package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View;


import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Checklist;

import java.util.ArrayList;
import java.util.List;

public interface ICheckListView {
    void CheckLsits(List<Checklist> list);

    void Checklist(Checklist checklist);

    void CheckListInserted(boolean status);

    void TypeCheckList(ArrayList<Checklist> arrayList);

    void NoCheckListWithThisType(String error);

    void CheckListByTypeAndSubCanal(ArrayList<Checklist> checkLists);

    void onItemInserted(String name);
}
