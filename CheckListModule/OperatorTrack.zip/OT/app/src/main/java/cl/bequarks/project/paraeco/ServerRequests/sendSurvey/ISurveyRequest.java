package cl.bequarks.project.paraeco.ServerRequests.sendSurvey;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ISurveyRequest {

    @FormUrlEncoded
    @POST("/api/addAnswer")
    Call<SurveyResult> sendSurvey(
     @Field("devid") String devId
    ,@Field("authkey")String authKey
    ,@Field("email")String userEmail
    ,@Field("shop_id")String shopId
    ,@Field("check_list_id")String checklistId
    ,@Field("start_time")String startTime
    ,@Field("end_time")String endTime
    ,@Field("data")String data
    ,@Field("pics")String pics);

}
