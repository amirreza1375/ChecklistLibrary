package cl.bequarks.project.paraeco.ServerRequests.LogMonitorServer;

import org.json.JSONArray;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ILogMonitorRequest {

    @FormUrlEncoded
    @POST("/api/getSendAppStatus")
    Call<LogMonitorResponse> request (@Field("authkey")String tokken
    , @Field("devid") String deviceId
    , @Field("data")JSONArray data);

}
