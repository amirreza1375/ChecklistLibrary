package cl.bequarks.project.paraeco.Activity.ActivityDeleted;

import android.app.AlertDialog;
import android.content.DialogInterface;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.checklist.PictureElement.PicturePickerItemModel;
import com.example.checklist.ReverseArray;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.UserCheckList;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Presenter.UserChecklistPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.View.IUserChecklistView;
import cl.bequarks.project.paraeco.Adapter.RecyclerItemTouchHelperListener;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.R;

import static cl.bequarks.project.paraeco.sharedpreference.Config.getUser;

public class ActivityDeleted extends AppCompatActivity implements IUserChecklistView
        , View.OnClickListener, RecyclerItemTouchHelperListener
        , DeletedItemsRecyclerAdapter.DeletedItemsActionListener {

    private RecyclerView recyclerView;
    private ImageView back;
    private EditText editTextSearch;
    private LinearLayout empty;
    private TextView deletedCount;
    private Button removeAll;

    private UserChecklistPresenter presenter;
    private UserCheckList model;

    private ArrayList<UserCheckList> deletedChecklists;

    private ReverseArray<UserCheckList> surveyReverseArray;

    private DeletedItemsRecyclerAdapter adapter;

    private AlertDialog deleteAlert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deleted_new);

        recyclerView = findViewById(R.id.recycler);
        back = findViewById(R.id.back);
//        editTextSearch = findViewById(R.id.editTextSerach);
        empty = findViewById(R.id.emptybox);
        deletedCount = findViewById(R.id.deletedCount);
        removeAll = findViewById(R.id.removeAll);

        InitilizeAlert();

        back.setOnClickListener(this);
        removeAll.setOnClickListener(this);

        deletedChecklists = new ArrayList<>();
        surveyReverseArray = new ReverseArray<>();

        presenter = new UserChecklistPresenter();
        model = new UserCheckList();
        presenter.addModel(model);
        presenter.attachView(this);

        presenter.getDeletedItems(getUser(this));

    }

    private void setUpRecycler() {
        if (adapter == null) {
            adapter = new DeletedItemsRecyclerAdapter(this, deletedChecklists, this);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));

            ItemTouchHelper.SimpleCallback itemTouchHelperCallBack = new RecylcerItemTouchHelperDeleted(0, ItemTouchHelper.LEFT, this);
            new ItemTouchHelper(itemTouchHelperCallBack).attachToRecyclerView(recyclerView);

            recyclerView.setAdapter(adapter);
        }else {
            update();
        }


    }

    private void update() {
        if (recyclerView.getAdapter() != null) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    recyclerView.getAdapter().notifyDataSetChanged();
                }
            });
        }
    }

    private void hideEmpty() {
        recyclerView.setVisibility(View.VISIBLE);
        empty.setVisibility(View.INVISIBLE);
        removeAll.setVisibility(View.INVISIBLE);
    }

    private void showEmpty() {
        recyclerView.setVisibility(View.INVISIBLE);
        empty.setVisibility(View.VISIBLE);
        removeAll.setVisibility(View.INVISIBLE);
    }

    private void dismissAlert(final AlertDialog alertDialog){
        if (alertDialog != null){
            if (!isFinishing()){
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        alertDialog.dismiss();
                    }
                });
            }
        }
    }


    private void showAlert(final AlertDialog alertDialog){
        if (alertDialog != null){
            if (!isFinishing()){
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        alertDialog.show();
                    }
                });
            }
        }
    }

    private void InitilizeAlert(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.deleteAllTitle));
        builder.setMessage(R.string.deleteAllMsg);
        builder.setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dismissAlert(deleteAlert);
            }
        });
        builder.setPositiveButton(getString(R.string.delete), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                removeAllItems();
            }
        });

        deleteAlert = builder.create();
    }

    @Override
    public void CheckListDataInserted(long id) {

    }

    @Override
    public void CheckListDataNotInserted(String err) {

    }

    @Override
    public void CheckListItemsByUserAndDate(ArrayList<UserCheckList> userCheckLists) {

    }

    @Override
    public void CheckListDataItemsEmpty() {

    }

    @Override
    public void CheckListById(UserCheckList userCheckList) {

    }

    @Override
    public void CheckListNotFound() {

    }

    @Override
    public void CheckListSynced() {

    }

    @Override
    public void CheckListNotSynced() {

    }

    @Override
    public void CheckListDataAndPictures(UserCheckList userCheckList, ArrayList<PicturePickerItemModel> pics) {

    }

    @Override
    public void NoCheckLisAndPictures() {

    }

    @Override
    public void NoDeletedItem() {
        showEmpty();
        deletedCount.setText("0");
    }

    @Override
    public void onDeletedItemsRecieved(ArrayList<UserCheckList> results) {
        hideEmpty();
        deletedCount.setText(results.size() + "");
        deletedChecklists.clear();
        deletedChecklists.addAll(surveyReverseArray.reverseArray(results));
        setUpRecycler();
    }

    @Override
    public void allDeletedsRemoved() {
        presenter.getDeletedItems(getUser(G.context));
    }

    @Override
    public void onClick(View v) {
        if (v == back) {
            finish();
        }
        if (removeAll == v){
            showAlert(deleteAlert);
        }
    }

    private void removeAllItems() {
        presenter.removeAllDeletedItems();
    }

    @Override
    public void onSwipe(RecyclerView.ViewHolder viewHolder, int direction, int position) {
        adapter.removeItem(position);
    }

    @Override
    public void onItemRemoved(long id) {
        UserCheckList userCheckList = new UserCheckList().fetchById(id);
        userCheckList.setDeleted(0);
        userCheckList.update(userCheckList);
        presenter.getDeletedItems(getUser(ActivityDeleted.this));
    }
}
