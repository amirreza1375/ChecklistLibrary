package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBResultView;
import cl.bequarks.project.paraeco.DBHelper.FeedReaderContract;
import cl.bequarks.project.paraeco.DBHelper.TableDbHelper;
import cl.bequarks.project.paraeco.Global.G;

import static com.example.checklist.GlobalFuncs.conf_productId;
import static com.example.checklist.GlobalFuncs.conf_shopId;
import static com.example.checklist.GlobalFuncs.conf_stock;
import static com.example.checklist.GlobalFuncs.conf_title;

public class Product extends DBModelBaseTemp<Product> implements IProduct {


//    "product_id": "1761",
//            "stock": "17"

    private long productId;
    private int stock;
    private String shop;
    private String title;


    public Product() {

    }

    @Override
    public SQLiteDatabase dropAndCreateTable() {
        TableDbHelper dbHelper = TableDbHelper.getInstanceProduct(G.context);
//
        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL(FeedReaderContract.ProductTalbe.SQL_DELETE_ENTRIES);

        if (!dbHelper.isTableExists(FeedReaderContract.ProductTalbe.TABLE_NAME, false)) {
            db.execSQL(FeedReaderContract.ProductTalbe.SQL_CREATE_ENTRIES);
        }

        return db;
    }

    public Product(long productId, int stock, String shop, String title) {
        this.productId = productId;
        this.stock = stock;
        this.shop = shop;
        this.title = title;
    }


    @Override
    public Product getByJson(JSONObject json) {
        try {
            Product product = new Product(
                    json.has(conf_productId) ? json.getLong(conf_productId) : -1,
                    json.has(conf_stock) ? json.getInt(conf_stock) : 0,
                    json.has(conf_shopId) ? json.getString(conf_shopId) : "",
                    json.has(conf_title) ? json.getString(conf_title) : "No Name"
            );
            return product;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return new Product();
    }

    @Override
    public void refreshTable(final JSONArray json, final IDBResultView callback) {
//        deleteAllTable("Product");

        new Thread(new Runnable() {
            @Override
            public void run() {
                SQLiteDatabase db = dropAndCreateTable();

                Log.i(MODEL_TAG, "Product -> Insert start");
//                db.beginTransaction();
                for (int i = 0; i < json.length(); i++) {
                    try {

                        Product product = getByJson(json.getJSONObject(i));
                        if (product.getErrorMessage() == null) {
                            product.insert(product, db, callback);
                            callback.onItemInserted();
                        } else {
                            callback.onFail(product.getErrorMessage());

                        }
                    } catch (JSONException e) {
                        callback.onFail("category have some problem");

                        //TODO: how is it posible to be here?
                    }
                }
                Log.i(MODEL_TAG, "Product -> Insert finished");
//                db.endTransaction();
//                db.close();
                callback.onSuccess();

            }
        }).start();
    }

    @Override
    public SQLiteDatabase getDataBaseConnection() {
        return TableDbHelper.getInstanceProduct(G.context).getWritableDatabase();
    }

    @Override
    public Product fetchById(long id) {
        TableDbHelper dbHelper = TableDbHelper.getInstanceProduct(G.context);

        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.ProductTalbe.TABLE_NAME
                + " where " + FeedReaderContract.ProductTalbe._ID + "='" + id + "'", null);
        cursor.moveToNext();
//        db.close();
        return getItemByCursor(cursor);
    }

    @Override
    public long insert(Product product, SQLiteDatabase db, IDBResultView callBack) {
        ContentValues values = new ContentValues();
        values.put(FeedReaderContract.ProductTalbe.productId, product.getProductId());
        values.put(FeedReaderContract.ProductTalbe.stock, product.getStock());
        values.put(FeedReaderContract.ProductTalbe.shopId, product.getShop());
        values.put(FeedReaderContract.ProductTalbe.title, product.getTitle());

        long newRowId = db.insert(FeedReaderContract.ProductTalbe.TABLE_NAME, null, values);
        return newRowId;

    }

    @Override
    public Product getItemByCursor(Cursor cursor) {
        if (cursor != null) {
            try {
                int productId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ProductTalbe.productId));
                int stock = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ProductTalbe.stock));
                String shopId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ProductTalbe.shopId));
                String title = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ProductTalbe.title));


                return new Product(productId, stock, shopId, title);
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                cursor.close();
            }
        }
        return new Product();
    }

    public Product getItemForCursor(Cursor cursor) {
        if (cursor != null) {

            int productId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ProductTalbe.productId));
            int stock = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ProductTalbe.stock));
            String shopId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ProductTalbe.shopId));
            String title = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ProductTalbe.title));


            return new Product(productId, stock, shopId, title);
        }
        return new Product();
    }

    @Override
    public boolean updateImgPath(SQLiteDatabase db, String URL, long id, IDBResultView callBack) {
        return false;
    }


    @Override
    public ArrayList<Product> getAllItems() {
        TableDbHelper dbHelper = TableDbHelper.getInstanceProduct(G.context);
//
        // Gets the data repository in write mode
        if (dbHelper.isTableExists(FeedReaderContract.ProductTalbe.TABLE_NAME, true)) {
            final SQLiteDatabase db = dbHelper.getWritableDatabase();

            Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.ProductTalbe.TABLE_NAME, null);
//            db.close();
            return getItemsByCursor(cursor, db);
        } else {
            return new ArrayList<>();
        }
    }

    @Override
    public ArrayList<Product> getItemsByCursor(Cursor cursor, SQLiteDatabase db) {
        try {
            ArrayList<Product> products = new ArrayList<>();
            if (cursor.moveToFirst()) {
                while (!cursor.isAfterLast()) {

                    products.add(getItemForCursor(cursor));

                    cursor.moveToNext();
                }
            }
            cursor.close();
//            db.close();
            return products;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
//            db.close();
            cursor.close();
        }
//        db.close();
        return new ArrayList<>();
    }

    @Override
    public String getImgURLById(long id) {
        return null;
    }

    @Override
    public ContentValues getValuse(Product item) {
        return null;
    }

//    @Override
//    public void downloadImages(IDBResultView callBack) {
//
//    }

    public long getProductId() {
        return productId;
    }

    public void setProductId(long productId) {
        this.productId = productId;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }


    public String getShop() {
        return shop;
    }

    public void setShop(String shop) {
        this.shop = shop;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
