package cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model;

public interface IDBInsertResult {
    void onSuccess(long id);
    void onFail(String error);
}
