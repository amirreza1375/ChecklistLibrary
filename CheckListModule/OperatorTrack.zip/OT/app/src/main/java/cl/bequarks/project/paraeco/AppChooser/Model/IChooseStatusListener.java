package cl.bequarks.project.paraeco.AppChooser.Model;

public interface IChooseStatusListener {
     void onAppChoosen();
}
