package cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.presenter;

import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.ResultPicture;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.UserCheckList;
import cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.model.MainItemModel;
import cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.view.IMainItemView;
import cl.bequarks.project.paraeco.Activity.PresenterBasic;

public class MainItemPresenter extends PresenterBasic<IMainItemView,MainItemModel>
         {


    SearchInChecklist searchInChecklist;
//    @Override
//    public void SyncItems() {
//        model.setListener(this);
//
//        model.SyncAll(new IDBSyncResultView<ItemQueueModel>() {
//            @Override
//            public void onSuccess(ItemQueueModel result) {
//                view.onItemSynced(result);
//            }
//
//            @Override
//            public void onFail(ItemQueueModel result, String error) {
//                view.onItemFailedToSync(result,error);
//            }
//        });
//
//    }

//    @Override
//    public void SyncItem(UserCheckList userCheckList, MainItemsRecyclerAdapter.ViewHolder statusImg) {
//        model.Sync(CreateQueueModelFromCheckListData(userCheckList, statusImg), new IDBSyncResultView<ItemQueueModel>() {
//            @Override
//            public void onSuccess(ItemQueueModel result) {
//                view.onItemSynced(result);
//            }
//
//            @Override
//            public void onFail(ItemQueueModel result, String error) {
//                view.onItemFailedToSync(result,error);
//            }
//        });
//    }
//
//    @Override
//    public void addItemToQueue(UserCheckList userCheckList, MainItemsRecyclerAdapter.ViewHolder statusImg) {
//        model.Push(CreateQueueModelFromCheckListData(userCheckList,statusImg));
//    }
//
//    private ItemQueueModel CreateQueueModelFromCheckListData(UserCheckList userCheckList, MainItemsRecyclerAdapter.ViewHolder statusImg) {
//
//        ItemQueueModel model = new ItemQueueModel(
//                userCheckList.get_ID()
//                , userCheckList.getShop_id()
//                , userCheckList.getCheckList_id()
//                , userCheckList.getStart_time()
//                , userCheckList.getEnd_time()
//                , userCheckList.getAnswerJson()
//                ,getItemPicturesByCheckListDataIdStr(userCheckList.get_ID())
//                ,getItemPicturesByCheckListDataId(userCheckList.get_ID())
//                ,statusImg
//        );
//
//        return model;
//
//    }

    private String getItemPicturesByCheckListDataIdStr(Long id) {
        return converPictureModelsToJSONArray(getItemPicturesByCheckListDataId(id)).toString();
    }

    private ArrayList<ResultPicture> getItemPicturesByCheckListDataId(Long id) {

        ArrayList<ResultPicture> temp = new ArrayList<>();

        List<ResultPicture> pictureModels = new ResultPicture().getAllItems();

        for (ResultPicture pictureModel : pictureModels){

            if (pictureModel.getCheckListDataBaseId() == id){
                temp.add(pictureModel);
            }

        }

        return temp;
    }
//
//    @Override
//    public void onSynced(boolean isSynced) {
//        SyncItems();
//        Log.i(MainItemModel.TAG, "onSynced: sync other");
//    }
//
//    @Override
//    public void onSyncStart(ItemQueueModel itemQueueModel,boolean isProccessing) {
//        view.updateRecyclerForSyncAnimation(itemQueueModel,isProccessing);
//    }
//
//    @Override
//    public void onSyncFinished(ItemQueueModel itemQueueModel,boolean isProccessing) {
//        view.updateRecyclerForSyncAnimation(itemQueueModel,isProccessing);
//    }
//
//    @Override
//    public void message(String msg) {
//        view.message(msg);
//    }

    private JSONArray converPictureModelsToJSONArray(ArrayList<ResultPicture> pictureModels){

        JSONArray pics = new JSONArray();

        for (ResultPicture pictureModel : pictureModels){

            JSONObject pic = new JSONObject();

            try {
                pic.put("type","file");
                pic.put("id",pictureModel.getQuestion_id());
                pic.put("name",pictureModel.getName());
                pic.put("imagetype",pictureModel.getImage_type());

                pics.put(pic);

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

        return pics;

    }





    public void startUpdateList(String key,String date){
        if(searchInChecklist!=null)
            searchInChecklist.cancel(true);
        if(key.equals("")) {
            new SearchInChecklist().execute("",date);
        }
        else
        {
            if(key.length()>0){
                searchInChecklist = new SearchInChecklist();
                searchInChecklist.execute(key,date);
            }else{
                stopSearchChecklist();
            }

        }
    }
    public void startUpdateList(String key,String date,Boolean checkLength){
        if(!checkLength){
            if(searchInChecklist!=null)
                searchInChecklist.cancel(true);

            searchInChecklist = new SearchInChecklist();
            searchInChecklist.execute(key,date);

        }


    }
    public void stopSearchChecklist(){
        if(searchInChecklist!=null)
            searchInChecklist.cancel(true);
        view.onSearchFinish();
    }
    public class SearchInChecklist extends AsyncTask<String, Void, String> {




        @Override
        protected String doInBackground(String... params) {
            String key = params[0];
            String date = params[1];
            List<UserCheckList> userCheckLists;
            userCheckLists = model.getChecklist(key,date);
            if (userCheckLists.size()>=0)
                view.listChange(userCheckLists);
            return "Executed";

        }

        @Override
        protected void onPostExecute(String result) {
            view.onSearchFinish();
        }

        @Override
        protected void onPreExecute() {
            view.onSearchStart();
        }

    }
}