package cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.view;

import java.util.List;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.UserCheckList;
import cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.model.ItemQueueModel;

public interface IMainItemView {

    void onItemSynced(ItemQueueModel itemQueueModel);

    void onItemFailedToSync(ItemQueueModel itemQueueModel, String error);

    void listChange(List<UserCheckList> list);
    void onSearchFinish();
    void onSearchStart();
    void updateRecyclerForSyncAnimation(ItemQueueModel itemQueueModel,boolean isProccessing);

    void message(String msg);
}
