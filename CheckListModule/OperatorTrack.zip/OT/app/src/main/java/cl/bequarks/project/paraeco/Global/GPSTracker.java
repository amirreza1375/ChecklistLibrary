package cl.bequarks.project.paraeco.Global;
/**
 * Created by Chingiskhan on 12/18/2017.
 */

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;

import cl.bequarks.project.paraeco.sharedpreference.Config;

import static cl.bequarks.project.paraeco.Global.EasyLocationProvider.currentLat;
import static cl.bequarks.project.paraeco.Global.EasyLocationProvider.currentLong;

public class GPSTracker extends Service implements LocationListener {

    private final Context mContext;

    private Location lastKnownLocation;

    private static final String TAG = "GPSTracker";

    // flag for GPS status
    boolean isGPSEnabled = false;

    // flag for network status
    boolean isNetworkEnabled = false;

    // flag for GPS status
    boolean canGetLocation = false;

    Location location; // location
    double latitude; // latitude
    double longitude; // longitude

    public static GPSTracker gpsTracker;

    private Context context;
    private GPSListener listener;

    // The minimum distance to change Updates in meters
    private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 0; // 10 meters

    // The minimum time between updates in milliseconds
    private static final long MIN_TIME_BW_UPDATES = 0; // 1 minute

    // Declaring a Location Manager
    protected LocationManager locationManager;


    private GPSTracker(Context context, GPSListener listener) {
        this.mContext = context;
        this.listener = listener;
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                getLocation();
            }
        });


    }

    public static GPSTracker getInstance(Context context, GPSListener listener){
        if (gpsTracker == null){
            gpsTracker = new GPSTracker(context,listener);
        }
        gpsTracker.setListener(listener);
        return gpsTracker;
    }

    public void getCurrentLocation(){
        if (lastKnownLocation == null){
            getLocation();
        }else{
            listener.onLocationTracked(lastKnownLocation.getLatitude()
            ,lastKnownLocation.getLongitude());
        }
    }


    @SuppressLint("MissingPermission")
    public Location getLocation() {
//        try {

        Config.sendDataLog("Lat : "+currentLat+" Long : "+currentLong,"GPS");
            listener.onLocationTracked(currentLat,currentLong);
            return null;
//
//            locationManager = (LocationManager) mContext
//                    .getSystemService(LOCATION_SERVICE);
//
//
//            // getting GPS status
//            isGPSEnabled = locationManager
//                    .isProviderEnabled(LocationManager.GPS_PROVIDER);
//
//            // getting network status
//            isNetworkEnabled = locationManager
//                    .isProviderEnabled(LocationManager.NETWORK_PROVIDER);
//
//            if (!isGPSEnabled && !isNetworkEnabled) {
//                // no network provider is enabled
////                Toast.makeText(mContext, "No network nor GPS", Toast.LENGTH_SHORT).show();
//            } else {
//                this.canGetLocation = true;
//                // First get location from Network Provider
//                if (isNetworkEnabled) {
////                    Toast.makeText(mContext, "Network is enable", Toast.LENGTH_SHORT).show();
//                    locationManager.requestLocationUpdates(
//                            LocationManager.NETWORK_PROVIDER,
//                            MIN_TIME_BW_UPDATES,
//                            MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
//                    Log.d("Network", "Network");
//                    if (locationManager != null) {
//                        location = locationManager
//                                .getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
//                        if (location != null) {
//                            latitude = location.getLatitude();
//                            longitude = location.getLongitude();
//                            Log.i(TAG, "getLocation: "+latitude+" -- "+longitude);
////                            Toast.makeText(mContext, "Location got by network -> "+location.getLatitude()+" -- " +
////                                                                          location.getLongitude(), Toast.LENGTH_SHORT).show();
//                            listener.onLocationTracked(latitude, longitude);
//                            return null;
//
//                        }
//                    }
//                }
//                // if GPS Enabled get lat/long using GPS Services
//                if (isGPSEnabled) {
////                    Toast.makeText(mContext, "GPS is enable", Toast.LENGTH_SHORT).show();
//                    if (location == null) {
//                        locationManager.requestLocationUpdates(
//                                LocationManager.GPS_PROVIDER,
//                                MIN_TIME_BW_UPDATES,
//                                MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
//                        Log.d("GPS Enabled", "GPS Enabled");
//                        if (locationManager != null) {
//                            location = locationManager
//                                    .getLastKnownLocation(LocationManager.GPS_PROVIDER);
//                            if (location != null) {
////                                Toast.makeText(mContext, "Location got by GPS -> "+location.getLatitude()+" -- "
////                                        +location.getLongitude(), Toast.LENGTH_SHORT).show();
//                                latitude = location.getLatitude();
//                                longitude = location.getLongitude();
//
//                                Log.i(TAG, "getLocation: "+latitude+" -- "+longitude);
//
//                                listener.onLocationTracked(latitude, longitude);
//                                return null;
//
//                            }else{
////                                Toast.makeText(mContext, "Location is null", Toast.LENGTH_SHORT).show();
//                                listener.onLocationError("");
////                                showSettingsAlert();
//                                return null;
//                            }
//
//                        }else{
////                            Toast.makeText(mContext, "Location manager is null", Toast.LENGTH_SHORT).show();
//                            listener.onLocationError("");
////                            showSettingsAlert();
//                            return null;
//                        }
//                    }
//                }else{
////                    Toast.makeText(mContext, "GPS is disable", Toast.LENGTH_SHORT).show();
//                    listener.onLocationError("");
////                    showSettingsAlert();
//                    return null;
//                }
//            }

//        } catch (Exception e) {
//            e.printStackTrace();
////            Toast.makeText(mContext, "CATCH : "+e.getMessage(), Toast.LENGTH_SHORT).show();
//            listener.onLocationError("");
////            showSettingsAlert();
//            return null;
//        }

//        return location;
    }

    /**
     * Stop using GPS listener
     * Calling this function will stop using GPS in your app
     */
    public void stopUsingGPS() {
        if (locationManager != null) {
            locationManager.removeUpdates(GPSTracker.this);
        }
    }

    /**
     * Function to get latitude
     */
    public double getLatitude() {
        if (location != null) {
            latitude = location.getLatitude();
        }

        // return latitude
        return latitude;
    }

    /**
     * Function to get longitude
     */
    public double getLongitude() {
        if (location != null) {
            longitude = location.getLongitude();
        }

        // return longitude
        return longitude;
    }

    /**
     * Function to check GPS/wifi enabled
     *
     * @return boolean
     */
    public boolean canGetLocation() {
        return this.canGetLocation;
    }

    /**
     * Function to show settings alert dialog
     * On pressing Settings button will lauch Settings Options
     */
    public void showSettingsAlert() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(mContext);

        // Setting Dialog Title
        alertDialog.setTitle("GPS is settings");

        // Setting Dialog Message
        alertDialog.setMessage("GPS is not enabled. Do you want to go to settings menu?");

        // On pressing Settings button
        alertDialog.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                mContext.startActivity(intent);
            }
        });

        // on pressing cancel button
        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        // Showing Alert Message
        alertDialog.show();
    }

    @Override
    public void onLocationChanged(Location location) {
//        Toast.makeText(mContext, "onLocationChanged: "+location.getLatitude(), Toast.LENGTH_SHORT).show();
        Log.i(TAG, "onLocationChanged: "+location.getLatitude());
        this.lastKnownLocation = location;
    }

    @Override
    public void onProviderDisabled(String provider) {
        Log.i(TAG, "onProviderDisabled: "+provider);
//        Toast.makeText(mContext, "onProviderDisabled: "+provider, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onProviderEnabled(String provider) {
        Log.i(TAG, "onProviderEnabled: "+provider);
//        Toast.makeText(mContext, "onProviderEnabled: "+provider, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
//        Log.i(TAG, "onStatusChanged: "+provider+":"+status);
//        Toast.makeText(mContext, "onStatusChanged: "+provider+":"+status, Toast.LENGTH_SHORT).show();
    }

    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }

    public GPSListener getListener() {
        return listener;
    }

    public void setListener(GPSListener listener) {
        this.listener = listener;
    }

    public interface GPSListener {
        void onLocationTracked(double lat, double latLong);

        void onLocationError(String msg);
    }

}
