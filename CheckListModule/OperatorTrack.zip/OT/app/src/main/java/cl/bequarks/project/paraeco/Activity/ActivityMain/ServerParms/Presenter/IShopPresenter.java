package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter;

import org.json.JSONArray;

public interface IShopPresenter {
    void Insert(JSONArray jSONArray);

    void getShopById(long j);

    void getShops();

    void getShopsByLocation(double j, double j2);

    void getShopsByLocationSubCanal(double j, double j2, int i, int i2);

    void getShopsByCurrentLocation();
}
