package cl.bequarks.project.paraeco.ServerRequests.RetrofitInterface;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;

import com.example.checklist.Image.ImageHandler;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.ResultPicture;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.R;
import cl.bequarks.project.paraeco.ServerRequests.ApiService;
import cl.bequarks.project.paraeco.ServerRequests.FileUploader.ProgressRequestBody;
import cl.bequarks.project.paraeco.ServerRequests.IResponsePicture;
import cl.bequarks.project.paraeco.ServerRequests.IResponseSendPicture;
import cl.bequarks.project.paraeco.sharedpreference.Config;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.content.Context.MODE_PRIVATE;
import static cl.bequarks.project.paraeco.ServerRequests.ApiService.TAGG;

public class PictureQueueSender implements IResponseSendPicture
        , ApiService.ApiAuthinticationFailListener {

    private final int appPreferedImageMaxSizeInKB = 250;

    private static final String TAG = "ActivityMain";

    private ArrayList<ResultPicture> resultPictures;
    private String serverId;
    private long checkListDataId;
    private IResponsePicture callBack;
    private String[] syncedImages;

    private int RETRY_COUNT = 5;
    private int retry = 0;

    public PictureQueueSender(ArrayList<ResultPicture> resultPictures, String serverId, long checkListDataId, IResponsePicture callBack, String[] syncedImages) {

        this.resultPictures = resultPictures;
        this.serverId = serverId;
        this.checkListDataId = checkListDataId;
        this.callBack = callBack;
        this.syncedImages = syncedImages;
    }

    public void startSend() {
        retry = 0;
        if (resultPictures.size() == 0) {
            callBack.NoPictures();
        } else {
            Log.i(TAG, "startSend: so we have "+resultPictures.size() + " images to send");
            sendPicture(resultPictures.get(0), serverId, checkListDataId, this, 0, resultPictures.size());
        }


    }


    private void sendPicture(final ResultPicture resultPicture, final String server_Id
            , final long checkListDataId, final IResponseSendPicture callBack, final int index, final int size) {

        if (resultPicture != null) {//check is not null

//            Log.i(TAG, "sendPicture: record is not null");

            if (resultPicture.isSynced() == 0) {//check is not synced

//                Log.i(TAG, "sendPicture: image is not synced");
                
                if (!isPictureSyncedToServer(resultPicture.getQuestion_id()))

//                if (!resultPicture.isProccessing()) {//check is not in proccess

                    //region image send Api

                    if (isNetworkConnected()) {

//                        Log.i(TAG, "sendPicture: network is connected");

                        resultPicture.setProccessing(1);
                        resultPicture.update(resultPicture);

                        //TODO change database


                        String imagePath = resultPicture.getPath();

                        if (resultPicture.getPath() != null) {

//                            Log.i(TAG, "sendPicture: image path is not null");

                            String imagePathArray[] = imagePath.split("/");
                            String imageName = imagePathArray[imagePathArray.length - 1];

                            ImageHandler imageHandler = new ImageHandler(G.context, appPreferedImageMaxSizeInKB);
                            File file = new File(resultPicture.getPath());
                            if (file.exists()) {
                                imageHandler.ResizeImage(G.context, resultPicture.getPath(), imageName, new ImageHandler.ImageResizerListener() {
                                    @Override
                                    public void onImageResized(String path) {
                                        File img = new File(path);

                                        if (img.exists()) {

//                                        new FileUploadTask(G.context,img.getPath(),Config.getServer(G.context)+"/Api/uploadPic/").execute("","","");

                                            Log.i(TAG, "onImageResized: image exist");

                                            ProgressRequestBody requestBody = new ProgressRequestBody(img, new ProgressRequestBody.UploadCallbacks() {
                                                @Override
                                                public void onProgressUpdate(int percentage) {
                                                    callBack.UploadProgress(percentage);
//                                                Log.i(TAG, "onProgressUpdate: "+percentage);
                                                }

                                                @Override
                                                public void onError() {
                                                    Log.i(TAG, "onError: ");
                                                }

                                                @Override
                                                public void onFinish() {
                                                    Log.i(TAG, "onFinish: ");
                                                }
                                            });

                                            final RequestBody reqFile = RequestBody.create(MediaType.parse("image/jpg"), img);
                                            final MultipartBody.Part body = MultipartBody.Part.createFormData("cont", img.getName(), requestBody);

                                            HttpLoggingInterceptor httpLoggingInterceptor1 = new HttpLoggingInterceptor();
                                            OkHttpClient client = new OkHttpClient.Builder().addInterceptor(httpLoggingInterceptor1)
                                                    .connectTimeout(30, TimeUnit.MINUTES)
                                                    .readTimeout(30, TimeUnit.MINUTES)
                                                    .build();

                                            Retrofit retrofit1
                                                    = new Retrofit.Builder().addConverterFactory(GsonConverterFactory.create())
                                                    .baseUrl(Config.getServer(G.context))
                                                    .client(client).build();

                                            Upload serviceAPI1 = retrofit1.create(Upload.class);
                                            RequestBody devid = RequestBody.create(okhttp3.MultipartBody.FORM, Settings.Secure.getString(G.context.getContentResolver(), Settings.Secure.ANDROID_ID));
                                            RequestBody serverId = RequestBody.create(okhttp3.MultipartBody.FORM, server_Id);
                                            RequestBody type = RequestBody.create(okhttp3.MultipartBody.FORM, String.valueOf(resultPicture.getImage_type()));
                                            final RequestBody pic_number = RequestBody.create(okhttp3.MultipartBody.FORM, resultPicture.getPic_index() + "");
                                            final RequestBody question_id = RequestBody.create(okhttp3.MultipartBody.FORM, resultPicture.getQuestion_id());
                                            RequestBody authkey = RequestBody.create(okhttp3.MultipartBody.FORM, G.context.getSharedPreferences(Config.sharedPreferencName, MODE_PRIVATE).getString(Config.tokken, ""));

                                            HashMap<String, RequestBody> map = new HashMap<>();

                                            map.put("devid", devid);
                                            map.put("authkey", authkey);
                                            map.put("server_id", serverId);
                                            map.put("pic_number", pic_number);
                                            map.put("type", type);
                                            map.put("question_id", question_id);

                                            log(resultPicture.get_ID() + "");

                                            Call<SaveServer> serverSaveCall1 = serviceAPI1.getSavePic(map, body);
                                            serverSaveCall1.enqueue(new Callback<SaveServer>() {
                                                @Override
                                                public void onResponse(Call<SaveServer> call, retrofit2.Response<SaveServer> response) {
                                                    if (response.body() != null) {
                                                        log(response.body().getResult());
                                                        if (response.body().getError().equals("false")) {
                                                            Log.i(TAG, "onResponse: image sent to server");
                                                            resultPicture.setProccessing(0);
                                                            resultPicture.setSynced(1);
                                                            resultPicture.update(resultPicture);

                                                            callBack.Sent(size, index);
                                                        } else {
                                                            Log.i(TAG, "onResponse: server error");
                                                            resultPicture.setProccessing(0);
                                                            resultPicture.setSynced(0);
                                                            resultPicture.update(resultPicture);
                                                            new ApiService(PictureQueueSender.this).sendUploadPicError(server_Id + "", resultPicture.getPic_index() + "", resultPicture.getImage_type() + "", resultPicture.getQuestion_id(), response.body().getResult());
                                                            callBack.ServerError(index, response.body().getResult(), size);
                                                        }
                                                    } else {
                                                        Log.i(TAG, "onResponse: server error body is null");
                                                        resultPicture.setProccessing(0);
                                                        resultPicture.setSynced(0);
                                                        resultPicture.update(resultPicture);
                                                        new ApiService(PictureQueueSender.this).sendUploadPicError(server_Id + "", resultPicture.getPic_index() + "", resultPicture.getImage_type() + "", resultPicture.getQuestion_id(), "Body was null -");
                                                        callBack.ServerError(index, "body was null", size);
                                                    }
                                                }

                                                @Override
                                                public void onFailure(Call<SaveServer> call, Throwable t) {
                                                    resultPicture.setProccessing(0);
                                                    resultPicture.setSynced(0);
                                                    resultPicture.update(resultPicture);
                                                    new ApiService(PictureQueueSender.this).sendUploadPicError(server_Id + "", resultPicture.getPic_index() + "", resultPicture.getImage_type() + "", resultPicture.getQuestion_id(), t.getMessage());
                                                    callBack.ServerFailed(index, t.getMessage(), size);
                                                }
                                            });
                                        } else {
                                            Log.i(TAG, "onImageResized: image not exist");
                                            resultPicture.setProccessing(0);
                                            resultPicture.setSynced(0);
                                            resultPicture.update(resultPicture);
                                            new ApiService(PictureQueueSender.this).sendUploadPicError(server_Id + "", resultPicture.getPic_index() + "", resultPicture.getImage_type() + "", resultPicture.getQuestion_id(), "Image not exist");
                                            callBack.ImageNotExist();
                                        }
                                    }
                                });
                            }else {
                                Log.i(TAG, "onImageResized: image not exist");
                                resultPicture.setProccessing(0);
                                resultPicture.setSynced(0);
                                resultPicture.update(resultPicture);
                                new ApiService(PictureQueueSender.this).sendUploadPicError(server_Id + "", resultPicture.getPic_index() + "", resultPicture.getImage_type() + "", resultPicture.getQuestion_id(), "Image not exist");
                                callBack.ImageNotExist();
                            }

                        } else {
                            Log.i(TAG, "sendPicture: image is null");
                            callBack.Sent(size, index);
                        }

                    } else {
                        Log.i(TAG, "sendPicture: network error");
                        callBack.NetWorkError();
                    }
                //endregion
                //}
            } else {//synced
                Log.i(TAG, "sendPicture: picture synced before");
                callBack.Sent(size, index);
            }

        }

    }

    private boolean isPictureSyncedToServer(String question_id) {
        for (int i = 0; i < syncedImages.length; i++) {
            String syncedImageId = syncedImages[i];
            if (syncedImageId.equals(question_id)) {
                return true;
            }

        }
        return false;
    }

    private boolean isNetworkConnected() {
        boolean isConnected = false;
        ConnectivityManager conMgr = (ConnectivityManager) G.context.getSystemService(Context.CONNECTIVITY_SERVICE);


        if (conMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED
                || conMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
            isConnected = true;

        } else if (conMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.DISCONNECTED
                || conMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.DISCONNECTED) {
            isConnected = false;

        }
        return isConnected;
    }

    private void log(String msg) {
        Log.i(TAGG, "log: ");
    }

    @Override
    public void NetWorkError() {
        Log.i(TAG, "NetWorkError: ");
        callBack.FailedToSync("Net Work Lost");
    }

    @Override
    public void ServerError(final int index , String error, final int size) {
        if (retry < RETRY_COUNT) {
            retry++;
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Log.i(TAG, "ServerError: retry "+ retry);
                    sendPicture(resultPictures.get(index), serverId, checkListDataId, PictureQueueSender.this, index, size);
                }
            },1000);

        }else {
            Log.i(TAG, "ServerError: server done retrying");;
            callBack.FailedToSync(error);
        }

    }

    @Override
    public void ServerFailed(final int index , String error, final int size) {
        if (retry < RETRY_COUNT) {
            retry++;
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Log.i(TAG, "ServerError: retry "+ retry);
                    sendPicture(resultPictures.get(index), serverId, checkListDataId, PictureQueueSender.this, index, size);
                }
            },1000);

        }else {
            Log.i(TAG, "ServerError: server done retrying");;
            callBack.FailedToSync(error);
        }
    }

    @Override
    public void Sent(int size, int index) {
        index++;
        callBack.onPictureSynced(size,index + 1);
        Log.i(TAG, "Sent: "+size + " / "+index);
        if (index < size) {//index 5 , size 5 last item is 4
            sendPicture(resultPictures.get(index), serverId, checkListDataId, PictureQueueSender.this, index, size);
        } else {//index 0 , size 5 last item is 4
            Log.i(TAG, "Sent: pictures synced all");
            callBack.PicturesSynced();
        }
    }

    @Override
    public void ImageNotExist() {
        callBack.FailedToSync(G.context.getString(R.string.imageNoExist));
        callBack.message("File not found");
    }

    @Override
    public void UploadProgress(int progress) {
        callBack.imageUploadProgress(progress);
    }

    @Override
    public void onAtuhinticationFailed() {

    }
}
