package cl.bequarks.project.paraeco.Activity.ActivityMain;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PointF;
import android.graphics.drawable.ColorDrawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.airbnb.lottie.LottieAnimationView;
import com.example.checklist.PictureElement.PicturePickerItemModel;
import com.example.checklist.ReverseArray;
import com.example.checklist.ServerJsonGenerator.ServerJSONCleanUp;
import com.github.clans.fab.FloatingActionButton;
import com.github.clans.fab.FloatingActionMenu;
import com.google.android.gms.common.api.GoogleApiClient;
import com.takusemba.spotlight.OnSpotlightEndedListener;
import com.takusemba.spotlight.OnSpotlightStartedListener;
import com.takusemba.spotlight.OnTargetStateChangedListener;
import com.takusemba.spotlight.SimpleTarget;
import com.takusemba.spotlight.Spotlight;

import cl.bequarks.project.paraeco.Activity.ActicityNewCheckList.ActivityNewCheckList;
import cl.bequarks.project.paraeco.Activity.ActivityBase;
import cl.bequarks.project.paraeco.Activity.ActivityDeleted.ActivityDeleted;
import cl.bequarks.project.paraeco.Activity.ActivityIssues.ActivityIssues;
import cl.bequarks.project.paraeco.Activity.ActivityChecklist.ActivityCheckList;
import cl.bequarks.project.paraeco.Activity.ActivityLogin.ActivityLogin;
import cl.bequarks.project.paraeco.Activity.ActivityLogin.Model.User;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.ResultPicture;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.UserCheckList;
import cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.ResultHolder;
import cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.ResultViewActionListener;
import cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.model.MainItemModel;
import cl.bequarks.project.paraeco.Activity.ActivityMain.Model.ActivityMainModel;
import cl.bequarks.project.paraeco.Activity.ActivityMain.Presenter.ActivityMainPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Presenter.UserChecklistPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.View.IUserChecklistView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.MainItemsRecyclerAdapter;

import cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.model.ItemQueueModel;
import cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.presenter.MainItemPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.view.IMainItemView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Accessory;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Category;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Checklist;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Layout;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.ModelAppVersion;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Optico;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Product;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Shop;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Version;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.AccessoryPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.CategoryPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.CheckListPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.LayoutPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.OpticoPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.PresenterAppVersion;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.ProductPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.ShopPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.UpdateParamsControllerPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.VersionPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IAccessoryView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.ICategoryView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.ICheckListView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.ILayoutView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IOpticoView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IProductView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IShopView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IVersionView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IViewAppVersion;
import cl.bequarks.project.paraeco.Activity.ActivityMain.View.IActivityMainView;
import cl.bequarks.project.paraeco.Activity.ActivityProfile.ActivityProfile;
import cl.bequarks.project.paraeco.Activity.ActivityProfile.Presenter.ProfilePresenter;
import cl.bequarks.project.paraeco.Activity.ActivityProfile.View.IProfileView;
import cl.bequarks.project.paraeco.Activity.ActivityShops.ActivityShops;
import cl.bequarks.project.paraeco.Activity.ActivityTutorial.ActivityTutorial;
import cl.bequarks.project.paraeco.Activity.Activitymap.MapsActivity;
import cl.bequarks.project.paraeco.Activity.PresenterBasic;
import cl.bequarks.project.paraeco.Adapter.CustomLayoutManager;
import cl.bequarks.project.paraeco.Adapter.RecyclerItemTouchHelper;
import cl.bequarks.project.paraeco.Adapter.RecyclerItemTouchHelperListener;
import cl.bequarks.project.paraeco.EvenLogger.LogEvent;
import cl.bequarks.project.paraeco.Global.EasyLocationProvider;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.Global.GPSTracker;
import cl.bequarks.project.paraeco.Global.NetWorkStatus;
import cl.bequarks.project.paraeco.Global.SwipeDetector;
import cl.bequarks.project.paraeco.Logger.LogMonitor;
import cl.bequarks.project.paraeco.Logger.LogMonitorDataListener;
import cl.bequarks.project.paraeco.Permissions.Model.Permission;
import cl.bequarks.project.paraeco.Permissions.Presenter.PermissionPresenter;
import cl.bequarks.project.paraeco.Permissions.View.IPermissionView;
import cl.bequarks.project.paraeco.R;
import cl.bequarks.project.paraeco.ServerRequests.ApiService;
import cl.bequarks.project.paraeco.ServerRequests.FileDownloader.IDownloaderListener;
import cl.bequarks.project.paraeco.ServerRequests.IResponseServerToApiForGetParams;
import cl.bequarks.project.paraeco.ServerRequests.LogEventServer.ILogEventListener;
import cl.bequarks.project.paraeco.sharedpreference.Config;
import de.hdodenhof.circleimageview.CircleImageView;
import io.reactivex.annotations.NonNull;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import org.json.JSONArray;

import static cl.bequarks.project.paraeco.Activity.ActivityChecklist.ActivityCheckList.IsCheckList;
import static cl.bequarks.project.paraeco.Activity.ActivityChecklist.ActivityCheckList.IsDraft;
import static cl.bequarks.project.paraeco.sharedpreference.Config.SIGNATURE_DIRECTORY;
import static cl.bequarks.project.paraeco.sharedpreference.Config.getDate;
import static cl.bequarks.project.paraeco.sharedpreference.Config.getUser;
import static cl.bequarks.project.paraeco.sharedpreference.Config.recycleBitmap;
import static cl.bequarks.project.paraeco.sharedpreference.Config.sendDataLog;
import static cl.bequarks.project.paraeco.sharedpreference.Config.sendEventLog;
import static com.example.checklist.GlobalFuncs.dpToPx;

public class ActivityMain extends ActivityBase implements IShopView
        , IResponseServerToApiForGetParams, ICheckListView
        , IOpticoView, IAccessoryView, ILayoutView
        , ICategoryView, View.OnClickListener, IPermissionView
        , IVersionView, NetWorkStatus.NetworkStatusListener
        , IActivityMainView, IUserChecklistView, IMainItemView
        , DrawerLayout.DrawerListener
        , TextWatcher, IViewAppVersion, View.OnKeyListener
        , RecyclerItemTouchHelperListener, ApiService.ApiAuthinticationFailListener
        , IDownloaderListener, IProductView, TextView.OnEditorActionListener, ResultViewActionListener
        , GPSTracker.GPSListener, IProfileView, SwipeRefreshLayout.OnRefreshListener {

    private static final int OPENED_CHECKLIST_KEY = 13;

    private float last_known_offset = 0;

    private LottieAnimationView animationEmptyBox;

    private GestureDetector gestureDetector;
    private SwipeDetector swipeDetector;

    private LinearLayout mainUI;


    private JSONArray shopsJSON;
    private JSONArray accessoriesJSON;
    private JSONArray checklistsJSON;
    private JSONArray categoriesJSON;
    private JSONArray opticosJSON;
    private JSONArray layoutsJSON;
    private JSONArray productsJSON;

    private HashMap<String, Integer> insertedItemCountByName;
    private HashMap<String, Integer> itemCountByName;

    private ArrayList<Long> forceClosedItems;
    private ArrayList<Long> forcedClosedPics;

    private ArrayList<PresenterBasic> presenterBasics;

    private int presenterPointer = 0;

    private static final String TAG = "activity_main";

    private boolean appStarted = false;

    private boolean upadteInProcces = false;

    private String USERAGENT_CAMPANAS = "1";
    private String USERAGENT_AUDITORIA = "0";
    private String USERAGENT_VISUAL = "0";

    private boolean isNetWorkConnected = false;

    private double allItemsCount = 0;
    private double insertedItemsCount = 0;

    private static final float ROTATE_FROM = 0.0f;
    private static final float ROTATE_TO = -10.0f * 360.0f;

    private RecyclerView recyclerView;

    private MainItemModel mainItemModel;

//    private ProgressDialog progressDialog;

    private AlertDialog dialogVersionApp;
    private AlertDialog noShopAlert;
    private AlertDialog detailAlert;


    private AlertDialog paramsDialog;
    private ProgressBar paramsDialogProgress;
    private ProgressBar paramsDialogServerProgress;
    private ProgressBar paramsDialogItemInsertedProgress;
    private TextView paramsDialogTotal;
    private TextView paramsDialogRefreshed;
    private TextView paramsDialogItemProgressTxt;
    private TextView paramsDialogItemNameTxt;

    private BroadcastReceiver nw;

    private ArrayList<UserCheckList> recyclerData;

    private MainItemsRecyclerAdapter adapter;

    private boolean isConnected = false;

    private boolean isDataUpdated = false;

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        if (charSequence.length() == 0)
            mainItemPresenter.startUpdateList(editTextSerach.getText().toString(), choosenDate);
    }

    @Override
    public void afterTextChanged(Editable editable) {

    }

    private void setUpdatedStatusTimer() {
        this.isDataUpdated = true;
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                isDataUpdated = false;
            }
        }, 500);
    }


    private String choosenDate;

    @Override
    public void onSwipe(RecyclerView.ViewHolder viewHolder, int direction, int position) {
        adapter.removeItem(position);
    }

    @Override
    public void onAtuhinticationFailed() {
        ApiService.logOutOnUserAuthFailed(ActivityMain.this);
    }

    @Override
    public void onProccessChanged(int progress) {
        setDownloadProgress(progress);
    }

    @Override
    public void onDownloadError(String error) {
        dismissDialogHandler(appDownloadingDialog);
        showToast(error);
    }

    @Override
    public void onDownloadFinished(String filePath) {
        dismissDialogHandler(appDownloadingDialog);
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.parse(filePath), "application/vnd.android.package-archive");
        startActivity(intent);

    }

    @Override
    public void onDownloadStarted() {
        showDialogHanlder(appDownloadingDialog);
    }

    //region product
    @Override
    public void Products(ArrayList<Product> results) {

    }

    @Override
    public void noProduct() {

    }

    @Override
    public void noProductById() {

    }

    @Override
    public void ProductsById(ArrayList<Product> results) {

    }

    @Override
    public void ErrorInsertingProduct(String error) {
        controllerPresenter.checkRefreshingTables(false, "Product");
    }

    @Override
    public void ProductsInserted() {
        controllerPresenter.checkRefreshingTables(true, "Product");
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        Log.i(TAG, "onEditorAction: ");
        mainItemPresenter.startUpdateList(editTextSerach.getText().toString(), choosenDate);
        return true;
    }

    @Override
    public void onLocationTracked(double lat, double latLong) {
        Log.i(TAG, "onLocationTracked: ");
    }

    @Override
    public void onLocationError(String msg) {

    }

    @Override
    public void onRefresh() {
        if (editTextSerach.getText().toString().trim().equals("")) {
            adapter.setIsSyncUpdate(true);
            userChecklistPresenter.getCheckListItemsByUserAndDate(getUser(ActivityMain.this)
                    , choosenDate);
        }
    }

    //endregion


    //region variables
    public enum updateModel {
        SHOP, CHECKLIST, OPTICO, LAYOUT, ACCESSORY, CATEGORY, PRODUCT
    }

    private boolean isDrawerOpen = false;
    private boolean isTimeOut = true;

    private boolean isStoragePermitted = false;
    private boolean isLocationPermitted = false;
    private boolean isUpdateDataInProccess = false;
    private int updatedModelsCount = 0;
    //endregion

    //region MVP variable
    private UpdateParamsControllerPresenter controllerPresenter;
    private ApiService apiService;

    private AccessoryPresenter accessoryPresenter;
    private Accessory accessory;
    private CheckListPresenter checkListPresenter;
    private Checklist checklist;
    private LayoutPresenter layoutPresenter;
    private Layout layout;
    private OpticoPresenter opticoPresenter;
    private Optico optico;
    private ShopPresenter shopPresenter;
    private Shop shop;
    private CategoryPresenter categoryPresenter;
    private Category category;
    private PermissionPresenter permissionPresenter;
    private Permission permission;
    private VersionPresenter versionPresenter;
    private ActivityMainModel mainModel;
    private ActivityMainPresenter mainPresenter;
    private UserChecklistPresenter userChecklistPresenter;
    private UserCheckList userCheckList;
    private PresenterAppVersion presenterAppVersion;
    private ModelAppVersion modelAppVersion;
    private ProductPresenter productPresenter;
    private Product product;


    private MainItemPresenter mainItemPresenter;
    //endregion

    //region arrays
    ArrayList<AsyncTask> asyncTasks;
    //endregion

    //region views
//    private SwipeRefreshLayout refresh;
    private FloatingActionMenu menu;
    private TextView calendar;
    private TextView calendar_btn;
    private LinearLayout calendarHolder;
    private TextView userName;
    private TextView userEmail;
    private CircleImageView userImage;
    private LinearLayout emptyBox;
    private ImageView topMenu;
    private LinearLayout update;
    private LinearLayout exit;
    private LinearLayout inventory;
    private LinearLayout settings;
    private LinearLayout support;
    private LinearLayout about;
    private LinearLayout shops;
    private LinearLayout tutorial;
    private LinearLayout trash;
    private DrawerLayout drawer;
    private LinearLayout network_status;
    private ImageView network_status_img;
    private FloatingActionButton auditoria;
    private FloatingActionButton ticket;
    private AlertDialog logoutDialog;
    private AlertDialog aboutUsDialog;
    private AlertDialog appDownloadingDialog;
    private TextView downloadProgress;
    private ProgressBar progressBar;
    private LinearLayout userLocation;

    private CustomLayoutManager layoutManager;


    private EditText editTextSerach;
    private TextView textViewAppVersion;

    private ReverseArray<UserCheckList> surveyReverseArray;
    //endregion


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (grantResults.length != 0) {

            if (requestCode == 101) {
                if (grantResults[0] != -1) {
                    createAppFolder();
                    isStoragePermitted = true;
                    if (!isAnyItemIsProcessing())
                        controllerPresenter.getDBsDataFromServer(true);

                }
            }
            if (requestCode == 102) {
                if (grantResults[0] != -1) {
                    isLocationPermitted = true;
                    permissionPresenter.CheckLocationPermission();
                    GPSTracker.getInstance(this, this).getCurrentLocation();
                }

            }
        }

    }

    private String getDateText(String date) {
        if (date.equals(getDate())) {
            return getString(R.string.last24haours);
        }
        return date;
    }

    @Override
    protected void onResume() {

        super.onResume();

        ProfilePresenter profilePresenter = new ProfilePresenter();
        profilePresenter.addModel(new User());
        profilePresenter.attachView(ActivityMain.this);

        permissionPresenter.getLocationPermission();

        mainPresenter.getProfilePic();

//        this.appStarted = true;

        menu.close(true);

        if (nw != null) {
            registerReceiver(nw, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
        }
        versionPresenter.StartVersionCheck();
        mainPresenter.setUserData();

//        refresh.setRefreshing(true);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                adapter.setIsSyncUpdate(true);
                userChecklistPresenter.getCheckListItemsByUserAndDate(getUser(ActivityMain.this), choosenDate);
            }
        },200);

        calendar_btn.setText(getDateText(choosenDate));

        if (!isUpdateDataInProccess) {
            dismissDialogHandler(paramsDialog);
            paramsDialog = null;
//            dismissProgressDialogHandler(progressDialog);
        }
//

//        terminateAllSynces();

    }

//    private void askForGpsPermissionAndStart() {
//        if (isLocationPermitted) {
//            GPSTracker.getInstance(this,this).getCurrentLocation();
//        } else {
//            permissionPresenter.getLocationPermission();
//        }
//    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OPENED_CHECKLIST_KEY) {

        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        TranslateAnimation translateAnimation = new TranslateAnimation(last_known_offset * 680, 0, 0, 0);
        translateAnimation.setFillEnabled(true);
        translateAnimation.setFillAfter(true);
        translateAnimation.setDuration(1);
        mainUI.setAnimation(translateAnimation);
        translateAnimation.start();
        drawer.closeDrawer(Gravity.LEFT);


        versionPresenter.TerminateVersionCheck();
//        terminateThreads();
        mainItemPresenter.stopSearchChecklist();
        if (nw != null)
            unregisterReceiver(nw);
//        terminateAllSynces();

    }

//    private void terminateAllSynces() {
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//
//                try {
//                    List<UserCheckList> checkListDataList = new UserCheckList().getAllItems();
//                    for (int i = 0; i < checkListDataList.size(); i++) {
//
//                       UserCheckList userCheckList = checkListDataList.get(i);
//
//                       if (userCheckList.isSynced() == 0 || userCheckList.isPicsSynced() == 0){
//
//                           if (userCheckList.isProccessing() == 1){
//
//                               userCheckList.setProccessing(0);
//                               userCheckList.update(userCheckList);
//
//                           }
//
//                       }
//
//                    }
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//
//            }
//        }).start();
//    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
//                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main_new);

        new LogEvent().getNotSyncedJsonArray(new LogMonitorDataListener() {
            @Override
            public void onDataRecieved(JSONArray data) {
                new ApiService(ActivityMain.this).sendLogEvents(data, new ILogEventListener() {
                    @Override
                    public void onSent(JSONArray data) {

                    }

                    @Override
                    public void onFailedToSend() {

                    }
                });
            }

            @Override
            public void onDataEmpty() {

            }
        });


        InitializeLogoutDialog();
        InitializeAboutUsDialog();
        InitializeVersionAppDialog();
        InitializeAppDownloader();
        InitilizaNoShopAlert();

//        new UserCheckList().getLastRowId();

        choosenDate = getDate();

        forceClosedItems = new ArrayList<>();
        forcedClosedPics = new ArrayList<>();
        insertedItemCountByName = new HashMap<>();
        itemCountByName = new HashMap<>();

        getCheckListError(getIntent().getExtras());

        //region findViewById
        menu = findViewById(R.id.menu);
        drawer = findViewById(R.id.drawer);
        drawer.addDrawerListener(this);
        calendar = findViewById(R.id.calendar);
        recyclerView = findViewById(R.id.recycler);
        topMenu = findViewById(R.id.top_menu);
        update = findViewById(R.id.update);
        exit = findViewById(R.id.exit);
        inventory = findViewById(R.id.inventory);
        shops = findViewById(R.id.shops);
        tutorial = findViewById(R.id.tutorial);
        about = findViewById(R.id.about);
        settings = findViewById(R.id.settings);
        support = findViewById(R.id.support);
        network_status = findViewById(R.id.network_status);
        network_status_img = findViewById(R.id.network_status_img);
        ticket = findViewById(R.id.ticket);
        auditoria = findViewById(R.id.auditoria);
        userName = findViewById(R.id.user_name);
        userEmail = findViewById(R.id.user_email);
        userImage = findViewById(R.id.imgProfile);
        emptyBox = findViewById(R.id.emptybox);
        trash = findViewById(R.id.deleted);
        userLocation = findViewById(R.id.userLocation);

        editTextSerach = findViewById(R.id.editTextSerach);
        calendar_btn = findViewById(R.id.calendar_btn);
        calendarHolder = findViewById(R.id.calendarHolder);
        textViewAppVersion = findViewById(R.id.app_version);
//        refresh = findViewById(R.id.refresh);
        animationEmptyBox = findViewById(R.id.animationEmptyBox);
        mainUI = findViewById(R.id.mainUI);
        //endregion

        //region setClick
        topMenu.setOnClickListener(this);
        update.setOnClickListener(this);
        exit.setOnClickListener(this);
        inventory.setOnClickListener(this);
        support.setOnClickListener(this);
        settings.setOnClickListener(this);
        about.setOnClickListener(this);
        shops.setOnClickListener(this);
        tutorial.setOnClickListener(this);
        auditoria.setOnClickListener(this);
        ticket.setOnClickListener(this);
        userImage.setOnClickListener(this);
        editTextSerach.addTextChangedListener(this);
        editTextSerach.setOnKeyListener(this);
        editTextSerach.setOnEditorActionListener(this);
        calendarHolder.setOnClickListener(this);
        trash.setOnClickListener(this);
        userLocation.setOnClickListener(this);
        network_status.setOnClickListener(this);
//        refresh.setOnRefreshListener(this);
        //endregion

        //region instances
        asyncTasks = new ArrayList<>();
        recyclerData = new ArrayList<>();
        nw = new NetWorkStatus(this);
        //endregion

        loadMVP_variables();

        surveyReverseArray = new ReverseArray<>();
        presenterBasics = new ArrayList<>();

        permissionPresenter.CheckStoragePermission();
        permissionPresenter.CheckLocationPermission();
        initial_dialog();

        setupRecycler();

        setupNetWorkView();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                network_status.performClick();
            }
        }, 1000);

        swipeDetector = new SwipeDetector();
        swipeDetector.setSwipeListener(new SwipeDetector.SwipeListener() {
            @Override
            public void onLeftToRight() {
                drawer.openDrawer(Gravity.LEFT);
            }
        });
        gestureDetector = new GestureDetector(swipeDetector);

        drawer.addDrawerListener(this);

    }

    private void startTutorial() {
        SimpleTarget first =
                new SimpleTarget.Builder(this).setPoint(calendar_btn)
                        .setRadius(200f)
                        .setTitle("Calendar")
                        .setDescription("You can filter results with date with this button")
                        .build();
        SimpleTarget second =
                new SimpleTarget.Builder(this).setPoint(emptyBox)
                        .setRadius(200f)
                        .setTitle("Result section")
                        .setDescription("Here you can see your results as sent or draft")
                        .build();
        SimpleTarget third =
                new SimpleTarget.Builder(this).setPoint(network_status)
                        .setRadius(200f)
                        .setTitle("Network status")
                        .setDescription("Here you can see if you are connected to any network or not (for sync or update data you need to be connected)")
                        .build();
        SimpleTarget forth =
                new SimpleTarget.Builder(this).setPoint(findViewById(R.id.search_linear))
                        .setRadius(200f)
                        .setTitle("Search")
                        .setDescription("Here you can search in results by checklist name or shop name")
                        .build();

        int[] twoLocation = new int[2];
        menu.getLocationInWindow(twoLocation);
        PointF point =
                new PointF(twoLocation[0] + menu.getWidth() / 2f, twoLocation[1] + menu.getHeight() / 2f);
        SimpleTarget fifth = new SimpleTarget.Builder(ActivityMain.this).setPoint(point)
                .setRadius(80f)
                .setTitle("FAB")
                .setDescription("You can choose which type of survey you want to submit")
                .setOnSpotlightStartedListener(new OnTargetStateChangedListener<SimpleTarget>() {
                    @Override
                    public void onStarted(SimpleTarget target) {

                    }

                    @Override
                    public void onEnded(SimpleTarget target) {
                        menu.open(true);
                    }
                })
                .build();

        SimpleTarget sixth = new SimpleTarget.Builder(ActivityMain.this).setPoint(point)
                .setRadius(80f)
                .setTitle("Types")
                .setDescription("By pressing one of types you can load shop then survey to submit")
                .setOnSpotlightStartedListener(new OnTargetStateChangedListener<SimpleTarget>() {
                    @Override
                    public void onStarted(SimpleTarget target) {

                    }

                    @Override
                    public void onEnded(SimpleTarget target) {
                        drawer.openDrawer(Gravity.LEFT);
                    }
                })
                .build();

        SimpleTarget seventh =
                new SimpleTarget.Builder(this).setPoint(findViewById(R.id.imgInventory))
                        .setRadius(200f)
                        .setTitle(getString(R.string.check_list))
                        .setDescription("You can see your result in this section")
                        .build();
        SimpleTarget eighth =
                new SimpleTarget.Builder(this).setPoint(findViewById(R.id.imgUpdate))
                        .setRadius(200f)
                        .setTitle(getString(R.string.update))
                        .setDescription("You can update your data with web changes (App  automaticly updates if any change happens in web)")
                        .build();
        SimpleTarget ninth =
                new SimpleTarget.Builder(this).setPoint(findViewById(R.id.imgSettings))
                        .setRadius(200f)
                        .setTitle(getString(R.string.setting))
                        .setDescription("You can change your password or profile picture here")
                        .build();
        SimpleTarget tenth =
                new SimpleTarget.Builder(this).setPoint(findViewById(R.id.imgShops))
                        .setRadius(200f)
                        .setTitle(getString(R.string.fragment_shop_title))
                        .setDescription("You can see all shops that assigned to you (You can make sure that you have the shop you want or not here)")
                        .build();
        SimpleTarget eleventh =
                new SimpleTarget.Builder(this).setPoint(findViewById(R.id.imgAbout))
                        .setRadius(200f)
                        .setTitle(getString(R.string.about))
                        .setDescription("Here we are")
                        .build();
        SimpleTarget twelwth =
                new SimpleTarget.Builder(this).setPoint(findViewById(R.id.imgTrash))
                        .setRadius(200f)
                        .setTitle(getString(R.string.deleted))
                        .setDescription("When you delete item will appear in this section you can delete items here (When you delete items in here you can not get them back anymore)")
                        .build();
        SimpleTarget thirteenth =
                new SimpleTarget.Builder(this).setPoint(findViewById(R.id.imgExit))
                        .setRadius(200f)
                        .setTitle(getString(R.string.log_out))
                        .setDescription("Log out from your account")
                        .build();

        Spotlight.with(this)
                .setDuration(1L)
                .setAnimation(new DecelerateInterpolator(2f))
                .setTargets(first, second, third, forth, fifth, sixth, seventh, eighth, ninth, tenth, eleventh, twelwth, thirteenth)
                .setOnSpotlightStartedListener(new OnSpotlightStartedListener() {
                    @Override
                    public void onStarted() {
//                        Toast.makeText(ActivityMain.this, "spotlight is started", Toast.LENGTH_SHORT)
//                                .show();
                    }
                })
                .setOnSpotlightEndedListener(new OnSpotlightEndedListener() {
                    @Override
                    public void onEnded() {
//                        Toast.makeText(ActivityMain.this, "spotlight is ended", Toast.LENGTH_SHORT).show();
                    }
                })
                .start();
    }


    private void clearMVP_variables() {
        controllerPresenter = null;
        apiService = null;
        //========================================
        shopPresenter = null;
        shop = null;
        //=====================================================
        checkListPresenter = null;
        checklist = null;
        //=======================================================
        opticoPresenter = null;
        optico = null;
        //====================================================
        accessoryPresenter = null;
        accessory = null;
        //================================================
        layoutPresenter = null;
        layout = null;
        //==============================================
        categoryPresenter = null;
        category = null;
        //============================================
//        permission = null;
//        permissionPresenter = null;
        //==============================================
        userChecklistPresenter = null;
        userCheckList = null;
        //============================================
//        mainItemPresenter = null;
//        mainItemModel = null;
        //===============================================
//        presenterAppVersion = null;
//        modelAppVersion = null;
        //==============================================
//        this.versionPresenter = null;
        //===============================================
//        mainPresenter = null;
//        mainModel = null;
        //==============================================
        productPresenter = null;
        product = null;

    }

    private void loadMVP_variables() {
        //region presenter
        controllerPresenter = new UpdateParamsControllerPresenter();
        controllerPresenter.attachView(this);
        apiService = new ApiService(this);
        controllerPresenter.addModel(apiService);
        //========================================
        shopPresenter = new ShopPresenter();
        shop = new Shop();
        shopPresenter.addModel(shop);
        shopPresenter.attachView(this);
        //=====================================================
        checkListPresenter = new CheckListPresenter();
        checkListPresenter.attachView(this);
        checklist = new Checklist();
        checkListPresenter.addModel(checklist);
        //=======================================================
        opticoPresenter = new OpticoPresenter();
        opticoPresenter.attachView(this);
        optico = new Optico();
        opticoPresenter.addModel(optico);
        //====================================================
        accessoryPresenter = new AccessoryPresenter();
        accessoryPresenter.attachView(this);
        accessory = new Accessory();
        accessoryPresenter.addModel(accessory);
        //================================================
        layoutPresenter = new LayoutPresenter();
        layoutPresenter.attachView(this);
        layout = new Layout();
        layoutPresenter.addModel(layout);
        //==============================================
        categoryPresenter = new CategoryPresenter();
        categoryPresenter.attachView(this);
        category = new Category();
        categoryPresenter.addModel(category);
        //============================================
        permission = new Permission(this);
        permissionPresenter = new PermissionPresenter();
        permissionPresenter.attachView(this);
        permissionPresenter.addModel(permission);
        //==============================================
        userChecklistPresenter = new UserChecklistPresenter();
        userChecklistPresenter.attachView(this);
        userCheckList = new UserCheckList();
        userChecklistPresenter.addModel(userCheckList);
        //============================================
        mainItemPresenter = new MainItemPresenter();
        mainItemModel = new MainItemModel();
        mainItemPresenter.attachView(this);
        mainItemPresenter.addModel(new MainItemModel());
        //===============================================
        presenterAppVersion = new PresenterAppVersion();
        modelAppVersion = new ModelAppVersion();
        presenterAppVersion.addModel(modelAppVersion);
        presenterAppVersion.attachView(this);
        presenterAppVersion.getVersionAppFromServer();
        //==============================================
        this.versionPresenter = new VersionPresenter(this, new Version());
        //===============================================
        mainPresenter = new ActivityMainPresenter();
        mainModel = ActivityMainModel.newInstance();
        mainPresenter.addModel(mainModel);
        mainPresenter.attachView(this);
        //==============================================
        productPresenter = new ProductPresenter();
        product = new Product();
        productPresenter.addModel(product);
        productPresenter.attachView(this);
        //endregion
    }

    private void getCheckListError(Bundle extras) {
        if (extras != null) {
            String err = extras.getString(ActivityCheckList.CheckListError);
            showToast(err);
        }
    }

    private void setupNetWorkView() {

        network_status_img.setImageDrawable(getDrawable(R.drawable.ic_signal_cellular_off_black_24dp));
        makeMeBlink(network_status, 1000, 20);
    }


    //region permission
    @Override
    public void StoragePermission(boolean status) {
        isStoragePermitted = status;
        if (status)
            createAppFolder();
        else
            permissionPresenter.getStoragePermission();
    }

    @Override
    public void LocationPermission(boolean status) {
        isLocationPermitted = status;
        if (status) {
            EasyLocationProvider easyLocationProvider = new EasyLocationProvider.Builder(ActivityMain.this)
                    .setInterval(5000)
                    .setFastestInterval(2000)
                    .setListener(new EasyLocationProvider.EasyLocationCallback() {
                        @Override
                        public void onGoogleAPIClient(GoogleApiClient googleApiClient, String message) {
                            Log.i(TAG, "onGoogleAPIClient: " + message);
                        }

                        @Override
                        public void onLocationUpdated(double latitude, double longitude) {
                            Log.i(TAG, "onLocationUpdated: " + latitude + " - " + longitude);
                        }

                        @Override
                        public void onLocationUpdateRemoved() {
                            Log.i(TAG, "onLocationUpdateRemoved: ");
                        }

                        @Override
                        public void onLocationRecieved(double lat, double latLng) {
                            Log.i(TAG, "onLocationRecieved: " + lat + " ---- " + latLng);
                        }
                    }).build();
            getLifecycle().addObserver(easyLocationProvider);
            GPSTracker.getInstance(this, this).getCurrentLocation();
        }
    }

    @Override
    public void CameraPermission(boolean status) {

    }

    @Override
    public void ReadStoragePermission(boolean status) {

    }
    //endregion

    //region version check
    @Override
    public void onVersionChanged() {
        if (isStoragePermitted) {
            if (!isUpdateDataInProccess) {
                initial_dialog();
                isUpdateDataInProccess = true;
                if (!isAnyItemIsProcessing())
                    controllerPresenter.getDBsDataFromServer(isConnected);
            }
        } else {
            permissionPresenter.getStoragePermission();
        }
    }

    @Override
    public void ServerVersion(String version) {

    }

    @Override
    public void onDeleteVersion() {

    }

    @Override
    public void onCantDeleteVersion() {

    }
    //endregion


    @Override
    protected void onStart() {
        super.onStart();

//        for (int i = 0; i < forceClosedItems.size(); i++) {
//            UserCheckList userCheckList = new UserCheckList().fetchById(forceClosedItems.get(i));
//            if (userCheckList.isSynced() == 0) {
//                userCheckList.setProccessing(1);
//                userCheckList.update(userCheckList);
//                Log.i(TAG, "onStart: changed to 1 id = " + forceClosedItems.get(i));
//            }
//        }
//        for (int i = 0; i < forcedClosedPics.size(); i++) {
//            ResultPicture resultPicture = new ResultPicture().fetchById(forcedClosedPics.get(i));
//            if (resultPicture.isSynced() == 0) {
//                resultPicture.setProccessing(1);
//                resultPicture.update(resultPicture);
//                Log.i(TAG, "onStart: changed pic to 1 id = " + forcedClosedPics.get(i));
//            }
//        }
//        ArrayList<ResultPicture> temp = new ResultPicture().getAllItems();
//        ArrayList<UserCheckList> tempp = new UserCheckList().getAllItems();
//        forceClosedItems.clear();
//        forcedClosedPics.clear();

    }

    @Override
    protected void onStop() {
//        Log.i(TAG, "onStop: ");
//        ArrayList<UserCheckList> inProccessItems = getNotSyncedInProcessItems();
//        for (int i = 0; i < inProccessItems.size(); i++) {
//            long id = inProccessItems.get(i).get_ID();
//            UserCheckList userCheckList = new UserCheckList().fetchById(id);
//            userCheckList.setProccessing(0);
//            userCheckList.update(userCheckList);
//            forceClosedItems.add(id);
//            Log.i(TAG, "onStop: changed to 0 id = " + userCheckList.getDate() + " -- " + userCheckList.getTime());
//        }
//        ArrayList<ResultPicture> resultPictures = getNotSyncedInProccessPics();
//        for (int i = 0; i < resultPictures.size(); i++) {
//            long id = resultPictures.get(i).get_ID();
//            ResultPicture resultPicture = new ResultPicture().fetchById(id);
//            resultPicture.setProccessing(0);
//            resultPicture.update(resultPicture);
//            forcedClosedPics.add(id);
//            Log.i(TAG, "onStop: changed pic to 0 id = " + resultPicture.getServer_id());
//        }
//
//        ArrayList<ResultPicture> temp = new ResultPicture().getAllItems();
//        ArrayList<UserCheckList> tempp = new UserCheckList().getAllItems();
        super.onStop();
    }

    private ArrayList<UserCheckList> getNotSyncedInProcessItems() {
        ArrayList<UserCheckList> temp = new UserCheckList().getNotSyncedInProcess();
        return temp;
    }

    private ArrayList<ResultPicture> getNotSyncedInProccessPics() {
        ArrayList<ResultPicture> temp = new ResultPicture().getNotSyncedInProccess();
        return temp;
    }

    @Override
    protected void onDestroy() {
        Log.i(TAG, "onDestroy: ");

        super.onDestroy();
    }

    //region server
    @Override
    public void Shops(JSONArray shops) {
        controllerPresenter.increamentItemCount();
        shopsJSON = shops;
        startNext(0);
        itemCountByName.put(Config.Params.SHOP, shops.length());
//        shopPresenter.Insert(shops);
//        asyncTasks.add(new Update(updateModel.SHOP, shops).execute(""));
    }

    @Override
    public void Categories(JSONArray categories) {
        categoriesJSON = categories;
        controllerPresenter.increamentItemCount();
        itemCountByName.put(Config.Params.CATEGORY, categories.length());
//        categoryPresenter.Insert(categories);
//        asyncTasks.add(new Update(updateModel.CATEGORY, categories).execute(""));
    }

    @Override
    public void CheckLists(JSONArray checklists) {
        controllerPresenter.increamentItemCount();
        checklistsJSON = checklists;
        itemCountByName.put(Config.Params.CHECKLIST, checklists.length());
//        Toast.makeText(ActivityMain.this, checklists.length()+"", Toast.LENGTH_SHORT).show();
//        checkListPresenter.Insert(checklists);
//        asyncTasks.add(new Update(updateModel.CHECKLIST, checklists).execute(""));

    }

    @Override
    public void Opticos(JSONArray opticos) {
        opticosJSON = opticos;
        controllerPresenter.increamentItemCount();
        itemCountByName.put(Config.Params.OPTICO, opticos.length());
//        opticoPresenter.Insert(opticos);
//        asyncTasks.add(new Update(updateModel.OPTICO, opticos).execute(""));
    }

    public void Accessories(JSONArray accessories) {
        controllerPresenter.increamentItemCount();
        accessoriesJSON = accessories;
        itemCountByName.put(Config.Params.ACCESSORY, accessories.length());
//        accessoryPresenter.Insert(accessories);
//        asyncTasks.add(new Update(updateModel.ACCESSORY, accessories).execute(""));
    }

    @Override
    public void Layouts(JSONArray layouts) {
        controllerPresenter.increamentItemCount();
        layoutsJSON = layouts;
        itemCountByName.put(Config.Params.LAYOUT, layouts.length());
//        layoutPresenter.Insert(layouts);
//        asyncTasks.add(new Update(updateModel.LAYOUT, layouts).execute(""));
    }

    @Override
    public void Products(JSONArray productsdb) {
        controllerPresenter.increamentItemCount();
        productsJSON = productsdb;
        itemCountByName.put(Config.Params.PRODUCT, productsdb.length());
//        productPresenter.Insert(productsJSON);
//        asyncTasks.add(new Update(updateModel.PRODUCT, productsdb).execute(""));
    }

    private void startNext(int x) {
        switch (x) {
            case 0:
                if (shopsJSON != null) {
                    shopPresenter.Insert(shopsJSON);
                    shopsJSON = null;
                } else {
                    startNext(x + 1);
                }
                break;
            case 1:
                if (checklistsJSON != null) {
                    checkListPresenter.Insert(checklistsJSON);
                    checklistsJSON = null;
                } else {
                    startNext(x + 1);
                }
                break;
            case 2:
                if (categoriesJSON != null) {
                    categoryPresenter.Insert(categoriesJSON);
                    categoriesJSON = null;
                } else {
                    startNext(x + 1);
                }
                break;
            case 3:
                if (opticosJSON != null) {
                    opticoPresenter.Insert(opticosJSON);
                    opticosJSON = null;
                } else {
                    startNext(x + 1);
                }
                break;
            case 4:
                if (layoutsJSON != null) {
                    layoutPresenter.Insert(layoutsJSON);
                    layoutsJSON = null;
                } else {
                    startNext(x + 1);
                }
                break;
            case 5:
                if (accessoriesJSON != null) {
                    accessoryPresenter.Insert(accessoriesJSON);
                    accessoriesJSON = null;
                } else {
                    startNext(x + 1);
                }
                break;
            case 6:
                if (productsJSON != null) {
                    productPresenter.Insert(productsJSON);
                    productsJSON = null;
                } else {
                    startNext(x + 1);
                }
                break;
        }
    }

    @Override
    public void onItemRefteshed(int numberOfRefreshedTable, int totalNumberOfTables, String refreshedItemName) {
//        int progrss = (numberOfRefreshedTable * 100) / totalNumberOfTables;
//        updateProgressDialogProgressAndText(progrss, numberOfRefreshedTable, totalNumberOfTables, refreshedItemName);
    }

    @Override
    public void AllItemsCounts(int count) {
        this.allItemsCount = count;
    }

    private void updateProgressDialogProgressAndText(final double progrss, final double numberOfRefreshedTable, final int totalNumberOfTables, final String refreshedItemName) {
        if (paramsDialogProgress != null
                && paramsDialogRefreshed != null
                && paramsDialogTotal != null) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    paramsDialogServerProgress.setVisibility(View.INVISIBLE);
                    paramsDialogProgress.setVisibility(View.VISIBLE);
                    paramsDialogProgress.setProgress((int) progrss);
                    paramsDialogTotal.setText(totalNumberOfTables + "");
                    paramsDialogRefreshed.setText(String.format("%.2f", progrss));
                }
            });
        }
    }

    private String getTraslatedStringByTableName(String refreshedItemName) {
        if (refreshedItemName.equals("Optico"))
            return "Ópticos";
        if (refreshedItemName.equals("accessory"))
            return "Accesorios";
        if (refreshedItemName.equals("category"))
            return "Categorías";
        if (refreshedItemName.equals("shop"))
            return "Tiendas";
        if (refreshedItemName.equals("Product"))
            return "Productos";
        if (refreshedItemName.equals("checklist"))
            return "Checklist";
        if (refreshedItemName.equals("layout"))
            return "Layouts";
        return "";
    }

    @Override
    public void onError(final String error) {
        if (Objects.equals(error, getString(R.string.no_network))) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(ActivityMain.this, error, Toast.LENGTH_LONG).show();
                }
            });
        }

        dismissDialog(error);
    }

    @Override
    public void showDialog() {
        startTimeOut();
        InitializeParamsDialog();
        showDialogHanlder(paramsDialog);
        isUpdateDataInProccess = true;

    }

    @Override
    public void dismissDialog() {

    }

    private void startTimeOut() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                dismissDialogHandler(paramsDialog);
                paramsDialog = null;
            }
        }, 1000 * 60 * 5);
    }

    @Override
    public void dismissDialog(String source) {
        dismissDialogHandler(paramsDialog);
        paramsDialog = null;
        isUpdateDataInProccess = false;
        insertedItemsCount = 0;
//        updateItems();
//        clearMVP_variables();
    }

    @Override
    public void onSuccessGetParams() {

    }

    @Override
    public void allTableRefresh() {
        this.insertedItemsCount = 0;
        this.allItemsCount = 0;
        itemCountByName.clear();
        insertedItemCountByName.clear();
        new Handler(getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                dismissDialog("ok");
            }
        }, 300);
    }


    //endregion

    //region shops
    @Override
    public void ShopInserted(boolean status) {
        controllerPresenter.checkRefreshingTables(status, "shop");
        startNext(1);
    }

    @Override
    public void ShopsByCurrentLocation(ArrayList<Shop> shops) {

    }

    @Override
    public void NoShopsAround(String error) {

    }

    @Override
    public void ShopById(Shop shop) {
        Log.i(TAG, "shop= " + shop);
    }

    @Override
    public void AllShops(List<Shop> shops) {
        Log.i(TAG, "AllShops: " + shops);
        //Toast.makeText(this,shops.size()+" shops saved",Toast.LENGTH_LONG).show();
    }

    @Override
    public void LocatedShops(List<Shop> list) {
        showToast(list.size() + "");
    }

    @Override
    public void LocatedShopsubCanalShops(List<Shop> list) {

    }
    //endregion

    //region checklist

    public void CheckListInserted(boolean status) {
        controllerPresenter.checkRefreshingTables(status, "checklist");
        startNext(2);
    }

    public void CheckLsits(List<Checklist> list) {
        Log.i(TAG, "CheckLsits: " + list);
    }

    public void Checklist(Checklist checklist) {

    }

    public void TypeCheckList(ArrayList<Checklist> arrayList) {

    }

    @Override
    public void NoCheckListWithThisType(String error) {

    }

    @Override
    public void CheckListByTypeAndSubCanal(ArrayList<Checklist> checkLists) {

    }

    //endregion

    //region optico
    @Override
    public void OpticoIserted(boolean status) {
        controllerPresenter.checkRefreshingTables(status, "Optico");
        startNext(4);
    }

    @Override
    public void Opticos(List<Optico> opticoDBS) {

        Log.i(TAG, "Opticos: " + opticoDBS);
    }

    @Override
    public void OpticoById(Optico optico) {

    }

    @Override
    public void OpticosByShop(List<Optico> list) {

    }

    @Override
    public void OpticosByCondition(List<Optico> list) {

    }

    //endregion

    //region accessoty
    @Override
    public void accessoryIserted(boolean status) {
        controllerPresenter.checkRefreshingTables(status, "accessory");
        startNext(6);

    }

    @Override
    public void onItemInserted(String name) {
        setItemProgress(name);
        allItemsCount++;
        insertedItemsCount++;
        if (allItemsCount != 0) {
            double progrss = (insertedItemsCount * 100) / allItemsCount;
            updateProgressDialogProgressAndText(progrss, insertedItemsCount, 100, name);
            Log.i(TAG, "onItemInserted: " + name + " -> " + insertedItemsCount + " % ");
        } else {
            dismissDialogHandler(paramsDialog);
        }
    }

    private void setItemProgress(final String name) {
        int lastInsertedItemCount = 0;
        if (insertedItemCountByName.get(name) != null) {
            lastInsertedItemCount = insertedItemCountByName.get(name);
        }
        lastInsertedItemCount++;
        insertedItemCountByName.put(name, lastInsertedItemCount);

        int totalCount = itemCountByName.get(name) == null ? 0 : itemCountByName.get(name);
        final int progress = (lastInsertedItemCount * 100) / totalCount;

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                paramsDialogItemNameTxt.setText(name);
                paramsDialogItemInsertedProgress.setProgress(progress);
                paramsDialogItemProgressTxt.setText(progress + "");
            }
        });


    }

    @Override
    public void accessories(List<Accessory> list) {
        Log.i(TAG, "accessories: " + list);
    }

    @Override
    public void accessoriesById(Accessory accessory) {

    }

    @Override
    public void accessoriesByShop(List<Accessory> list) {

    }

    @Override
    public void accessoriesByCondition(List<Accessory> list) {

    }

    //endregion

    //region layouts
    @Override
    public void LayoutInserted(boolean status) {
        controllerPresenter.checkRefreshingTables(status, "layout");
        layoutPresenter.getLayouts();
        startNext(5);
    }

    @Override
    public void Layouts(List<Layout> list) {
        Log.i(TAG, "Layouts: " + list);
    }

    @Override
    public void LayoutsByShop(ArrayList<Layout> arrayList) {

    }

    @Override
    public void LayoutById(Layout layout) {

    }

    //endregion

    //region category

    @Override
    public void CategoryInserted(boolean status) {
        controllerPresenter.checkRefreshingTables(status, "category");
        startNext(3);
//        categoryPresenter.getCategories();
    }


    @Override
    public void Categories(List<Category> categoriesDBS) {
        Log.i(TAG, "Categories: " + categoriesDBS);
    }

    @Override
    public void CategoryById(Category category) {

    }

    @Override
    public void CategoryByValue(Category category) {

    }

    //endregion

    //region check list items

    @Override
    public void CheckListDataInserted(long id) {

    }

    @Override
    public void CheckListDataNotInserted(String err) {
        showToast(err);
    }

    @Override
    public void CheckListItemsByUserAndDate(ArrayList<UserCheckList> userCheckLists) {

        recyclerData.clear();
        ArrayList<UserCheckList> datas = surveyReverseArray.reverseArray(userCheckLists);
        this.recyclerData.addAll(datas);
        updateItems();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                emptyBox.setVisibility(View.GONE);
//                refresh.setRefreshing(false);
            }
        });

    }


    @Override
    public void CheckListDataItemsEmpty() {
        recyclerData.clear();
        updateItems();
        Log.i(TAG, "CheckListDataItemsEmpty: ");
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
//                refresh.setRefreshing(false);
                emptyBox.setVisibility(View.VISIBLE);
                animationEmptyBox.playAnimation();
            }
        });
    }

    @Override
    public void CheckListById(UserCheckList userCheckList) {

    }

    @Override
    public void CheckListNotFound() {

    }

    @Override
    public void CheckListSynced() {

    }

    @Override
    public void CheckListNotSynced() {

    }

    @Override
    public void CheckListDataAndPictures(UserCheckList userCheckList, ArrayList<PicturePickerItemModel> pics) {

    }

    @Override
    public void NoCheckLisAndPictures() {

    }

    @Override
    public void NoDeletedItem() {

    }

    @Override
    public void onDeletedItemsRecieved(ArrayList<UserCheckList> results) {

    }

    @Override
    public void allDeletedsRemoved() {

    }
    //endregion

    //region sync
    @Override
    public void onItemSynced(ItemQueueModel itemQueueModel) {
//        userChecklistPresenter.getCheckListItemsByUserAndDate(getUser(ActivityMain.this), choosenDate);
//        calendar.setText(choosenDate);
    }

    @Override
    public void onItemFailedToSync(ItemQueueModel itemQueueModel, String error) {
//        updateItems();
        showToast(getString(R.string.errorHandlingMessage));
    }

    @Override
    public void listChange(List<UserCheckList> list) {
        recyclerData.clear();
        ArrayList<UserCheckList> reverseList = new ArrayList<>();
        reverseList.addAll(list);
        reverseList = surveyReverseArray.reverseArray(reverseList);
        recyclerData.addAll(reverseList);
    }

    @Override
    public void onSearchFinish() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (adapter != null) {
                    disableScroll();
                    adapter.notifyDataSetChanged();
                    if (recyclerData.size() == 0) {
                        emptyBox.setVisibility(View.VISIBLE);
                    } else {
                        emptyBox.setVisibility(View.GONE);
                    }
                }
                enableScroll();
            }
        });

    }

    @Override
    public void onSearchStart() {
        disableScroll();
    }

    @Override
    public void updateRecyclerForSyncAnimation(final ItemQueueModel itemQueueModel, final boolean isProccessing) {

//        final int position = getPositionFromItem(itemQueueModel, isProccessing);
//        if (position != -1) {
//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    if (adapter != null) {
//                        adapter.notifyItemChanged(position);
//                    }
//                }
//            });
//        }

//        final int position = getPositionFromItem(itemQueueModel, isProccessing);
//        if (position != -1) {
//            Handler handler = new Handler();
//
//            final Runnable r = new Runnable() {
//                public void run() {
//                    adapter.notifyItemChanged(position);
//                }
//            };
//
//            handler.post(r);
//        }

//        runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//                if (isProccessing) {
//                    RotateAnimation syncAnimation = new RotateAnimation(ROTATE_FROM, ROTATE_TO,
//                            Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
//                    syncAnimation.setDuration(1000 * 5);
//                    syncAnimation.setRepeatCount(Animation.INFINITE);
//                    syncAnimation.setRepeatMode(Animation.INFINITE);
//                    itemQueueModel.getHolder().statusImg.setAnimation(syncAnimation);
//                    syncAnimation.reset();
//                    syncAnimation.start();
//                }else {
//                    itemQueueModel.getHolder().statusImg.clearAnimation();
//                }
//            }
//        });

    }

//    private int getPositionFromItem(ItemQueueModel itemQueueModel, boolean isProccessing) {
//        int position = -1;
//        for (int i = 0; i < recyclerData.size(); i++) {
//            UserCheckList item = recyclerData.get(i);
//            item.setProccessing(isProccessing);
//            if (item.getId() == itemQueueModel.getId()) {
//                position = i;
//                break;
//            }
//        }
//        return position;
//    }

    @Override
    public void message(final String msg) {
//        ActivityMain.this.runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//                Toast.makeText(ActivityMain.this, msg
//                        , Toast.LENGTH_SHORT).show();
//            }
//        });
    }

    //endregion


    @Override
    public void onItemClicked(boolean isDraft, boolean isSynced, long checkListServerId
            , long checkListDataId, String shopId, String shopName, String checkListName) {
        if (isSynced || isDraft) {
            Intent intent = new Intent(ActivityMain.this
                    , ActivityCheckList.class);
            intent.putExtra(IsDraft, isDraft);
            intent.putExtra(IsCheckList, false);
            intent.putExtra(ActivityCheckList.CheckListServerId, checkListServerId);
            intent.putExtra(ActivityCheckList.CheckListDataDataBaseId, checkListDataId + "");
            intent.putExtra(ActivityCheckList.CheckListDataBaseId, 0);
            intent.putExtra(ActivityCheckList.ShopId, shopId);
            intent.putExtra(ActivityCheckList.CheckListName, checkListName);
            intent.putExtra(ActivityCheckList.ShopName, shopName);
            startActivityForResult(intent, OPENED_CHECKLIST_KEY);
        }
    }

    @Override
    public void onItemLongCicked(String Error, long id, int position, ResultHolder holder) {

        AlertDialog.Builder builder = InitializeDetailDialog(Error, id, position, holder);
        detailAlert = builder.create();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                detailAlert.show();
            }
        });

    }

    @Override
    public void removeItem(long id) {
        showRemoveItemDialog(id);
    }

    @Override
    public void innnerUpdateStart() {
//        disableScroll();
    }

    @Override
    public void updateRow(final int position, final long id) {
//        changeData(id);
//        runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//                if (recyclerView.getAdapter() != null){
//                    recyclerView.getAdapter().notifyItemChanged(position);
//                }
//            }
//        });
    }

    private void changeData(long id) {
        for (int i = 0; i < recyclerData.size(); i++) {
            if (recyclerData.get(i).get_ID() == id) {
                UserCheckList userCheckList = recyclerData.get(i);
                userCheckList.setSynced(1);
                userCheckList.setPicsSynced(1);
                userCheckList.setProccessing(0);
                recyclerData.set(i, userCheckList);
            }
        }
    }


    private void showRemoveItemDialog(final long id) {
        AlertDialog.Builder builder = new AlertDialog.Builder(ActivityMain.this);
        LayoutInflater inflater = getLayoutInflater();
        builder.setCancelable(false);
        View view = inflater.inflate(R.layout.layout_remove_row_alert, drawer, false);
        TextView no = view.findViewById(R.id.no);
        TextView delete = view.findViewById(R.id.delete);

        builder.setView(view);

        final AlertDialog alertDialog = builder.create();
        alertDialog.show();


        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendDataLog("Remove result item", "No");
                alertDialog.dismiss();
//                refresh.setRefreshing(true);
                adapter.setIsSyncUpdate(false);
                userChecklistPresenter.getCheckListItemsByUserAndDate(getUser(ActivityMain.this)
                        , choosenDate);
                calendar_btn.setText(getDateText(choosenDate));
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendDataLog("Remove result item", "Remove");
                UserCheckList userCheckList = new UserCheckList().fetchById(id);
                userCheckList.setDeleted(1);
                userCheckList.update(userCheckList);
//                refresh.setRefreshing(true);
                adapter.setIsSyncUpdate(false);
                userChecklistPresenter.getCheckListItemsByUserAndDate(getUser(ActivityMain.this)
                        , choosenDate);

                alertDialog.dismiss();

            }
        });
    }

    private void remove_items_pics(long id) {

    }

    private void InitializeParamsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View v = LayoutInflater.from(this).inflate(R.layout.layout_get_params_dialog, drawer, false);
        builder.setView(v);
        builder.setCancelable(false);

        paramsDialogProgress = v.findViewById(R.id.refreshProgress);
        paramsDialogTotal = v.findViewById(R.id.totalRefreshCount);
        paramsDialogRefreshed = v.findViewById(R.id.refreshedCountTxt);
        paramsDialogServerProgress = v.findViewById(R.id.serverDataProgress);
        paramsDialogItemInsertedProgress = v.findViewById(R.id.itemProgress);
        paramsDialogItemProgressTxt = v.findViewById(R.id.itemProgressTxt);
        paramsDialogItemNameTxt = v.findViewById(R.id.itemName);

        paramsDialog = builder.create();

    }

    private AlertDialog.Builder InitializeDetailDialog(String error, final long id, final int position, final ResultHolder holder) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = LayoutInflater.from(this).inflate(R.layout.layout_alert_resend_and_information, drawer, false);
        builder.setView(view);
        TextView resultIdTxt = view.findViewById(R.id.resultIdTxt);
        TextView resultStatusTxt = view.findViewById(R.id.resultStatusTxt);
        TextView resultPicturesCountTxt = view.findViewById(R.id.picturesCountTxt);
        TextView uploadedPicturesCountTxt = view.findViewById(R.id.sycnedPicturesCountTxt);
        LinearLayout errorLogLinear = view.findViewById(R.id.errorLogLinear);
        TextView errorLogTxt = view.findViewById(R.id.errorLogTxt);
        Button cancelBtn = view.findViewById(R.id.cancelBtn);
        Button resendBtn = view.findViewById(R.id.resendBtn);
        TextView answerCountTxt = view.findViewById(R.id.answerCountTxt);
        resultIdTxt.setText(getResultIdFromCehcklistWithId(id));
        resultStatusTxt.setText(getResultStatusFromId(id));
        resultPicturesCountTxt.setText(getResultPicturesCountWithResultId(id));
        uploadedPicturesCountTxt.setText(getResultPictureCountSyncedWithResultID(id));
        answerCountTxt.setText(getAnswerCountWithId(id));

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendDataLog("Result detail dialog", "Cancel");
                if (detailAlert != null) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            detailAlert.dismiss();
                        }
                    });
                }
            }
        });
        resendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendDataLog("Result detail dialog", "Resend");
                resendData(id, position, holder);
                if (detailAlert != null) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            detailAlert.dismiss();
                        }
                    });


                }
            }
        });
//        builder.setPositiveButton("Volver", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                if (detailAlert != null) {
//                    runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            detailAlert.dismiss();
//                        }
//                    });
//
//
//                }
//            }
//        });
//        builder.setNegativeButton("Reenviar", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                resendData(id, position, holder);
//            }
//        });


        return builder;
    }

    private String getResultIdFromCehcklistWithId(long id) {
        double Rid = new UserCheckList().fetchById(id).getServer_id();
        int resId = (int) Rid;
        return resId + "";
    }


    private String getAnswerCountWithId(long id) {
        UserCheckList userCheckList = new UserCheckList().fetchById(id);
        JSONArray answers = new ServerJSONCleanUp(userCheckList.getAnswerJson()).cleanUpJSON();
        return answers.length() + "";
    }

    private String getResultPicturesCountWithResultId(long id) {
        int count = getItemPicturesByCheckListDataId(id).size();
        return count + "";
    }

    private String getResultPictureCountSyncedWithResultID(long id) {
        int count = getSyncedItemPicturesByCheckListDataId(id).size();
        return count + "";
    }

    private ArrayList<ResultPicture> getSyncedItemPicturesByCheckListDataId(Long id) {

        ArrayList<ResultPicture> temp = new ArrayList<>();

        List<ResultPicture> resultPictures = new ResultPicture().getAllItems();

        for (ResultPicture resultPicture : resultPictures) {

            if (resultPicture.getCheckListDataBaseId() == id && resultPicture.isSynced() == 1) {
                temp.add(resultPicture);
            }

        }

        return temp;
    }

    private ArrayList<ResultPicture> getItemPicturesByCheckListDataId(Long id) {

        ArrayList<ResultPicture> temp = new ArrayList<>();

        List<ResultPicture> resultPictures = new ResultPicture().getAllItems();

        for (ResultPicture resultPicture : resultPictures) {

            if (resultPicture.getCheckListDataBaseId() == id) {
                temp.add(resultPicture);
            }

        }

        return temp;
    }

    private String getResultStatusFromId(long id) {
        UserCheckList userCheckList = new UserCheckList().fetchById(id);
        if (userCheckList.isSynced() == 1) {
            return "Enviada";
        } else {
            return "No enviado";
        }
    }

    private void resendData(long id, int position, ResultHolder holder) {

        Log.i(TAG, "resendData: " + id);

        UserCheckList userCheckList = new UserCheckList().fetchById(id);
        userCheckList.setSynced(0);
        userCheckList.setPicsSynced(0);
        userCheckList.setProccessing(0);
        userCheckList.update(userCheckList);

        List<ResultPicture> resultPictures = new ResultPicture().getAllItems();
        for (ResultPicture resultPicture : resultPictures) {
            if (resultPicture.getCheckListDataBaseId() == id) {
                resultPicture.setSynced(0);
                resultPicture.setProccessing(0);
                resultPicture.update(resultPicture);
            }
        }

        adapter.resendItem(id, userCheckList, position, holder);

//        userChecklistPresenter.getCheckListItemsByUserAndDate(getUser(this), choosenDate);
//        calendar_btn.setText(choosenDate);

    }

    //region network handler
    @Override
    public void onConnected() {
        if (!appStarted) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    adapter.setIsSyncUpdate(true);
                    updateItems();
                }
            }, 300);

        }
        Log.i(TAG, "onConnected: ");
        if (!isNetWorkConnected) {
            isNetWorkConnected = true;
            setNetWorkStatus(true);

//            mainItemPresenter.SyncItems();
        }
    }

    private boolean isAnyItemIsProcessing() {
        ArrayList<UserCheckList> userCheckLists = new UserCheckList().getNotSyncedInProcess();
        ArrayList<ResultPicture> resultPictures = new ResultPicture().getNotSyncedInProccess();

        int allSize = resultPictures.size() + userCheckLists.size();

        return allSize != 0;
    }

    @Override
    public void onDisConnected() {
        appStarted = false;
        Log.i(TAG, "onDisConnected: ");
        if (isNetWorkConnected) {
            isNetWorkConnected = false;
            setNetWorkStatus(false);
            terminateUpdating();
        }
    }

    private void terminateUpdating() {
        for (int i = 0; i < asyncTasks.size(); i++) {
            AsyncTask asyncTask = asyncTasks.get(i);
            if (asyncTask != null)
                asyncTask.cancel(false);
        }
        isUpdateDataInProccess = false;
        dismissDialogHandler(paramsDialog);
        paramsDialog = null;

    }

    private void setNetWorkStatus(final boolean status) {
        isConnected = status;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                if (status) {
                    network_status_img.setImageDrawable(getDrawable(R.drawable.ic_signal_wifi_4_bar_black_24dp));
                    network_status.clearAnimation();
                } else {

                    network_status_img.setImageDrawable(getDrawable(R.drawable.ic_signal_wifi_off_black_24dp));
                    makeMeBlink(network_status, 1000, 20);
                }
            }
        });


    }

    private void disableScroll() {
        layoutManager.setScroll(false);
    }

    private void enableScroll() {
        layoutManager.setScroll(true);
    }


    private void updateItems() {


        if (!isUpdateDataInProccess) {
            animate_recycler_update();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (adapter != null) {
//                        disableScroll();
                        adapter.notifyDataSetChanged();
                    }
                }
            });
        }


    }

    private void animate_recycler_update() {
        AlphaAnimation aa = new AlphaAnimation(0.0f, 1.0f);
        aa.setDuration(500);
        aa.setFillAfter(true);
        aa.setFillEnabled(true);
        recyclerView.setAnimation(aa);
        aa.reset();
        aa.start();
    }


    private void makeMeBlink(View view, int duration, int offset) {
        Animation anim = new AlphaAnimation(0.0f, 1.0f);
        anim.setDuration(duration);
        anim.setStartOffset(offset);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        view.setAnimation(anim);
        view.startAnimation(anim);
        anim.start();
    }
    //endregion

    //region Logout Dialog
    private void InitializeLogoutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setMessage(getResources().getString(R.string.msg));
        builder.setPositiveButton(getResources().getString(R.string.log_out_yes), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                sendDataLog("Log out dialog", "Yes");
                mainPresenter.logout();
                versionPresenter.DeleteVersion();

            }
        });
        builder.setNegativeButton(getResources().getString(R.string.log_out_no), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                sendDataLog("Log out dialog", "No");
                mainPresenter.cancelLogout();

            }
        });

        logoutDialog = builder.create();
        logoutDialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
    }

    private void InitializeVersionAppDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_download_new_app, drawer, false);
        Button btn = view.findViewById(R.id.btnYes);
        Button btnNo = view.findViewById(R.id.btnNo);
        builder.setView(view);
        builder.setCancelable(true);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendDataLog("App new version dialog", "Yes");
                try {
                    dismissDialogHandler(dialogVersionApp);
//                    presenterAppVersion.downloadAppFromPlayStore(ActivityMain.this);
                    new ApiService(ActivityMain.this).getNewApp(ActivityMain.this, "1.1.1");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendDataLog("App new version dialog", "No");
                dismissAppVersionDialog();
            }
        });
        dialogVersionApp = builder.create();
        dialogVersionApp.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        dialogVersionApp.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    }

    private void InitializeAppDownloader() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = LayoutInflater.from(this).inflate(R.layout.layout_progress, drawer, false);
        builder.setView(view);
        downloadProgress = view.findViewById(R.id.txt);
        progressBar = view.findViewById(R.id.prgrss);
        appDownloadingDialog = builder.create();
    }

    private void setDownloadProgress(int progress) {
        if (downloadProgress != null) {
            downloadProgress.setText(progress + " %");
            progressBar.setProgress(progress);
        }
    }

    private void showProgressDialogHandler(final ProgressDialog progressDialog) {
        if (progressDialog != null) {
            if (!isFinishing()) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressDialog.show();
                    }
                });
            }
        }
    }

    private void dismissProgressDialogHandler(final ProgressDialog progressDialog) {
        if (progressDialog != null) {
            if (!isFinishing()) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressDialog.dismiss();
                    }
                });
            }
        }
    }

    private void showDialogHanlder(final AlertDialog alertDialog) {
        if (alertDialog != null) {
            if (!isFinishing()) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        alertDialog.show();
                    }
                });
            }
        }
    }

    private void dismissDialogHandler(final AlertDialog alertDialog) {
        if (alertDialog != null) {
            if (!isFinishing()) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        alertDialog.dismiss();
                    }
                });
            }
        }
    }

    private void InitializeAboutUsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View view1 = inflater.inflate(R.layout.about_layout, drawer, false);
        Button btn = view1.findViewById(R.id.btn);
        builder.setView(view1);
        builder.setCancelable(true);
        aboutUsDialog = builder.create();
        aboutUsDialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainPresenter.dismissAboutUsDialog();
            }
        });
    }

    @Override
    public void showLogoutDialog() {
        showDialogHanlder(logoutDialog);
    }

    @Override
    public void dismissLogoutDialog() {
        dismissDialogHandler(logoutDialog);
    }

    @Override
    public void sendToActivityLogin() {
        Intent i = new Intent(ActivityMain.this, ActivityLogin.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
        finish();
    }

    @Override
    public void showAboutUsDialog() {
        showDialogHanlder(aboutUsDialog);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                aboutUsDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });

    }

    @Override
    public void dismissAboutUsDialog() {
        dismissDialogHandler(aboutUsDialog);
    }

    @Override
    public void setName(String name) {
        this.userName.setText(name);
    }

    @Override
    public void setEmail(String email) {
        this.userEmail.setText(email);
    }

    @Override
    public void onValidPass() {

    }

    @Override
    public void onInvalidPass(String error) {

    }

    @Override
    public void onChangePassword(String message) {

    }

    @Override
    public void onNotChagePassword(String message) {

    }

    @Override
    public void onSuccessRemoveUserInfo() {

    }

    @Override
    public void onFailRemoveUserInfo() {

    }

    @Override
    public void uploadSuccess(String newUrl) {

    }

    @Override
    public void uploadFail(String error) {

    }

    @Override
    public void setProfilePic(Bitmap bitmap) {
        if (bitmap == null) {
            mainPresenter.getProfilePic();
            userImage.setImageResource(R.drawable.nouser);
            recycleBitmap(bitmap);
        } else {
            userImage.setImageBitmap(bitmap);
            recycleBitmap(bitmap);
        }

    }

    @Override
    public void showProfileDialog() {

    }

    @Override
    public void dismissProfileDialog() {

    }

    @Override
    public void profilePicDownloaded() {
        mainPresenter.setUserData();
    }

    //endregion


    private void setupRecycler() {

        layoutManager = new CustomLayoutManager(this);
        enableScroll();

        adapter = new MainItemsRecyclerAdapter(this, recyclerData, this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);
//        adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
//            @Override
//            public void onChanged() {
//                super.onChanged();
//                Log.i(TAG, "onChanged: ");
//                enableScroll();
//            }
//        });

        ItemTouchHelper.SimpleCallback itemTouchHelperCallBack = new RecyclerItemTouchHelper(0, ItemTouchHelper.LEFT, this);
        new ItemTouchHelper(itemTouchHelperCallBack).attachToRecyclerView(recyclerView);

        recyclerView.setAdapter(adapter);
//        adapter.setListener(this);


    }

    private void showToast(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(ActivityMain.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void terminateThreads() {
        for (int i = 0; i < asyncTasks.size(); i++) {
            if (asyncTasks.get(i) != null) {
                asyncTasks.get(i).cancel(true);
                asyncTasks.remove(i);
            }
        }
    }

    private void initial_dialog() {
//        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//        dataDialog = new DataDialog(this, getString(R.string.getData));
//        builder.setView(dataDialog);
//        progressDialog = builder.create();

//        progressDialog = new ProgressDialog(this);
//        progressDialog.setMessage(getString(R.string.main_prgrss_msg));
//        progressDialog.setCancelable(false);
//        progressDialog.setTitle(getString(R.string.main_prgrss_title));
//

    }

    private boolean isAppFoldersExist() {
        File opticoFolder = new File(Environment.getExternalStorageDirectory() + File.separator + Config.APP_FOLDER_NAME);
        if (!opticoFolder.exists())
            return false;
        File optico = new File(opticoFolder.getPath() + File.separator + Config.APP_FOLDER_OPTICO);
        if (!optico.exists())
            return false;
        File layout = new File(opticoFolder.getPath() + File.separator + Config.APP_FOLDER_LAYOUT);
        if (!layout.exists())
            return false;
        File accessory = new File(opticoFolder.getPath() + File.separator + Config.APP_FOLDER_ACCESSORY);
        if (!accessory.exists())
            return false;

        return true;

    }

    private void createAppFolder() {
        File opticoFolder = new File(Environment.getExternalStorageDirectory(), Config.APP_FOLDER_NAME);
        boolean AppFolderExist = opticoFolder.exists();
        if (!AppFolderExist) {
            AppFolderExist = opticoFolder.mkdirs();
        }
        if (AppFolderExist) {
            createSubFolders(opticoFolder.getPath());
            createSignatureFolder();
        }
    }

    private void createSignatureFolder() {
        File signatureFolder = new File(SIGNATURE_DIRECTORY);
        boolean signatureFolderExist = signatureFolder.exists();
        if (!signatureFolderExist) {
            signatureFolder.mkdirs();
        }
    }

    private void createSubFolders(String appFolderPath) {
        File opticoFolder = new File(appFolderPath, Config.APP_FOLDER_OPTICO);
        File accessoryFolder = new File(appFolderPath, Config.APP_FOLDER_ACCESSORY);
        File layoutFolder = new File(appFolderPath, Config.APP_FOLDER_LAYOUT);
        if (!opticoFolder.exists())
            opticoFolder.mkdirs();
        if (!accessoryFolder.exists())
            accessoryFolder.mkdirs();
        if (!layoutFolder.exists())
            layoutFolder.mkdirs();
    }

    private void showStoragePermissionError() {
        final AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("Permiso de almacenamiento");
        alertDialog.setMessage("Debes permitir que la aplicación use la tarjeta sd");

        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "De acuerdo", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                sendDataLog("Storage permission alert", "Positive");
                permissionPresenter.getStoragePermission();
            }
        });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                sendDataLog("Storage permission alert", "Negative");
                alertDialog.cancel();
            }
        });
        showDialogHanlder(alertDialog);
    }

    private boolean isGPSProviderEnable() {
        LocationManager locationManager = (LocationManager)
                Objects.requireNonNull(this)
                        .getSystemService(LOCATION_SERVICE);
        if (locationManager != null) {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                return true;
            }
        }

        EasyLocationProvider easyLocationProvider = new EasyLocationProvider.Builder(ActivityMain.this)
                .setInterval(5000)
                .setFastestInterval(2000)
                .setListener(new EasyLocationProvider.EasyLocationCallback() {
                    @Override
                    public void onGoogleAPIClient(GoogleApiClient googleApiClient, String message) {
                        Log.i(TAG, "onGoogleAPIClient: " + message);
                    }

                    @Override
                    public void onLocationUpdated(double latitude, double longitude) {
                        Log.i(TAG, "onLocationUpdated: " + latitude + " - " + longitude);
                    }

                    @Override
                    public void onLocationUpdateRemoved() {
                        Log.i(TAG, "onLocationUpdateRemoved: ");
                    }

                    @Override
                    public void onLocationRecieved(double lat, double latLng) {
                        Log.i(TAG, "onLocationRecieved: " + lat + " ---- " + latLng);
                    }
                }).build();
        getLifecycle().addObserver(easyLocationProvider);
        GPSTracker.getInstance(this, this).getCurrentLocation();

        return false;
    }

    private void goToNewCheckList(String user_aggent) {
        if (isGPSProviderEnable()) {
            if (isLocationPermitted) {
                Intent intent = new Intent(G.context, ActivityNewCheckList.class);
                intent.putExtra(Config.USER_AGGENT, user_aggent);
                startActivityForResult(intent, OPENED_CHECKLIST_KEY);
            } else {
                permissionPresenter.getLocationPermission();
            }
        }
    }

    @Override
    public void onDownloadingNewApp() {

    }

    @Override
    public void onFinishDownloadNewApp() {

    }

    @Override
    public void onFailDownloadNewApp() {

    }
    //endregion

    //region app version
    @Override
    public void showAppVersionDialog(String uri) {

//        if (dialogVersionApp != null)
//            showDialogHanlder(dialogVersionApp);
//        else {
//            InitializeVersionAppDialog();
//            dismissDialogHandler(dialogVersionApp);
//        }
    }

    @Override
    public void dismissAppVersionDialog() {
        dismissDialogHandler(dialogVersionApp);
    }

    @Override
    public void setVersionAppDrawer(String currentVersion) {
        textViewAppVersion.setText(currentVersion);
    }
    //endregion

    private long get_current_long_time(String date) {

        String parts[] = date.split("-");

        int day = Integer.parseInt(parts[0]);
        int month = Integer.parseInt(parts[1]);
        int year = Integer.parseInt(parts[2]);

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month - 1);
        calendar.set(Calendar.DAY_OF_MONTH, day);

        long milliTime = calendar.getTimeInMillis();

        return milliTime;

    }

    private String handle_day_with_zero(int dayOfMonth) {

//        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP_MR1) {
//            int temp = dayOfMonth - 7;
//            if (temp > 0 && temp <= 31)
//                dayOfMonth = temp;
//        }

        String day = String.valueOf(dayOfMonth);

        if (day.length() < 2) {
            day = "0" + day;
        }

        return day;

    }


    private void showCalendarFilter() {

        AlertDialog.Builder builder = new AlertDialog.Builder(ActivityMain.this);
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.layout_calendar_view, drawer, false);
        final CalendarView calendarView = view.findViewById(R.id.calendar_view);
        builder.setCancelable(false);
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.LOLLIPOP) {
            ViewGroup.LayoutParams parameters = calendarView.getLayoutParams();
            parameters.height = 500;
        }
        calendarView.setDate(get_current_long_time(choosenDate));
        TextView cancel = view.findViewById(R.id.cancel);
        TextView done = view.findViewById(R.id.done);
        TextView today = view.findViewById(R.id.today);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                month++;
                choosenDate = handle_day_with_zero(dayOfMonth) + "-" + handle_day_with_zero(month) + "-" + year;

            }
        });
        builder.setView(view);
        final AlertDialog alertDialog = builder.create();
        showDialogHanlder(alertDialog);
        today.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendDataLog(choosenDate, "Today");
                alertDialog.dismiss();
                Date today = Calendar.getInstance().getTime();
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                choosenDate = dateFormat.format(today).replace("/", "-");
                calendar.setText(getString(R.string.check_list_filter_pre_text));
                calendar_btn.setText(getString(R.string.last24haours));
//                refresh.setRefreshing(true);
                adapter.setIsSyncUpdate(false);
                userChecklistPresenter.getCheckListItemsByUserAndDate(getUser(ActivityMain.this), choosenDate);

            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                sendDataLog(choosenDate, "Cancel");
            }
        });
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                calendar_btn.setText(getDateText(choosenDate));
//                init_data();
//                refresh.setRefreshing(true);
                adapter.setIsSyncUpdate(false);
                userChecklistPresenter.getCheckListItemsByUserAndDate(getUser(ActivityMain.this), choosenDate);
                sendDataLog(choosenDate, "Done");
            }
        });

    }

    //onclick methodes

    @Override
    public void onClick(View view) {

        if (view == topMenu) {
            sendEventLog("Top menu bar");
            drawer.openDrawer(Gravity.LEFT);
        }
        if (view == update) {
            sendEventLog("Update data");
            drawer.closeDrawer(Gravity.LEFT);
            //updatedModelsCount =0;
            if (isStoragePermitted) {
                initial_dialog();
                isUpdateDataInProccess = true;
                if (!isAnyItemIsProcessing()) {
                    controllerPresenter.getDBsDataFromServer(isConnected);
                } else {
                    Toast.makeText(this, getString(R.string.pleaseUpdateAfterUpload), Toast.LENGTH_SHORT).show();
                }
            } else
                showStoragePermissionError();
        }
        if (view == exit) {
            sendEventLog("Logout");
            drawer.closeDrawer(Gravity.LEFT);
            mainPresenter.showLogoutDialog();
        }
        if (view == inventory) {
            sendEventLog("Inventory");
            drawer.closeDrawer(Gravity.LEFT);
        }
        if (view == about) {
            sendEventLog("About us");
            drawer.closeDrawer(Gravity.LEFT);
            mainPresenter.showAboutUsDialog();

        }

        if (view == userLocation) {
            sendEventLog("Mapas");
            Intent intent = new Intent(ActivityMain.this, MapsActivity.class);
            startActivity(intent);

        }

        if (view == support) {
            sendEventLog("Support");
            if (isConnected) {
                Intent intent = new Intent(this, ActivityIssues.class);
                startActivity(intent);
                drawer.closeDrawer(Gravity.LEFT);
                support.setEnabled(false);
                new Handler(getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (support != null) {
                            support.setEnabled(true);
                        }
                    }
                }, 500);
            } else {
                Toast.makeText(this, getString(R.string.no_network), Toast.LENGTH_SHORT).show();
                drawer.closeDrawer(Gravity.LEFT);
            }

        }

        if (trash == view) {
            sendEventLog("Trash");
            startActivity(new Intent(G.context
                    , ActivityDeleted.class));
        }

        if (ticket == view) {
            sendEventLog("Campanas");
            if (hasShops())
                goToNewCheckList("2");
            else
                showNoShopError();
        }
        if (tutorial == view) {
            startActivity(new Intent(ActivityMain.this, ActivityTutorial.class));
        }
        if (auditoria == view) {
            sendEventLog("Auditoria");
            new LogMonitor().getAllInJSONArray(new LogMonitorDataListener() {
                @Override
                public void onDataRecieved(JSONArray data) {
                    Log.i(TAG, "onDataRecieved: " + data);
                    new ApiService(ActivityMain.this).sendLogMonitor(data);
                }

                @Override
                public void onDataEmpty() {

                }
            });
            if (hasShops())
                goToNewCheckList(USERAGENT_VISUAL);
            else {
                sendDataLog("", "No shop assigned", "", "", "", "");
                showNoShopError();
            }
            //shopPresenter.getShops();
        }
        if (view == settings) {
            sendEventLog("Settings");
            if (isConnected) {
                Intent intent = new Intent(this, ActivityProfile.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, getString(R.string.no_network), Toast.LENGTH_SHORT).show();
                drawer.closeDrawer(Gravity.LEFT);
            }

        }
        if (view == shops) {
            sendEventLog("Shops");
            drawer.closeDrawer(Gravity.LEFT);
            Intent intent = new Intent(this, ActivityShops.class);
            startActivity(intent);
        }
        if (view == userImage) {
            mainPresenter.getProfilePic();
            new LogEvent().getAllItems();
        }
        if (view == calendarHolder) {
            sendEventLog("Calendar botton");
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP_MR1) {
                showCalendarFilterForAndroid5();
            } else {
                showCalendarFilter();
            }

            calendar_btn.setEnabled(false);
            new Handler(getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (calendar_btn != null) {
                        calendar_btn.setEnabled(true);
                    }
                }
            }, 90);
        }


    }

    private void showCalendarFilterForAndroid5() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ActivityMain.this);
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.layout_date, drawer, false);
        builder.setCancelable(false);

        TextView cancel = view.findViewById(R.id.cancel);
        TextView done = view.findViewById(R.id.done);
        TextView today = view.findViewById(R.id.today);

        final EditText yearEdt = view.findViewById(R.id.yearEdt);
        final EditText monthEdt = view.findViewById(R.id.monthEdt);
        final EditText dayEdt = view.findViewById(R.id.dayEdt);

        if (!choosenDate.equals("")) {

            String dateArray[] = choosenDate.split("-");
            String preYear = dateArray[2];
            String preMonth = dateArray[1];
            String preDay = dateArray[0];

            yearEdt.setText(preYear);
            monthEdt.setText(preMonth);
            dayEdt.setText(preDay);

        }


        builder.setView(view);
        final AlertDialog alertDialog = builder.create();
        showDialogHanlder(alertDialog);
        today.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendDataLog(choosenDate, "Today");
                alertDialog.dismiss();
                Date today = Calendar.getInstance().getTime();
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                choosenDate = dateFormat.format(today).replace("/", "-");
                calendar.setText(getString(R.string.check_list_filter_pre_text));
                calendar_btn.setText(getString(R.string.last24haours));
//                refresh.setRefreshing(true);
                adapter.setIsSyncUpdate(false);
                userChecklistPresenter.getCheckListItemsByUserAndDate(getUser(ActivityMain.this), choosenDate);


            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendDataLog(choosenDate, "Cancel");
                alertDialog.dismiss();
            }
        });
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isDataOk(yearEdt, monthEdt, dayEdt)) {
                    sendDataLog(choosenDate, "Done");

                    int year = Integer.parseInt(yearEdt.getText().toString());
                    int month = Integer.parseInt(monthEdt.getText().toString());
                    int day = Integer.parseInt(dayEdt.getText().toString());

                    choosenDate = handle_day_with_zero(day) + "-" + handle_day_with_zero(month) + "-" + year;

                    alertDialog.dismiss();

                    calendar_btn.setText(getDateText(choosenDate));
//                init_data();
//                    refresh.setRefreshing(true);
                    adapter.setIsSyncUpdate(false);
                    userChecklistPresenter.getCheckListItemsByUserAndDate(getUser(ActivityMain.this), choosenDate);

                }
            }
        });
    }

    private boolean isDataOk(EditText yearEdt, EditText monthEdt, EditText dayEdt) {

        try {

            if (yearEdt.getText().toString().equals("")
                    || monthEdt.getText().toString().equals("")
                    || dayEdt.getText().toString().equals("")
            ) {
                Toast.makeText(this, R.string.fillAllBlanks, Toast.LENGTH_SHORT).show();
                return false;
            }

            int year = Integer.parseInt(yearEdt.getText().toString());
            int month = Integer.parseInt(monthEdt.getText().toString());
            int day = Integer.parseInt(dayEdt.getText().toString());

            if (year <= 0 || month <= 0 || month > 12 || day <= 0 || day > 31) {
                Toast.makeText(this, R.string.valueCannotZero, Toast.LENGTH_SHORT).show();
                return false;
            }

            if (year < 2018) {
                Toast.makeText(this, R.string.yearNotExist, Toast.LENGTH_SHORT).show();
                return false;
            }

            return true;

        } catch (Exception e) {

            Toast.makeText(this, R.string.valueNotValid, Toast.LENGTH_SHORT).show();

            return false;

        }
    }


    private void InitilizaNoShopAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.noShop));
        builder.setCancelable(false);
        builder.setMessage(getString(R.string.noShopUpdateDataMsg));
        builder.setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                sendDataLog("No shop alert", "Negative");
                noShopAlert.dismiss();

            }
        });
        builder.setPositiveButton(getString(R.string.update), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                sendDataLog("No shop alert", "Positive");
                noShopAlert.dismiss();

                if (isStoragePermitted) {
                    initial_dialog();
                    isUpdateDataInProccess = true;
                    if (!isAnyItemIsProcessing())
                        controllerPresenter.getDBsDataFromServer(isConnected);
                } else
                    showStoragePermissionError();
            }
        });
        noShopAlert = builder.create();


    }

    private void showNoShopError() {
        showDialogHanlder(noShopAlert);
    }

    private boolean hasShops() {
        return new Shop().hasShop();
    }

    @Override
    public boolean onKey(View view, int keyCode, KeyEvent keyEvent) {
        if (view == editTextSerach) {
            if ((keyEvent.getAction() == KeyEvent.ACTION_DOWN) &&
                    (keyCode == KeyEvent.KEYCODE_ENTER)) {
                // Perform action on key press
                View keyboard = this.getCurrentFocus();
                if (keyboard != null) {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    assert imm != null;
                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                }
                mainItemPresenter.startUpdateList(editTextSerach.getText().toString(), choosenDate, false);
                editTextSerach.clearFocus();
                return true;
            }
            return false;
        }
        return false;
    }


    @Override
    public void onBackPressed() {
        if (isDrawerOpen) {
            drawer.closeDrawer(Gravity.LEFT);
        } else {
            if (isTimeOut) {
                isTimeOut = false;
                Toast.makeText(this, getString(R.string.pressAgainToExitMsg), Toast.LENGTH_SHORT).show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        isTimeOut = true;
                    }
                }, 1000 * 2);
            } else {
                finish();
                versionPresenter.TerminateVersionCheck();
            }

        }

    }


    //region Drawer listener
    @Override
    public void onDrawerSlide(@NonNull View view, float v) {
        TranslateAnimation translateAnimation = new TranslateAnimation(dpToPx(last_known_offset * 265, ActivityMain.this), dpToPx(v * 265, ActivityMain.this), 0, 0);
        translateAnimation.setFillEnabled(true);
        translateAnimation.setFillAfter(true);
        translateAnimation.setDuration(1);
        mainUI.setAnimation(translateAnimation);
        translateAnimation.start();

        last_known_offset = v;

//        float moveFactor = (drawer.getWidth() * v);
//
//        TranslateAnimation anim = new TranslateAnimation(last_known_offset, moveFactor, 0.0f, 0.0f);
//        anim.setDuration(0);
//        anim.setFillAfter(true);
//        mainUI.startAnimation(anim);
//
//        last_known_offset = moveFactor;

    }

    @Override
    public void onDrawerOpened(@NonNull View view) {
        isDrawerOpen = true;
        set_drawer_back_view_disabled();

    }

    @Override
    public void onDrawerClosed(@NonNull View view) {
        isDrawerOpen = false;
        set_drawer_back_view_enabled();

    }

    @Override
    public void onDrawerStateChanged(int i) {
    }

    private void set_drawer_back_view_disabled() {
        editTextSerach.setEnabled(false);
        int count = recyclerView.getChildCount();
        for (int i = 0; i < count; i++) {
            recyclerView.getChildAt(i).setEnabled(false);

        }

    }

    private void set_drawer_back_view_enabled() {
        editTextSerach.setEnabled(true);
        int count = recyclerView.getChildCount();
        for (int i = 0; i < count; i++) {
            recyclerView.getChildAt(i).setEnabled(true);
        }

    }
    //endregion

    private class Update extends AsyncTask<String, Void, String> {

        private ActivityMain.updateModel updateModel;
        private JSONArray params;

        public Update(updateModel updateModel, JSONArray params) {
            this.updateModel = updateModel;
            this.params = params;
        }

        @Override
        protected String doInBackground(String... strings) {
            switch (updateModel) {
                case SHOP:
                    shopPresenter.Insert(params);
                    break;
                case CHECKLIST:
                    checkListPresenter.Insert(params);
                    break;
                case LAYOUT:
                    layoutPresenter.Insert(params);
                    break;
                case OPTICO:
                    opticoPresenter.Insert(params);
                    break;
                case CATEGORY:
                    categoryPresenter.Insert(params);
                    break;
                case ACCESSORY:
                    accessoryPresenter.Insert(params);
                    break;
                case PRODUCT:
                    productPresenter.Insert(params);
                    break;
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
//            dataDialog.setFinishedToItem(updateModel);
            if (asyncTasks.size() > 0) {
                asyncTasks.remove(asyncTasks.size() - 1);
            }
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
    }


}
