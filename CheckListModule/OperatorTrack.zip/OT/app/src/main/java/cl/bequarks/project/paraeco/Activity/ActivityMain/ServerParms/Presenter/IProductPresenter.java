package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter;

import org.json.JSONArray;

interface IProductPresenter {

    void getProducts();

    void getProductById(long id);

    void Insert(JSONArray products);
}
