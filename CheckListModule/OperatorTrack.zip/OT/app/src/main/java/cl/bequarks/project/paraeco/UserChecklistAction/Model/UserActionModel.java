package cl.bequarks.project.paraeco.UserChecklistAction.Model;

public class UserActionModel implements IUserActionModel {

    private String actionName;
    private String actionTime;
    private String actionParameters;
    private String actionId;

    public UserActionModel(String ActionName, String ActionTime, String ActionParameters,String actionId) {
        actionName = ActionName;
        actionTime = ActionTime;
        actionParameters = ActionParameters;
        this.actionId = actionId;
    }

    public String getActionName() {
        return actionName;
    }

    public void setActionName(String actionName) {
        this.actionName = actionName;
    }

    public String getActionTime() {
        return actionTime;
    }

    public void setActionTime(String actionTime) {
        this.actionTime = actionTime;
    }

    public String getActionParameters() {
        return actionParameters;
    }

    public void setActionParameters(String actionParameters) {
        this.actionParameters = actionParameters;
    }

    public String getActionId() {
        return actionId;
    }

    public void setActionId(String actionId) {
        this.actionId = actionId;
    }
}
