package cl.bequarks.project.paraeco.DBHelper;

import android.provider.BaseColumns;

public class FeedReaderContract {
    /**
     * prevent getting instance
     */
    private FeedReaderContract() {

    }

    public static class OpticoTable implements BaseColumns {

        public static final String TABLE_NAME = "OpticoTable";

        public static final String endtDate = "endDate";
        public static final String img = "img";
        public static final String img_path = "imgPath";
        public static final String optico_id = "opticoId";
        public static final String optico_name = "opticoName";
        public static final String priority = "priority";
        public static final String result_id = "resultId";
        public static final String shop_id = "shopId";
        public static final String startDate = "startDate";

        public static final String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + FeedReaderContract.OpticoTable.TABLE_NAME + " (" +
                        FeedReaderContract.OpticoTable._ID + " INTEGER PRIMARY KEY," +
                        FeedReaderContract.OpticoTable.optico_id + " INTEGER," +
                        FeedReaderContract.OpticoTable.optico_name + " TEXT," +
                        FeedReaderContract.OpticoTable.shop_id + " TEXT," +
                        FeedReaderContract.OpticoTable.priority + " INTEGER," +
                        FeedReaderContract.OpticoTable.result_id + " TEXT," +
                        FeedReaderContract.OpticoTable.img + " TEXT," +
                        FeedReaderContract.OpticoTable.img_path + " TEXT," +
                        FeedReaderContract.OpticoTable.startDate + " TEXT," +
                        FeedReaderContract.OpticoTable.endtDate + " TEXT)";

        public static final String SQL_DELETE_ENTRIES =
                "DROP TABLE IF EXISTS " + FeedReaderContract.OpticoTable.TABLE_NAME;

    }

    public static class ShopTable implements BaseColumns {

        public static final String TABLE_NAME = "SHOP";

        public static String shop_id = "shop_id";
        public static String shop_name = "shop_name";
        public static String retail_id = "retail_id";
        public static String retail_name = "retail_name";
        public static String country = "country";
        public static String state = "state";
        public static String city = "city";
        public static String adress = "address";
        public static String lat = "lat";
        public static String lat_long = "long";
        public static String img = "img";
        public static String logo = "logo";
        public static String canal_id = "canal_id";
        public static String subcanal_id = "subcanal_id";
        public static String type = "type";
        public static String user_id = "user_id";
        public static String zones = "zones";
        public static String surveyType = "type_survey";
        public static String fullName = "fullName";

        public static final String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + FeedReaderContract.ShopTable.TABLE_NAME + " (" +
                        FeedReaderContract.ShopTable._ID + " INTEGER PRIMARY KEY," +
                        ShopTable.shop_id + " INTEGER," +
                        ShopTable.shop_name + " TEXT," +
                        ShopTable.retail_id + " INTEGER," +
                        ShopTable.retail_name + " TEXT," +
                        ShopTable.country + " TEXT," +
                        ShopTable.state + " TEXT," +
                        ShopTable.city + " TEXT," +
                        ShopTable.adress + " TEXT," +
                        ShopTable.lat + " TEXT," +
                        ShopTable.lat_long + " TEXT," +
                        ShopTable.img + " TEXT," +
                        ShopTable.logo + " TEXT," +
                        ShopTable.canal_id + " INTEGER," +
                        ShopTable.subcanal_id + " INTEGER," +
                        ShopTable.type + " TEXT," +
                        ShopTable.user_id + " INTEGER," +
                        ShopTable.zones + " TEXT," +
                        ShopTable.fullName + " TEXT," +
                        ShopTable.surveyType + " TEXT)";

        public static final String SQL_DELETE_ENTRIES =
                "DROP TABLE IF EXISTS " + FeedReaderContract.ShopTable.TABLE_NAME;

        public static final String SQL_GET_ALL = "SELECT * FROM "+ShopTable.TABLE_NAME;

    }

    public static class ProductTalbe implements BaseColumns{

        public static final String TABLE_NAME = "ProductTable";

        public static String productId = "product_id";
        public static String stock = "stock";
        public static String shopId = "shop_id";
        public static String title = "title";

        public static final String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + FeedReaderContract.ProductTalbe.TABLE_NAME + " (" +
                        FeedReaderContract.ProductTalbe._ID + " INTEGER PRIMARY KEY," +
                        ProductTalbe.productId + " INTEGER," +
                        ProductTalbe.stock + " INTEGER," +
                        ProductTalbe.shopId + " INTEGER," +
                        ProductTalbe.title + " TEXT)";

        public static final String SQL_DELETE_ENTRIES =
                "DROP TABLE IF EXISTS " + FeedReaderContract.ProductTalbe.TABLE_NAME;

    }

    public static class LayoutTable implements BaseColumns{

        public static final String TABLE_NAME = "LayoutTable";

        public static String order_id = "order_id";
        public static String order_name = "name";
        public static String img = "img";
        public static String shop = "shop";
        public static String countpos = "countpos";
        public static String positions = "positions";
        public static String replacements = "replacements";
        public static String imgPath = "imgPath";

        public static final String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + FeedReaderContract.LayoutTable.TABLE_NAME + " (" +
                        FeedReaderContract.LayoutTable._ID + " INTEGER PRIMARY KEY," +
                        LayoutTable.order_id + " INTEGER," +
                        LayoutTable.order_name + " TEXT," +
                        LayoutTable.img + " TEXT," +
                        LayoutTable.shop + " TEXT," +
                        LayoutTable.countpos + " INTEGER," +
                        LayoutTable.positions + " TEXT," +
                        LayoutTable.replacements + " TEXT," +
                        LayoutTable.imgPath + " TEXT)";

        public static final String SQL_DELETE_ENTRIES =
                "DROP TABLE IF EXISTS " + FeedReaderContract.LayoutTable.TABLE_NAME;

    }

    public static class CheckListTable implements BaseColumns{

        public static final String TABLE_NAME = "ChecklistTable";

        public static String serverId = "serverId";
        public static String category = "category";
        public static String title = "title";
        public static String shops = "shop";
        public static String type = "type";
        public static String hasError = "hasError";
        public static String json = "json";
        public static String errors = "errors";

        public static final String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + FeedReaderContract.CheckListTable.TABLE_NAME + " (" +
                        FeedReaderContract.CheckListTable._ID + " INTEGER PRIMARY KEY," +
                        CheckListTable.serverId + " INTEGER," +
                        CheckListTable.category + " TEXT," +
                        CheckListTable.title + " TEXT," +
                        CheckListTable.shops + " TEXT," +
                        CheckListTable.errors + " TEXT," +
                        CheckListTable.hasError + " INTEGER," +
                        CheckListTable.type + " INTEGER," +
                        CheckListTable.json + " TEXT)";

        public static final String SQL_DELETE_ENTRIES =
                "DROP TABLE IF EXISTS " + FeedReaderContract.CheckListTable.TABLE_NAME;

    }

    public static class CategoryTable implements BaseColumns{

        public static final String TABLE_NAME = "CategoryTable";

        public static String name = "name";
        public static String value = "val" ;

        public static final String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + FeedReaderContract.CategoryTable.TABLE_NAME + " (" +
                        FeedReaderContract.CategoryTable._ID + " INTEGER PRIMARY KEY," +
                        CategoryTable.name + " TEXT," +
                        CategoryTable.value + " INTEGER)";

        public static final String SQL_DELETE_ENTRIES =
                "DROP TABLE IF EXISTS " + FeedReaderContract.CategoryTable.TABLE_NAME;

    }

    public static class AccessoryTalbe implements BaseColumns{

        public static final String TABLE_NAME = "AccessoryTable";

        public static String accessory_name = "accessory_name";
        public static String shop_id = "shop_id";
        public static String result_id = "result_id";
        public static String img = "img";
        public static String startDate = "startDate";
        public static String endtDate = "endDate";
        public static String imgPath = "imgPath";


        public static final String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + FeedReaderContract.AccessoryTalbe.TABLE_NAME + " (" +
                        FeedReaderContract.AccessoryTalbe._ID + " INTEGER PRIMARY KEY," +
                        AccessoryTalbe.accessory_name + " TEXT," +
                        AccessoryTalbe.shop_id + " TEXT," +
                        AccessoryTalbe.result_id + " TEXT," +
                        AccessoryTalbe.img + " TEXT," +
                        AccessoryTalbe.startDate + " TEXT," +
                        AccessoryTalbe.endtDate + " TEXT," +
                        AccessoryTalbe.imgPath + " TEXT)";

        public static final String SQL_DELETE_ENTRIES =
                "DROP TABLE IF EXISTS " + FeedReaderContract.AccessoryTalbe.TABLE_NAME;

    }

    public static class UserChecklistTable implements BaseColumns{

        public static final String TABLE_NAME = "UserChecklistTable";

        public static String checkListJson = "checklistJson";
        public static  String answerJson = "answerJson";
        public static  String time = "time";
        public static  String date = "date";
        public static  String shop_name = "shopName";
        public static  String checkList_name = "checklistName";
        public static  String shop_id = "shopId";
        public static  String checkList_id = "checklistId";
        public static  String start_time = "startTime";
        public static  String end_time = "endTime";
        public static  String server_id = "serverId";
        public static  String userEmail = "userEmail";
        public static  String serverLink = "serverLink";
        public static  String errors = "errors";
        public static  String pagePosition = "pagePosition";
        public static  String isPicsSynced = "isPicsSynced";
        public static  String isDeleted = "isDeleted";
        public static  String isSynced = "isSynced";
        public static  String isDraft = "isDraft";
        public static  String isProccessing = "isProccessing";
        public static  String isTicket = "isTicket";



        public static final String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + FeedReaderContract.UserChecklistTable.TABLE_NAME + " (" +
                        FeedReaderContract.UserChecklistTable._ID + " INTEGER PRIMARY KEY," +
                        UserChecklistTable.checkListJson + " TEXT," +
                        UserChecklistTable.answerJson + " TEXT," +
                        UserChecklistTable.time + " TEXT," +
                        UserChecklistTable.date + " TEXT," +
                        UserChecklistTable.shop_name + " TEXT," +
                        UserChecklistTable.checkList_name + " TEXT," +
                        UserChecklistTable.shop_id + " TEXT," +
                        UserChecklistTable.checkList_id + " TEXT," +
                        UserChecklistTable.start_time + " TEXT," +
                        UserChecklistTable.end_time + " TEXT," +
                        UserChecklistTable.server_id + " INTEGER," +
                        UserChecklistTable.userEmail + " TEXT," +
                        UserChecklistTable.serverLink + " TEXT," +
                        UserChecklistTable.errors + " TEXT," +
                        UserChecklistTable.pagePosition + " INTEGER," +
                        UserChecklistTable.isPicsSynced + " INTEGER," +
                        UserChecklistTable.isDeleted + " INTEGER," +
                        UserChecklistTable.isSynced + " INTEGER," +
                        UserChecklistTable.isDraft + " INTEGER," +
                        UserChecklistTable.isTicket + " INTEGER," +
                        UserChecklistTable.isProccessing + " INTEGER)";

        public static final String SQL_DELETE_ENTRIES =
                "DROP TABLE IF EXISTS " + FeedReaderContract.UserChecklistTable.TABLE_NAME;

    }

    public static class PictureTable implements BaseColumns{

        public static final String TABLE_NAME = "PictureTable";

        public static String question_id = "questionId";
        public static String path = "paht";
        public static String server_id = "serverId";//double
        public static String checkListDataBaseId = "checkListDataBaseId";//long
        public static String image_type = "imageType";//int
        public static String name = "name";
        public static String pic_index = "picIndex";//int
        public static String position = "position";//int
        public static String isProccessing = "isProccessing";//bool
        public static String isSynced = "isSynced";//bool




        public static final String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + FeedReaderContract.PictureTable.TABLE_NAME + " (" +
                        FeedReaderContract.PictureTable._ID + " INTEGER PRIMARY KEY," +
                        PictureTable.question_id + " TEXT," +
                        PictureTable.path + " TEXT," +
                        PictureTable.server_id + " INTEGER," +
                        PictureTable.checkListDataBaseId + " TEXT," +
                        PictureTable.image_type + " INTEGER," +
                        PictureTable.name + " TEXT," +
                        PictureTable.pic_index + " INTEGER," +
                        PictureTable.position + " INTEGER," +
                        UserChecklistTable.isSynced + " INTEGER," +
                        UserChecklistTable.isProccessing + " INTEGER)";

        public static final String SQL_DELETE_ENTRIES =
                "DROP TABLE IF EXISTS " + FeedReaderContract.PictureTable.TABLE_NAME;

    }

    public static class LogTable implements BaseColumns{
        public static final String TABLE_NAME = "LogTable";

        public static String checklistDataBaseID = "cehcklistDBID";
        public static String resultID = "resultId";
        public static String Date = "Date";
        public static String Time = "Time";//double
        public static String QuesrionCount = "QuationCount";//double
        public static String AnswerCount = "AnswerCount";//long
        public static String PictureCount = "PictureCount";//int
        public static String UploadedPicture = "UploadedPicture";
        public static String Status = "Status";//int
        public static String NET = "NET";//int
        public static String AnyMommentOffline = "AnyMommentOffline";//bool
        public static String UploadTime = "UploadTime";//bool
        public static String userEmail = "userEmail";
        public static String shopId = "shopId";
        public static String checklistId = "checklsitId";
        public static String shopName = "shopName";
        public static String checklistName = "checklistName";
        public static String isSynced = "isSynced";




        public static final String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + FeedReaderContract.LogTable.TABLE_NAME + " (" +
                        FeedReaderContract.LogTable._ID + " INTEGER PRIMARY KEY," +
                        LogTable.checklistDataBaseID + " TEXT," +
                        LogTable.resultID + " TEXT," +
                        LogTable.Date + " TEXT," +
                        LogTable.Time + " TEXT," +
                        LogTable.QuesrionCount + " TEXT," +
                        LogTable.AnswerCount + " INTEGER," +
                        LogTable.PictureCount + " INTEGER," +
                        LogTable.UploadedPicture + " INTEGER," +
                        LogTable.Status + " TEXT," +
                        LogTable.NET + " TEXT," +
                        LogTable.AnyMommentOffline + " INTEGER," +
                        LogTable.UploadTime + " TEXT," +
                        LogTable.userEmail + " TEXT," +
                        LogTable.shopId + " TEXT," +
                        LogTable.checklistId + " TEXT," +
                        LogTable.shopName + " TEXT," +
                        LogTable.checklistName + " TEXT," +
                        LogTable.isSynced+" INTEGER)";

        public static final String SQL_DELETE_ENTRIES =
                "DROP TABLE IF EXISTS " + FeedReaderContract.LogTable.TABLE_NAME;
    }

    public static class LogEventTable implements BaseColumns{
        public static final String TABLE_NAME = "LogEventTable";

        public static final String APP_VERIOSN = "appVersion";
        public static final String TOKEN = "token";
        public static final String USER = "user";
        public static final String INTERNET = "internet";
        public static final String DATE = "date";
        public static final String TIME = "time";
        public static final String PHONE = "phone";
        public static final String OLD_VERSION = "oldVersion";
        public static final String NEW_VERSION = "newVersion";
        public static final String SERVER_DATA = "serverData";
        public static final String CHECKLIST_JSON = "checklistJson";
        public static final String EVENT_NAME = "eventName";
        public static final String ANSWER_JSON = "answerJson";
        public static final String SYNC_DATA = "syncData";
        public static final String IS_SYNCED = "isSynced";

        public static final String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + FeedReaderContract.LogEventTable.TABLE_NAME + " (" +
                        FeedReaderContract.LogEventTable._ID + " INTEGER PRIMARY KEY," +
                        LogEventTable.APP_VERIOSN + " TEXT," +
                        LogEventTable.TOKEN + " TEXT," +
                        LogEventTable.USER + " TEXT," +
                        LogEventTable.INTERNET + " TEXT," +
                        LogEventTable.DATE + " TEXT," +
                        LogEventTable.TIME + " TEXT," +
                        LogEventTable.PHONE + " TEXT," +
                        LogEventTable.OLD_VERSION + " TEXT," +
                        LogEventTable.NEW_VERSION + " TEXT," +
                        LogEventTable.SERVER_DATA + " TEXT," +
                        LogEventTable.CHECKLIST_JSON + " TEXT," +
                        LogEventTable.EVENT_NAME + " TEXT," +
                        LogEventTable.ANSWER_JSON + " TEXT," +
                        LogEventTable.SYNC_DATA + " TEXT," +
                        LogEventTable.IS_SYNCED+" INTEGER)";

        public static final String SQL_DELETE_ENTRIES =
                "DROP TABLE IF EXISTS " + FeedReaderContract.LogEventTable.TABLE_NAME;

    }

    public static class TicketTable implements BaseColumns {

        public static final String TABLE_NAME = "TicketTable";

        public static final String ANSWER = "answer";
        public static final String DATE = "date";
        public static final String TIME = "time";
        public static final String USER_ID = "userId";
        public static final String TOKEN = "token";
        public static final String DEV_ID = "devId";
        public static final String IS_DELETED = "isDeleted";

        public static final String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + TABLE_NAME + " (" +
                        FeedReaderContract.LogEventTable._ID + " INTEGER PRIMARY KEY," +
                        ANSWER + " TEXT," +
                        DATE + " TEXT," +
                        TIME + " TEXT," +
                        USER_ID + " TEXT," +
                        TOKEN + " TEXT," +
                        DEV_ID + " TEXT," +
                        IS_DELETED+" INTEGER)";

        public static final String SQL_DELETE_ENTRIES =
                "DROP TABLE IF EXISTS " + TABLE_NAME;

    }

}
