package cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.checklist.PictureElement.PicturePickerItemModel;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBArrayResultView;
import cl.bequarks.project.paraeco.DBHelper.FeedReaderContract;
import cl.bequarks.project.paraeco.DBHelper.RunTimeTableDBHelper;
import cl.bequarks.project.paraeco.Global.G;

public class ResultPicture implements IResultPicture {


    private long _ID;
    private String question_id;
    private String path;
    private int isSynced;
    private double server_id;
    private long checkListDataBaseId;
    private int image_type;
    private String name;
    private int isProccessing;
    private int pic_index;
    private int position;


    public ResultPicture() {

    }

    public SQLiteDatabase dropAndCreateTable() {
        return null;
    }

    public SQLiteDatabase getPictureTableDB() {

        RunTimeTableDBHelper dbHelper = getDBHelperInstance();

        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();


        return db;
    }

    private void createTable() {
        RunTimeTableDBHelper dbHelper = getDBHelperInstance();

        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        if (!dbHelper.isTableExists(FeedReaderContract.PictureTable.TABLE_NAME, true)) {
            db.execSQL(FeedReaderContract.PictureTable.SQL_CREATE_ENTRIES);
        }

        db.close();

    }

    public long insert(ResultPicture item) {


        createTable();

        ContentValues values = getValuseFromItem(item);

        if (pictureExist(item)) {
            item.set_ID(getPictureId(item));
            update(item);
            return 1;
        } else {
            SQLiteDatabase db = getPictureTableDB();
            long newRowId = db.insert(FeedReaderContract.PictureTable.TABLE_NAME, null, values);
            db.close();
            return newRowId;
        }

    }

    private long getPictureId(ResultPicture item) {
        RunTimeTableDBHelper helper = getDBHelperInstance();
        SQLiteDatabase db = helper.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM "+ FeedReaderContract.PictureTable.TABLE_NAME
                +" where "+ FeedReaderContract.PictureTable.checkListDataBaseId +"="+item.getCheckListDataBaseId()
                +" AND "+ FeedReaderContract.PictureTable.position + "="+item.getPosition()
                +" AND "+ FeedReaderContract.PictureTable.question_id + "='"+item.getQuestion_id()
                +"' AND "+ FeedReaderContract.PictureTable.pic_index + "="+item.getPic_index(),null);
        cursor.moveToNext();
        ResultPicture picture = getItemByCursor(cursor);
        return picture.get_ID();
    }

    private boolean pictureExist(ResultPicture item) {
        RunTimeTableDBHelper helper = getDBHelperInstance();


        String SQL = "SELECT *  FROM " + FeedReaderContract.PictureTable.TABLE_NAME
                + " WHERE " + FeedReaderContract.PictureTable.checkListDataBaseId + "='" + item.getCheckListDataBaseId()
                + "' AND " + FeedReaderContract.PictureTable.question_id + "='" + item.getQuestion_id()
                + "' AND " + FeedReaderContract.PictureTable.position + "='" + item.getPosition()
                + "' AND " + FeedReaderContract.PictureTable.pic_index + "='" + item.getPic_index()+"'";

//        String SQL = "SELECT *  FROM PictureTable WHERE checkListDataBaseId='9' AND questionId='QuZLxMc' AND position='10' AND picIndex='0'"
        SQLiteDatabase db = helper.getWritableDatabase();
        Cursor cursor = db.rawQuery(SQL,null);
        cursor.moveToNext();
        ResultPicture picture = getItemByCursor(cursor);
        db.close();
        return picture.get_ID() > 0;
    }

//    public boolean isPictureExist(ResultPicture picture){
//        SQLiteDatabase db = getPictureTableDB();
//        String SQL = "SELECT * FROM "+ FeedReaderContract.PictureTable.TABLE_NAME
//                +" WHERE "+ FeedReaderContract.PictureTable.path+" = '"+picture.getPath()+"'";
//        Cursor cursor = db.rawQuery(SQL,null);
//
//        ArrayList<ResultPicture> resultPictures = getItemsByCursor(cursor);
//
//        return resultPictures.size() != 0;
//    }

    public ResultPicture fetchById(long id) {
        RunTimeTableDBHelper dbHelper = getDBHelperInstance();

        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.PictureTable.TABLE_NAME
                + " where " + FeedReaderContract.PictureTable._ID + "='" + id + "'", null);
        cursor.moveToNext();

        ResultPicture resultPicture = getItemByCursor(cursor);
        db.close();
        return resultPicture;
    }

    private RunTimeTableDBHelper getDBHelperInstance() {
        return new RunTimeTableDBHelper(G.context);
    }

    public void update(ResultPicture model) {
        RunTimeTableDBHelper dbHelper = getDBHelperInstance();
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = getValuseFromItem(model);

        db.update(FeedReaderContract.PictureTable.TABLE_NAME, values, FeedReaderContract.PictureTable._ID + "=" + model.get_ID(), null);

        db.close();
    }

    public ContentValues getValuseFromItem(ResultPicture item) {
        ContentValues values = new ContentValues();
        values.put(FeedReaderContract.PictureTable.question_id, item.getQuestion_id());//1
        values.put(FeedReaderContract.PictureTable.path, item.getPath());//2
        values.put(FeedReaderContract.PictureTable.server_id, item.getServer_id());//3
        values.put(FeedReaderContract.PictureTable.checkListDataBaseId, item.getCheckListDataBaseId());//4
        values.put(FeedReaderContract.PictureTable.image_type, item.getImage_type());//5
        values.put(FeedReaderContract.PictureTable.name, item.getName());//6
        values.put(FeedReaderContract.PictureTable.pic_index, item.getPic_index());//7
        values.put(FeedReaderContract.PictureTable.position, item.getPosition());//8
        values.put(FeedReaderContract.PictureTable.isSynced, item.isSynced());//18
        values.put(FeedReaderContract.PictureTable.isProccessing, item.isProccessing());//20
        return values;
    }

    public ResultPicture getItemByCursor(Cursor cursor) {
        if (cursor != null) {
            try {
                long ID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.PictureTable._ID));
                String questionId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.PictureTable.question_id));
                String path = cursor.getString(cursor.getColumnIndex(FeedReaderContract.PictureTable.path));
                int serverID = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.PictureTable.server_id));
                long checklistDataBaseID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.PictureTable.checkListDataBaseId));
                int imageType = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.PictureTable.image_type));
                String name = cursor.getString(cursor.getColumnIndex(FeedReaderContract.PictureTable.name));
                int picIndex = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.PictureTable.pic_index));
                int position = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.PictureTable.position));
                int isSynced = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.PictureTable.isSynced));
                int isProccessing = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.PictureTable.isProccessing));


                ResultPicture resultPicture = new ResultPicture(questionId, path, isSynced, serverID, checklistDataBaseID
                        , imageType, name, isProccessing, picIndex, position);
                resultPicture.set_ID(ID);
                cursor.close();
                return resultPicture;
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                cursor.close();
            }
        }
        return new ResultPicture();
    }

    public ResultPicture getItemForCursor(Cursor cursor) {
        if (cursor != null) {
            long ID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.PictureTable._ID));
            String questionId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.PictureTable.question_id));
            String path = cursor.getString(cursor.getColumnIndex(FeedReaderContract.PictureTable.path));
            int serverID = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.PictureTable.server_id));
            long checklistDataBaseID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.PictureTable.checkListDataBaseId));
            int imageType = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.PictureTable.image_type));
            String name = cursor.getString(cursor.getColumnIndex(FeedReaderContract.PictureTable.name));
            int picIndex = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.PictureTable.pic_index));
            int position = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.PictureTable.position));
            int isSynced = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.PictureTable.isSynced));
            int isProccessing = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.PictureTable.isProccessing));


            ResultPicture resultPicture = new ResultPicture(questionId, path, isSynced, serverID, checklistDataBaseID
                    , imageType, name, isProccessing, picIndex, position);
            resultPicture.set_ID(ID);
            return resultPicture;

        }
        return new ResultPicture();
    }

    public ArrayList<ResultPicture> getAllItems() {
        RunTimeTableDBHelper dbHelper = getDBHelperInstance();
//
        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.PictureTable.TABLE_NAME, null);

        ArrayList<ResultPicture> resultPictures = getItemsByCursor(cursor);
        db.close();
        return resultPictures;
    }

    public ArrayList<ResultPicture> getItemsByCursor(Cursor cursor) {
        try {
            ArrayList<ResultPicture> resultPictures = new ArrayList<>();
            if (cursor.moveToFirst()) {
                while (!cursor.isAfterLast()) {

                    resultPictures.add(getItemForCursor(cursor));

                    cursor.moveToNext();
                }
            }

            cursor.close();
            return resultPictures;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cursor.close();
        }
        return new ArrayList<>();
    }

    public ResultPicture(String question_id, String path, int isSynced, double server_id, long checkListDataBaseId
            , int image_type, String name, int isProccessing, int pic_index, int position) {
        this.question_id = question_id;
        this.path = path;
        this.isSynced = isSynced;
        this.server_id = server_id;
        this.checkListDataBaseId = checkListDataBaseId;
        this.image_type = image_type;
        this.name = name;
        this.isProccessing = isProccessing;
        this.pic_index = pic_index;
        this.position = position;
    }

    @Override
    public void fetchByCheckListId(long checkListId, IDBArrayResultView<ResultPicture> idbArrayResultView) {
        RunTimeTableDBHelper dbHelper = getDBHelperInstance();
//
        // Gets the data repository in write mode

        if (dbHelper.isTableExists(FeedReaderContract.PictureTable.TABLE_NAME, true)) {

            final SQLiteDatabase db = dbHelper.getWritableDatabase();

            Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.PictureTable.TABLE_NAME
                    + " WHERE " + FeedReaderContract.PictureTable.checkListDataBaseId + "=" + checkListId, null);

            ArrayList<ResultPicture> resultPictures = getItemsByCursor(cursor);

            if (resultPictures.size() == 0)
                idbArrayResultView.onFail("No picture");
            else
                idbArrayResultView.onSuccess(resultPictures);
            cursor.close();
            db.close();
        } else {
            createTable();
        }


    }

    public PicturePickerItemModel convertPicturePickerToPictureModel(ResultPicture resultPicture) {

        PicturePickerItemModel model = new PicturePickerItemModel();
        model.setPath(resultPicture.getPath());
        model.setId(resultPicture.getQuestion_id());
        model.setIndex(resultPicture.getPic_index());
        model.setName(resultPicture.getName());
        model.setCat_id(resultPicture.getImage_type());
        model.setStatus(resultPicture.isSynced() == 1);
        model.setPosition(resultPicture.getPosition());
        model.setCategory(resultPicture.getImage_type() + "");

        return model;
    }

    public ArrayList<PicturePickerItemModel> convertPickerArrayToPictureArray(ArrayList<ResultPicture> resultPictures) {
        ArrayList<PicturePickerItemModel> picturePickerItemModels = new ArrayList<>();

        for (ResultPicture resultPicture : resultPictures) {

            picturePickerItemModels.add(convertPicturePickerToPictureModel(resultPicture));

        }

        return picturePickerItemModels;

    }

    public int getPicturesCountByChecklistID(long id) {

        RunTimeTableDBHelper dbHelper = getDBHelperInstance();



        if (dbHelper.isTableExists(FeedReaderContract.PictureTable.TABLE_NAME, true)) {

            String SQL = "SELECT * FROM " + FeedReaderContract.PictureTable.TABLE_NAME
                    + " where " + FeedReaderContract.PictureTable._ID + "='" + id + "'";
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            Cursor cursor = db.rawQuery(SQL, null);
            int size = getItemsByCursor(cursor).size();
            db.close();
            return size;

        } else {
            createTable();
        }
        return 0;

    }

    public int getSyncedPicturesWithChecklistID(long id) {
        RunTimeTableDBHelper dbHelper = getDBHelperInstance();

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        if (dbHelper.isTableExists(FeedReaderContract.PictureTable.TABLE_NAME, true)) {

            String SQL = "SELECT * FROM " + FeedReaderContract.PictureTable.TABLE_NAME
                    + " where " + FeedReaderContract.PictureTable._ID + "='" + id
                    + "' AND " + FeedReaderContract.PictureTable.isSynced + "=" + 1 + "";

            Cursor cursor = db.rawQuery(SQL, null);

            return getItemsByCursor(cursor).size();

        } else {
            createTable();
        }
        db.close();
        return 0;

    }

    public ArrayList<ResultPicture> getNotSyncedInProccess() {
        RunTimeTableDBHelper dbHelper = getDBHelperInstance();



        if (dbHelper.isTableExists(FeedReaderContract.PictureTable.TABLE_NAME, true)) {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            String SQL = "SELECT * FROM " + FeedReaderContract.PictureTable.TABLE_NAME
                    + " where " + FeedReaderContract.PictureTable.isSynced + "='" + 0
                    + "' AND " + FeedReaderContract.PictureTable.isProccessing + "='" + 1 + "'";

            Cursor cursor = db.rawQuery(SQL, null);
            ArrayList<ResultPicture> resultPictures = getItemsByCursor(cursor);
            db.close();
            return resultPictures;


        } else {
            createTable();
        }


        return new ArrayList<>();
    }

    public void removeImages(long checkListDataId, ArrayList<PicturePickerItemModel> pics) {

        if (pics.size() > 0) {

            RunTimeTableDBHelper dbHelper = getDBHelperInstance();

            SQLiteDatabase db = dbHelper.getWritableDatabase();

            String whereClause = FeedReaderContract.PictureTable.checkListDataBaseId + "=" + checkListDataId;

//            for (PicturePickerItemModel pic : pics){
//
//                whereClause = whereClause + " AND " + FeedReaderContract.PictureTable.question_id + "='" + pic.getId()+"'";
//                whereClause = whereClause + " AND " +FeedReaderContract.PictureTable.pic_index + "=" + pic.getIndex();
//
//            }

            if (dbHelper.isTableExists(FeedReaderContract.PictureTable.TABLE_NAME, true)) {

                int a = db.delete(FeedReaderContract.PictureTable.TABLE_NAME, whereClause, null);


            } else {
                createTable();
            }

            db.close();
        }

    }


    public void removeImagesWithUserCheckListID(long checkListDataId) {


    }


    //region setter getter

    public String getQuestion_id() {
        return question_id;
    }

    public void setQuestion_id(String question_id) {
        this.question_id = question_id;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int isSynced() {
        return isSynced;
    }

    public void setSynced(int synced) {
        isSynced = synced;
    }

    public double getServer_id() {
        return server_id;
    }

    public void setServer_id(double server_id) {
        this.server_id = server_id;
    }

    public long getCheckListDataBaseId() {
        return checkListDataBaseId;
    }

    public void setCheckListDataBaseId(long checkListDataBaseId) {
        this.checkListDataBaseId = checkListDataBaseId;
    }

    public int getImage_type() {
        return image_type;
    }

    public void setImage_type(int image_type) {
        this.image_type = image_type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int isProccessing() {
        return isProccessing;
    }

    public void setProccessing(int proccessing) {
        Log.i("ActivityMain", "setProccessing: " + proccessing);
        isProccessing = proccessing;
    }

    public int getPic_index() {
        return pic_index;
    }

    public void setPic_index(int pic_index) {
        this.pic_index = pic_index;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public long get_ID() {
        return _ID;
    }

    public void set_ID(long _ID) {
        this._ID = _ID;
    }


    //endregion
}
