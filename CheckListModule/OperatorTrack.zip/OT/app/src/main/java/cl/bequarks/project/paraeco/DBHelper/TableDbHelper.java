package cl.bequarks.project.paraeco.DBHelper;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.sharedpreference.Config;

import static cl.bequarks.project.paraeco.DBHelper.DataBaseConfig.PARAMS_DATABASE_NAME;
import static cl.bequarks.project.paraeco.DBHelper.DataBaseConfig.PARAMS_VERSION;
import static cl.bequarks.project.paraeco.DBHelper.DataBaseConfig.getParamsDB_VERSION;
import static cl.bequarks.project.paraeco.DBHelper.DataBaseConfig.setParamsDB_VERSION;

public class TableDbHelper extends SQLiteOpenHelper {

    public static TableDbHelper tableDbHelperAccessory;
    public static TableDbHelper tableDbHelperCategory;
    public static TableDbHelper tableDbHelperCehcklist;
    public static TableDbHelper tableDbHelperLayout;
    public static TableDbHelper tableDbHelperOptico;
    public static TableDbHelper tableDbHelperProduct;
    public static TableDbHelper tableDbHelperShop;

    private static final String TAG = "TableDbHelper";


    public TableDbHelper(Context context) {
        super(context, PARAMS_DATABASE_NAME, null, PARAMS_VERSION);
        Log.i(TAG, "TableDbHelper: ");
    }

    public static TableDbHelper getInstanceAccessory(Context context) {
        if (tableDbHelperAccessory == null) {
            tableDbHelperAccessory = new TableDbHelper(context);
        }
        return tableDbHelperAccessory;
    }
    public static TableDbHelper getInstanceCategory(Context context) {
        if (tableDbHelperCategory == null) {
            tableDbHelperCategory = new TableDbHelper(context);
        }
        return tableDbHelperCategory;
    }
    public static TableDbHelper getInstanceChecklist(Context context) {
        if (tableDbHelperCehcklist == null) {
            tableDbHelperCehcklist = new TableDbHelper(context);
        }
        return tableDbHelperCehcklist;
    }
    public static TableDbHelper getInstanceLayout(Context context) {
        if (tableDbHelperLayout == null) {
            tableDbHelperLayout = new TableDbHelper(context);
        }
        return tableDbHelperLayout;
    }
    public static TableDbHelper getInstanceOptico(Context context) {
        if (tableDbHelperOptico == null) {
            tableDbHelperOptico = new TableDbHelper(context);
        }
        return tableDbHelperOptico;
    }
    public static TableDbHelper getInstanceProduct(Context context) {
        if (tableDbHelperProduct == null) {
            tableDbHelperProduct = new TableDbHelper(context);
        }
        return tableDbHelperProduct;
    }
    public static TableDbHelper getInstanceShop(Context context) {
        if (tableDbHelperShop == null) {
            tableDbHelperShop = new TableDbHelper(context);
        }
        return tableDbHelperShop;
    }

    public boolean isTableExists(String tableName, boolean openDb) {
        SQLiteDatabase mDatabase = getWritableDatabase();
        if (openDb) {
            if (mDatabase == null || !mDatabase.isOpen()) {
                mDatabase = getReadableDatabase();
            }

            if (!mDatabase.isReadOnly()) {
                mDatabase.close();
                mDatabase = getReadableDatabase();
            }
        }
        Cursor cursor = mDatabase.rawQuery("select DISTINCT tbl_name from sqlite_master where tbl_name = '" + tableName + "'", null);
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                cursor.close();
                return true;
            }
            cursor.close();
        }
        return false;

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(FeedReaderContract.ShopTable.SQL_CREATE_ENTRIES);
        db.execSQL(FeedReaderContract.CheckListTable.SQL_CREATE_ENTRIES);
        db.execSQL(FeedReaderContract.OpticoTable.SQL_CREATE_ENTRIES);
        db.execSQL(FeedReaderContract.CategoryTable.SQL_CREATE_ENTRIES);
        db.execSQL(FeedReaderContract.LayoutTable.SQL_CREATE_ENTRIES);
        db.execSQL(FeedReaderContract.AccessoryTalbe.SQL_CREATE_ENTRIES);
        db.execSQL(FeedReaderContract.ProductTalbe.SQL_CREATE_ENTRIES);
        setParamsDB_VERSION(PARAMS_VERSION);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over
        if (newVersion > getParamsDB_VERSION()) {
            db.execSQL(FeedReaderContract.ShopTable.SQL_DELETE_ENTRIES);
            db.execSQL(FeedReaderContract.CheckListTable.SQL_DELETE_ENTRIES);
            db.execSQL(FeedReaderContract.OpticoTable.SQL_DELETE_ENTRIES);
            db.execSQL(FeedReaderContract.CategoryTable.SQL_DELETE_ENTRIES);
            db.execSQL(FeedReaderContract.LayoutTable.SQL_DELETE_ENTRIES);
            db.execSQL(FeedReaderContract.AccessoryTalbe.SQL_DELETE_ENTRIES);
            db.execSQL(FeedReaderContract.ProductTalbe.SQL_DELETE_ENTRIES);

            clearVersion();
            onCreate(db);
        }
    }

    private void clearVersion() {
        SharedPreferences.Editor editor = G.context.getSharedPreferences(Config.sharedPreferencName, Context.MODE_PRIVATE)
                .edit();
        editor.putString(Config.version, "").apply();
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);

    }

}
