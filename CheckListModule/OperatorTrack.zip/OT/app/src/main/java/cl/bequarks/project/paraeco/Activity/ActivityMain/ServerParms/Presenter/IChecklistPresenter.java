package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter;

import org.json.JSONArray;

public interface IChecklistPresenter {
    void Insert(JSONArray jSONArray);

    void getCheckListById(long j);

    void getCheckListByType(int i);

    void getCheckLists();

    void getByTypeAndSubCanal(String shopId,int i, int i1);



}
