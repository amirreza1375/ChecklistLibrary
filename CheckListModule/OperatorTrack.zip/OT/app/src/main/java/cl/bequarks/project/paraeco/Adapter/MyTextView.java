package cl.bequarks.project.paraeco.Adapter;

/**
 * custom text view with custom font
 */
public class MyTextView {
//    public MyTextView(Context context) {
//        super(context);
//        init(context);
//    }
//
//    public MyTextView(Context context, AttributeSet attrs) {
//        super(context, attrs);
//        init(context);
//    }
//
//    public MyTextView(Context context, AttributeSet attrs, int defStyleAttr) {
//        super(context, attrs, defStyleAttr);
//        init(context);
//    }
//    private void init(Context context) {
//        //isInEditMode()should be used inside the Custom View constructor
//        if (!isInEditMode()) {
//            Typeface tf = Typeface.createFromAsset(context.getAssets(), "OpenSans-Light.ttf");
//            setTypeface(tf);
//        }
//    }
}
