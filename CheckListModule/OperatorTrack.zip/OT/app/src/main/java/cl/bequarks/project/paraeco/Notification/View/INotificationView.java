package cl.bequarks.project.paraeco.Notification.View;

public interface INotificationView {

    void onNotificationPublished();

}
