package cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Presenter;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.ResultPicture;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.View.IResultView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBArrayResultView;
import cl.bequarks.project.paraeco.Activity.PresenterBasic;

public class ResutlPicturePresenter extends PresenterBasic<IResultView,ResultPicture> implements IResutlPicturePresenter {


    @Override
    public void getPicturesByCheckListId(long checkListId) {
        model.fetchByCheckListId(checkListId, new IDBArrayResultView<ResultPicture>() {
            @Override
            public void onSuccess(ArrayList<ResultPicture> results) {
                view.PicturesByCheckListId(results);
            }

            @Override
            public void onFail(String error) {
                view.EmptyPicturesWithCheckListId("");
            }
        });
    }

    @Override
    public void insert(ResultPicture resultPicture, int count) {

        long id = resultPicture.insert(resultPicture);
        if (0 <= id){
            view.PictureInsertet(count);
        }else{
            view.PictureNotInserted();
        }

    }
}
