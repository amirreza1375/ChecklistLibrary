package cl.bequarks.project.paraeco.DBHelper;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import static cl.bequarks.project.paraeco.DBHelper.DataBaseConfig.EVENT_DATABASE_NAME;
import static cl.bequarks.project.paraeco.DBHelper.DataBaseConfig.EVENT_VERSION;
import static cl.bequarks.project.paraeco.DBHelper.DataBaseConfig.getLogEventDBVersion;
import static cl.bequarks.project.paraeco.DBHelper.DataBaseConfig.setLogEventDBVersion;


public class LogEventTableDBHelper extends SQLiteOpenHelper {

    public static LogEventTableDBHelper logEventTableDBHelper;


    private LogEventTableDBHelper(@Nullable Context context) {
        super(context, EVENT_DATABASE_NAME, null, EVENT_VERSION);
    }

    public static LogEventTableDBHelper getInstance(Context context) {
        if (logEventTableDBHelper == null)
            logEventTableDBHelper = new LogEventTableDBHelper(context);
        return logEventTableDBHelper;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(FeedReaderContract.LogEventTable.SQL_CREATE_ENTRIES);
        setLogEventDBVersion(EVENT_VERSION);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        if (EVENT_VERSION != getLogEventDBVersion() && getLogEventDBVersion() != 0) {
            sqLiteDatabase.execSQL(FeedReaderContract.LogEventTable.SQL_DELETE_ENTRIES);
            onCreate(sqLiteDatabase);
        }
    }

    public boolean isTableExists(String tableName, boolean openDb) {
        if (getLogEventDBVersion() > 0){
            return true;
        }
        SQLiteDatabase mDatabase = getWritableDatabase();
        Cursor cursor = mDatabase.rawQuery("select DISTINCT tbl_name from sqlite_master where tbl_name = '"+tableName+"'", null);
        if(cursor!=null) {
            if(cursor.getCount()>0) {
                cursor.close();
                return true;
            }
            cursor.close();
        }
        return false;
    }
}
