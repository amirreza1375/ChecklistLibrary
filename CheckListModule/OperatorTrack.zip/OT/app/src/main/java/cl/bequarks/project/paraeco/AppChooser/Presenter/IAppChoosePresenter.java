package cl.bequarks.project.paraeco.AppChooser.Presenter;

public interface IAppChoosePresenter {

    void showAppChooser();

}
