package cl.bequarks.project.paraeco.Activity.ActivityProfile.Presenter;

import android.net.Uri;
import android.os.AsyncTask;

import cl.bequarks.project.paraeco.Activity.ActivityLogin.Model.User;
import cl.bequarks.project.paraeco.Activity.ActivityProfile.View.IProfileView;
import cl.bequarks.project.paraeco.Activity.PresenterBasic;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.Global.SaveImage;
import cl.bequarks.project.paraeco.ServerRequests.IResponseApiToModel;

/**
 * Created by shahr on 2/16/2019.
 */

public class ProfilePresenter extends PresenterBasic<IProfileView,User> {

    private int numberGetProfilePic=0;

    public void setUserData(){
        setProfilePic();
        setName();
        setEmail();
    }
    private void setProfilePic(){
        view.setProfilePic(model.setProfilePic());
    }
    private void setName(){
        view.setName(model.getNameSaved());
    }
    private void setEmail(){
        view.setEmail(model.getEmailSaved());
    }
    public void getProfilePic(){
        numberGetProfilePic++;
        new AsyncProfileImage().execute(model.getPicUrl());
    }
    public void ValidationPass(String newPass,String repeatPass){

        if(newPass.length()>4){
            if(newPass.equals(repeatPass)){
                view.onValidPass();
            }else{
                view.onInvalidPass("notSame");
            }
        }else{
            view.onInvalidPass("length");

        }

    }
    public void ChangePassword(String newPass){
        model.SendChangePasswordRequest(newPass, new IResponseApiToModel() {
            @Override
            public void onFail(String error) {
                view.onNotChagePassword(error);
            }

            @Override
            public <T> void onSuccess(T answer) {
                view.onChangePassword((String)answer);
            }
        });
    }
    public void removeUserInfo(){
        if(model.removeUserInfo()){
            view.onSuccessRemoveUserInfo();
        }else{
            view.onFailRemoveUserInfo();
        }
    };

    public void uploadImage(Uri uri){
        view.showDialog();
        model.uploadProfilePic(uri,new IResponseApiToModel(){

           @Override
           public void onFail(String error) {
               view.dismissDialog();
               view.uploadFail(error);
           }

           @Override
           public <T> void onSuccess(T answer) {
               view.dismissDialog();
               view.uploadSuccess((String)answer);
           }
        });
    }

    class AsyncProfileImage extends AsyncTask<String,Void,Boolean> {

        @Override
        protected Boolean doInBackground(String... strings) {
            return SaveImage.newInstance(G.context).getProfileImageFromServer(strings[0]);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            view.showProfileDialog();
        }

        @Override
        protected void onPostExecute(Boolean result) {
            super.onPostExecute(result);
            if(result){
                numberGetProfilePic =0;
                view.dismissProfileDialog();
                view.profilePicDownloaded();
            }else if (numberGetProfilePic<3){
                getProfilePic();
            }else {
                view.dismissProfileDialog();
            }

        }
    }
}
