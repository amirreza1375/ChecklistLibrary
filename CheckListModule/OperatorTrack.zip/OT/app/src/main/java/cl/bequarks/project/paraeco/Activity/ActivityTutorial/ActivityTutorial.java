package cl.bequarks.project.paraeco.Activity.ActivityTutorial;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ScrollView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.FragmentTransaction;

import cl.bequarks.project.paraeco.Activity.ActivityTutorial.AppTutorial.AppTutorialFragment;
import cl.bequarks.project.paraeco.Activity.ActivityTutorial.CameraTutorial.CameraFragment;
import cl.bequarks.project.paraeco.Activity.ActivityTutorial.ChecklistTutorial.ChecklistTutorialFragment;
import cl.bequarks.project.paraeco.R;

public class ActivityTutorial extends AppCompatActivity implements View.OnClickListener, AppTutorialFragment.OnFragmentInteractionListener
    , ChecklistTutorialFragment.OnFragmentInteractionListener,CameraFragment.OnFragmentInteractionListener {


    private CardView appTutorial;
    private CardView checklistTutorial;
    private CardView cameraTutorial;
    private CardView checklistExam;

    private ScrollView toots;
    private FrameLayout frame;

    private AppTutorialFragment appTutorialFragment;
    private ChecklistTutorialFragment checklistTutorialFragment;
    private CameraFragment cameraFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial);

        appTutorial = findViewById(R.id.appT);
        checklistTutorial = findViewById(R.id.checklistT);
        cameraTutorial = findViewById(R.id.cameraT);
        checklistExam = findViewById(R.id.checklistE);
        toots = findViewById(R.id.toolsScroll);
        frame = findViewById(R.id.frame);

        appTutorial.setOnClickListener(this);
        checklistTutorial.setOnClickListener(this);
        cameraTutorial.setOnClickListener(this);
        checklistExam.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.appT:
                loadAppTutorial();
                break;
            case R.id.checklistT:
                loadChecklistTutorial();
                break;
            case R.id.cameraT:
                loadCameraTutorial();
                break;
        }
    }

    private void loadCameraTutorial() {
        hideTools();
        FragmentTransaction tr = getSupportFragmentManager().beginTransaction();
        cameraFragment = CameraFragment.newInstance("","");
        tr.add(R.id.frame,cameraFragment).commit();
    }

    private void loadChecklistTutorial() {
        hideTools();
        FragmentTransaction tr = getSupportFragmentManager().beginTransaction();
        checklistTutorialFragment = ChecklistTutorialFragment.newInstance("","");
        tr.add(R.id.frame,checklistTutorialFragment).commit();
    }

    private void hideTools(){
        toots.setVisibility(View.GONE);
        frame.setVisibility(View.VISIBLE);
    }

    private void showTools(){
        frame.setVisibility(View.GONE);
        toots.setVisibility(View.VISIBLE);
    }

    private void loadAppTutorial() {
        hideTools();
        FragmentTransaction tr = getSupportFragmentManager().beginTransaction();
        appTutorialFragment = AppTutorialFragment.newInstance("","");
        tr.add(R.id.frame,appTutorialFragment).commit();
    }


    @Override
    public void onAppTutorialFinished() {
        showTools();
    }

    @Override
    public void onChecklistTutorialFinished() {

    }

    @Override
    public void onCameraTutorialFinished() {

    }
}
