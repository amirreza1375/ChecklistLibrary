package cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBArrayResultView;

interface IResultPicture {

    void fetchByCheckListId(long checkListId, IDBArrayResultView<ResultPicture> idbArrayResultView);

}
