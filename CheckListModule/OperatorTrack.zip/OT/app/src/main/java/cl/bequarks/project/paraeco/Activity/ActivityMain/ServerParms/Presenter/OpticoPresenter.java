package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter;

import org.json.JSONArray;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Optico;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBResultView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IOpticoView;
import cl.bequarks.project.paraeco.Activity.PresenterBasic;
import cl.bequarks.project.paraeco.sharedpreference.Config;

public class OpticoPresenter extends PresenterBasic<IOpticoView,Optico> implements IOpticoPresenter {

    public void Insert(final JSONArray opticos) {
        model.refreshTable(opticos, new IDBResultView() {
            @Override
            public void onSuccess() {
                view.OpticoIserted(true);
            }

            @Override
            public void onItemInserted() {
                view.onItemInserted(Config.Params.OPTICO);
            }

            @Override
            public void onFail(String error) {
                view.OpticoIserted(false);
            }
        });

    }

    public void getOpticos() {
        view.Opticos(new Optico().getAllItems());
    }

    public void getOpticoById(long id) {
        view.OpticoById(new Optico().fetchById(id));
    }

    public void OpticoBtShop(int shop_id) {
        view.OpticosByShop(new Optico().fetchByShop(shop_id));
    }

    public void getOpticosByCondition(int shop_id, int ID, int subcanal, int Posiction, int Elemento) {
        view.OpticosByCondition(new Optico().fetchByShopResultId(shop_id, ID, subcanal, Posiction, Elemento));
    }



}
