package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter;

import org.json.JSONArray;

public interface ILayoutPresenter {
    void Insert(JSONArray jSONArray);

    void getLayoutById(long j);

    void getLayouts();

    void getLayoutsByShop(int i);


}
