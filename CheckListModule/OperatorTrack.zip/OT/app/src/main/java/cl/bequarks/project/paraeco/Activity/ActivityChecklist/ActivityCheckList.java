package cl.bequarks.project.paraeco.Activity.ActivityChecklist;

import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Handler;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.TimePicker;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.example.checklist.CheckListGenerator.PageView;
import com.example.checklist.Database.ModuleLogEvent;
import com.example.checklist.GlobalFuncs;
import com.example.checklist.ImageSliderModel;
import com.example.checklist.ImageSliderView.ImagesViewer;
import com.example.checklist.LayoutMaker.LayoutModel;
import com.example.checklist.PageGenerator.CheckListPager;
import com.example.checklist.PictureElement.PicturePickerItemModel;
import com.example.checklist.ProductCounter.ProductModel;
import com.example.checklist.ResultId;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import cl.bequarks.project.paraeco.Activity.ActivityBase;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ActivityMain;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.ResultPicture;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.UserCheckList;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Presenter.UserChecklistPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Presenter.ResutlPicturePresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.View.IUserChecklistView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.View.IResultView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Checklist;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Layout;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Optico;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Product;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.AccessoryPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.CheckListPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.LayoutPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.OpticoPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.ICheckListView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IOpticoView;
import cl.bequarks.project.paraeco.EvenLogger.LogEvent;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.Logger.LogMonitorDataListener;
import cl.bequarks.project.paraeco.Notification.Model.NotificationModel;
import cl.bequarks.project.paraeco.Notification.Presenter.NotificationPresenter;
import cl.bequarks.project.paraeco.Notification.View.INotificationView;
import cl.bequarks.project.paraeco.Permissions.Model.Permission;
import cl.bequarks.project.paraeco.Permissions.Presenter.PermissionPresenter;
import cl.bequarks.project.paraeco.Permissions.View.IPermissionView;
import cl.bequarks.project.paraeco.R;
import cl.bequarks.project.paraeco.ServerRequests.ApiService;
import cl.bequarks.project.paraeco.ServerRequests.LogEventServer.ILogEventListener;
import cl.bequarks.project.paraeco.sharedpreference.Config;

import static android.icu.text.DateTimePatternGenerator.PatternInfo.OK;
import static android.view.View.GONE;
import static cl.bequarks.project.paraeco.sharedpreference.Config.SIGNATURE_DIRECTORY;
import static cl.bequarks.project.paraeco.sharedpreference.Config.appCenterErrorLog;
import static cl.bequarks.project.paraeco.sharedpreference.Config.appCenterLog;
import static cl.bequarks.project.paraeco.sharedpreference.Config.getDate;
import static cl.bequarks.project.paraeco.sharedpreference.Config.getTime;
import static cl.bequarks.project.paraeco.sharedpreference.Config.getUserId;
import static com.example.checklist.GlobalFuncs.addEvenLog;
import static com.example.checklist.GlobalFuncs.showToast;


public class ActivityCheckList extends ActivityBase implements ICheckListView
        , CheckListPager.CheckListListener, IUserChecklistView, IPermissionView
        , IOpticoView, IResultView, INotificationView, View.OnClickListener, LogMonitorDataListener
        , ILogEventListener, ApiService.ApiAuthinticationFailListener
        , LogEvent.BulkInsertListener {

    public String userAgent = "0";

    public static final String ID = "ID";
    public static final String CheckListDataBaseId = "checkListDataBaseId";
    public static final String CheckListDataDataBaseId = "checkListDataDataBaseId";
    private static final String OPENED_CHECKLIST_ID_KEY = "checklistID_OPENED";
    public static String CheckListServerId = "checkListDataId";
    public static String CheckListError = "checklisterror";

    private long checkListDataBaseID;
    private long checkListDataDataBaseId = -1;
    private long checkListServerId;

    private static final String TAG = "ActivityCheckList";

    public static String IsDraft = "isDraft";
    public static String IsCheckList = "isCheckList";
    public static String ShopId = "shopId";
    public static String CheckListName = "checkListName";
    public static String ShopName = "shopName";

    private LinearLayout parent;
    private Button btn_back;
    private Button btn_done;
    private ImageView btnChooseShop;
    private ImageView btnChooseChecklist;
    private ImageView btnShowChecklist;
    private ImageView btnFinishChecklist;

    private CheckListPager pager;

    private NotificationPresenter notificationPresenter;
    private NotificationModel notificationModel;
    private UserChecklistPresenter userChecklistPresenter;
    private CheckListPresenter checkListPresenter;
    private OpticoPresenter opticoPresenter;
    private AccessoryPresenter accessoryPresenter;
    private LayoutPresenter layoutPresenter;
    private ResutlPicturePresenter picturePresenter;

    //    private Checklist currentCheckList;
    private long currentCheckListId;

    private long saveCheckListId = -1;
    private boolean instantlySaved = false;

    private String shopName;
    private String checkListName;
    private String shopId;
    private String startTime;
    private String endTime;
    private boolean isDraft = false;
    private boolean isCheckList = true;
    private boolean notOkToSaveInstantly;

    private boolean isCheckListDataIserted = false;
    private boolean isPictruesInserted = false;
    private int insertedImageCount = 0;

    private PermissionPresenter permissionPresenter;

    private ArrayList<ImageSliderModel> imageSliderModels;

    private ArrayList<PicturePickerItemModel> pics;
    private ArrayList<PicturePickerItemModel> signatures;

    private AlertDialog saveAsDraftDialog;

    private boolean isAppClosed;

    private LinearLayout timeTrackerBtn;
    private AlertDialog timesAlert;

    private TextView choosenProgress;

    @Override
    protected void onResume() {
        super.onResume();
        if (pager != null) {
            pager.updateCheckListView();
            pager.updateMandatory();
        }

        notOkToSaveInstantly = false;
        Log.i(TAG, "onResume: ");

    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG, "onPause: ");
        if (pager != null
                && !notOkToSaveInstantly
                && getPageStatus() != PageView.pageStatus.PREVIEW) {
            isAppClosed = true;
            pager.instantSaveCheckList(true);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "onDestroy: ");
//        if (pager != null
//                && !notOkToSaveInstantly
//                && getPageStatus() != CheckListMaker.pageStatus.PREVIEW) {
//            isAppClosed = true;
//            pager.instantSaveCheckList(true);
//        }
    }


    private void showTimeDialog() {
        TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int i, int i1) {

            }
        }, 0, 0, true);
        timePickerDialog.show();

    }


    @Override
    public void onBackPressed() {
        //super.onBackPressed(); // stop user to finish activity
        //and ask to save or not
        if (pager != null)
            pager.showSaveAsDraftMessage();
        else
            super.onBackPressed();

        Log.i(TAG, "onBackPressed: ");

        btnShowChecklist.setImageDrawable(getResources().getDrawable(R.drawable.ic_autorenew_black_24dp));
        btnFinishChecklist.setImageDrawable(getResources().getDrawable(R.drawable.ic_code_black_24dp));

    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG, "onStop: ");
    }

    private ImageView scrollHint;
    private LinearLayout buttonHolder;
    private ProgressBar checklistLoad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checklist);
        Log.i(TAG, "onCreate: ");

        scrollHint = findViewById(R.id.scrollHint);
        timeTrackerBtn = findViewById(R.id.timerTracker);
        choosenProgress = findViewById(R.id.choosenProgress);
        checklistLoad = findViewById(R.id.checklistLoad);

        timeTrackerBtn.setOnClickListener(this);

        String colorstr = getSharedPreferences(Config.sharedPreferencName, MODE_PRIVATE)
                .getString(Config.color_primary, "");
        if (!colorstr.equals("")) {
            int color = Color.parseColor(colorstr);
        }

        insertedImageCount = 0;

        setStartTime();

        clearImages();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                parent = findViewById(R.id.parent);
                btn_back = findViewById(R.id.btn_back);
                btn_done = findViewById(R.id.btn_done);
                buttonHolder = findViewById(R.id.buttonHolder);

                btnChooseShop = findViewById(R.id.btnChooseShop);
                btnChooseChecklist = findViewById(R.id.btnChooseChecklist);
                btnShowChecklist = findViewById(R.id.btnShowChecklist);
                btnFinishChecklist = findViewById(R.id.btnFinishChecklist);

                imageSliderModels = new ArrayList<>();

                //get currentCheckList id from bundle and get page json with id

                checkListPresenter = new CheckListPresenter();
                checkListPresenter.attachView(ActivityCheckList.this);
                checkListPresenter.addModel(new Checklist());

                userChecklistPresenter = new UserChecklistPresenter();
                userChecklistPresenter.attachView(ActivityCheckList.this);
                userChecklistPresenter.addModel(new UserCheckList());

                opticoPresenter = new OpticoPresenter();
                opticoPresenter.addModel(new Optico());
                opticoPresenter.attachView(ActivityCheckList.this);

                picturePresenter = new ResutlPicturePresenter();
                picturePresenter.attachView(ActivityCheckList.this);
                picturePresenter.addModel(new ResultPicture());

                opticoPresenter.getOpticos();

                permissionPresenter = new PermissionPresenter();
                permissionPresenter.addModel(new Permission(ActivityCheckList.this));
                permissionPresenter.attachView(ActivityCheckList.this);

                notificationPresenter = new NotificationPresenter(new NotificationModel(), ActivityCheckList.this);

                String checklist = "";

                Bundle bundle = getIntent().getExtras();
                if (bundle != null) {
                    userAgent = bundle.getString(Config.USER_AGGENT);
                    checkListDataBaseID = bundle.getLong(CheckListDataBaseId);
                    isDraft = bundle.getBoolean(IsDraft);
                    isCheckList = bundle.getBoolean(IsCheckList);
                    shopId = bundle.getString(ShopId);
                    shopName = bundle.getString(ShopName);
                    checkListName = bundle.getString(CheckListName);

                    String checkListDataDataBaseIdStr = bundle.getString(CheckListDataDataBaseId);
                    checkListDataDataBaseId = Long.parseLong(checkListDataDataBaseIdStr);

                    try {
                        checkListServerId = bundle.getLong(CheckListServerId);

                    } catch (Exception e) {
                        e.printStackTrace();
                        appCenterErrorLog(e.getMessage());
                    }
                }
                permissionPresenter.CheckCameraPermission();

                isLastPageToolbar(false);
            }
        }, 100);

        Log.i(TAG, "onCreate: currentCheckList server id = " + checkListServerId);
        Log.i(TAG, "onCreate: currentCheckList database id = " + checkListDataBaseID);
        Log.i(TAG, "onCreate: currentCheckList data database id = " + checkListDataDataBaseId);
    }

    private void clearImages() {

        SharedPreferences.Editor editor = getSharedPreferences(Config.sharedPreferencName, MODE_PRIVATE)
                .edit();
        editor.putString(Config.pictures, "[]").apply();
        String pics = getSharedPreferences(Config.sharedPreferencName, MODE_PRIVATE).getString(Config.pictures, "");
        Log.i(TAG, "clearImages: ");
    }

    private void triggerPresenterByStatus(PageView.pageStatus pageStatus) {
        switch (pageStatus) {
            case CHECKLIST:
                checkListPresenter.getCheckListById(checkListDataBaseID);
                break;
            case DRAFT:
                userChecklistPresenter.getCheckListAndPictures(checkListDataDataBaseId);
                break;
            case PREVIEW:
                btnShowChecklist.setImageResource(R.drawable.ic_done_black_24dp);
                btnFinishChecklist.setImageResource(R.drawable.ic_done_black_24dp);
                userChecklistPresenter.getCheckListAndPictures(checkListDataDataBaseId);
                break;
        }
    }


    private PageView.pageStatus getPageStatus() {
        if (isCheckList) {
            return PageView.pageStatus.CHECKLIST;
        }
        if (isDraft) {
            return PageView.pageStatus.DRAFT;
        } else {
            return PageView.pageStatus.PREVIEW;
        }
    }

    private void savePicturesInDataBase(final ArrayList<PicturePickerItemModel> pics, final long checkListDataId) {

//        removeImagesWithUserCheckListId(checkListDataId);
//
        for (int i = 0; i < pics.size(); i++) {
            PicturePickerItemModel pic = pics.get(i);
            ResultPicture model = new ResultPicture();
            model.setCheckListDataBaseId(checkListDataId);
            model.setImage_type(pic.getCat_id());
            model.setName(pic.getName());
            model.setPath(pic.getPath());
            model.setPic_index(pic.getIndex());
            model.setProccessing(0);
            model.setQuestion_id(pic.getId());
            model.setPosition(pic.getPosition());
            model.setSynced(0);
            model.setServer_id(-1);

            picturePresenter.insert(model, pics.size());

        }

        if (pics.size() == 0) {
            isPictruesInserted = true;
            if (isCheckListDataIserted && !instantlySaved) {
                goToMainPage();
                Log.i(TAG, "savePicturesInDataBase: ");
            }
        }


    }

    private void goToMainPage() {
//        startActivity(new Intent(this,ActivityMain.class));
//        setResult(OK,new Intent().putExtra(OPENED_CHECKLIST_ID_KEY,checkListDataDataBaseId));
        finish();

    }

    private void removeImagesWithUserCheckListId(long checkListDataId, ArrayList<PicturePickerItemModel> pics) {
//        new ResultPicture().removeImages(checkListDataId, pics);
    }


    private void isLastPageToolbar(boolean status) {
        btnChooseShop.setImageDrawable(getResources().getDrawable(R.drawable.ic_done_black_24dp));
        btnChooseChecklist.setImageDrawable(getResources().getDrawable(R.drawable.ic_done_black_24dp));
        if (status) {
            btnShowChecklist.setImageDrawable(getResources().getDrawable(R.drawable.ic_done_black_24dp));
            btnFinishChecklist.setImageDrawable(getResources().getDrawable(R.drawable.ic_autorenew_black_24dp));
        } else {
            btnShowChecklist.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_autorenew_black_24dp));
            btnFinishChecklist.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_code_black_24dp));
        }
    }

    private void removeParentButtuns() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                buttonHolder.setVisibility(GONE);
                btn_done.setVisibility(GONE);
                btn_back.setVisibility(GONE);
            }
        });
    }

    private void showParentButtons() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                buttonHolder.setVisibility(View.VISIBLE);
                btn_done.setVisibility(View.VISIBLE);
                btn_back.setVisibility(View.VISIBLE);
            }
        });
    }

    //region check lists

    @Override
    public void CheckLsits(List<Checklist> list) {

    }

    @Override
    public void Checklist(Checklist checklist) {
        if (checklist != null) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    choosenProgress.setText(shopName + "  >>  " + checkListName);
                }
            });
//            this.currentCheckList = checklist;
            this.currentCheckListId = checklist.get_ID();
            pager = new CheckListPager(this, checklist.getJOSN(), buttonHolder, btn_back, btn_done
                    , new ArrayList<PicturePickerItemModel>(), PageView.pageStatus.CHECKLIST, new JSONArray()
                    , imageSliderModels
                    , SIGNATURE_DIRECTORY
                    , ActivityCheckList.this
                    , Integer.valueOf(shopId)
                    , getLayouts()
                    , -1
                    , getProducts()
                    , checkListServerId + ""
                    , Config.APP_FOLDER_NAME
                    , Config.APP_FOLDER_PRICTURES);
//            pager.setListListener(ActivityCheckList.this);
            parent.addView(pager);
        } else {
            goToMainPage();
            Log.i(TAG, "Checklist: ");
        }


    }

    private ArrayList<ProductModel> getProducts() {
        Product product = new Product();
        ArrayList<ProductModel> productModels = new ArrayList<>();
        List<Product> products = product.getAllItems();
        for (int i = 0; i < products.size(); i++) {
            ProductModel productModel = new ProductModel(
                    products.get(i).getProductId(),
                    products.get(i).getStock(),
                    products.get(i).getShop(),
                    products.get(i).getTitle()
            );
            productModels.add(productModel);
        }
        return productModels;

    }

    private ArrayList<LayoutModel> getLayouts() {
        Layout layout = new Layout();
        List<Layout> layouts = layout.getAllItems();
        ArrayList<LayoutModel> layoutModels = new ArrayList<>();
        for (int i = 0; i < layouts.size(); i++) {
            Layout layoutTemp = layouts.get(i);
            LayoutModel model = new LayoutModel(
                    layout.getOrderId() + ""
                    , layoutTemp.getName()
                    , layoutTemp.getImg()
                    , layoutTemp.getShops()
                    , ""
                    , layoutTemp.getPositions() + ""
                    , layoutTemp.getImgPath()
                    , ""
                    , layoutTemp.getReplaceMent() + ""
            );
            layoutModels.add(model);
        }

        return layoutModels;
    }


    @Override
    public void CheckListInserted(boolean status) {

    }

    @Override
    public void TypeCheckList(ArrayList<Checklist> arrayList) {

    }

    @Override
    public void NoCheckListWithThisType(String error) {

    }

    @Override
    public void CheckListByTypeAndSubCanal(ArrayList<Checklist> checkLists) {

    }

    @Override
    public void onItemInserted(String name) {


    }

    //endregion

    //region finish page


    private void saveData(ArrayList<PicturePickerItemModel> pics, ArrayList<PicturePickerItemModel> signatures, JSONArray checkListAnswer
            , boolean isDraft, int userPagePosition) {
        HashMap<String, String> params = new HashMap<>();
        params.put("ChecklistServerId", checkListServerId + "");
        params.put("ShopId", shopId);
        params.put("Answers", checkListAnswer.toString());
        params.put("isDraft", isDraft + "");
        params.put("UserPagePosition", userPagePosition + "");
        params.put("PicsNumber", pics.size() + "");
        params.put("ChecklistDataBaseId", checkListDataDataBaseId + "");
        appCenterLog("SaveData", params);
        addEvenLog(this, -1, checkListDataDataBaseId + "", "Save data", "N/I ", "");

        notOkToSaveInstantly = true;
        if (checkListDataDataBaseId == -1) {
            setEndTime();
            UserCheckList userCheckList = new UserCheckList(getCheckListJson(currentCheckListId), checkListAnswer.toString()
                    , 0, isDraft ? 1 : 0, getTime(), getDate(), shopName, checkListName, shopId, checkListServerId + ""
                    , getStartTime(), getEndTime(), 0, 0, getUserId(this)
                    , 0, Config.getServer(G.context), "", userPagePosition, 0);

            if (userAgent.equals("2"))//this defines thre result is ticket or not
                userCheckList.setIsTicket(1);

            userChecklistPresenter.insert(userCheckList);

        } else {
            removeImagesWithUserCheckListId(checkListDataDataBaseId, pics);
            updateData(isDraft, checkListDataDataBaseId, pics, signatures, checkListAnswer, userPagePosition);
        }
    }

    private String getCheckListJson(long currentCheckListId) {
        return new Checklist().fetchById(currentCheckListId).getJOSN().toString();
    }

    private void updateData(boolean isDraft, long checkListDataDataBaseId, ArrayList<PicturePickerItemModel> pics
            , ArrayList<PicturePickerItemModel> signatures, JSONArray checkListAnswer, int userPagePosition) {
        UserCheckList userCheckList = new UserCheckList().fetchById(checkListDataDataBaseId);
        userCheckList.setAnswerJson(checkListAnswer.toString());
        userCheckList.setDate(getDate());
        userCheckList.setTime(getTime());
        userCheckList.setDraft(isDraft ? 1 : 0);
        userCheckList.setPagePosition(userPagePosition);
        userCheckList.deleteUserData(userCheckList);
        userChecklistPresenter.insert(userCheckList);
//        userCheckList.update(userCheckList);


        savePicturesInDataBase(pics, userCheckList.get_ID());//currentCheckList images
        savePicturesInDataBase(signatures, userCheckList.get_ID());//currentCheckList signature images

        if (!instantlySaved) {
            goToMainPage();
        }
    }

    private void setErrorLogsOfModule(ArrayList<String> errors) {
        for (String error : errors) {
            appCenterErrorLog(error);
        }
    }

    @Override
    public void SaveAsDraft(JSONArray array, ArrayList<PicturePickerItemModel> pics, boolean isAppClosed, ArrayList<PicturePickerItemModel> signatures, ArrayList<String> errors) {
        instantlySaved = false;
        this.pics = pics;
        this.signatures = signatures;
        setErrorLogsOfModule(errors);
        saveData(pics, signatures, array, true, -1);
    }


    @Override
    public void SaveAsFinished(JSONArray array, ArrayList<PicturePickerItemModel> pics, ArrayList<PicturePickerItemModel> signatures, ArrayList<String> errors) {
        this.pics = pics;
        this.signatures = signatures;
        instantlySaved = false;
        setErrorLogsOfModule(errors);
        if (array != null) {

            if (array.length() == 0 && pics.size() == 0 && signatures.size() == 0) {
                showToast(ActivityCheckList.this, getString(R.string.emptyData));
            } else {

                saveData(pics, signatures, array, false, -1);
            }
        } else {
            showToast(ActivityCheckList.this, getString(R.string.emptyData));
        }

    }

    private void sendLogs() {
        new LogEvent().getNotSyncedJsonArray(this);
    }

    @Override
    public void instantSaveCall(JSONArray array, ArrayList<PicturePickerItemModel> pics, boolean isAppClosed, ArrayList<PicturePickerItemModel> signatures, int userPagePosition, ArrayList<String> errors) {
        instantlySaved = true;
        this.pics = pics;
        this.signatures = signatures;
        saveData(pics, signatures, array, true, userPagePosition);
        setErrorLogsOfModule(errors);
        if (isAppClosed)
            if (getPageStatus() == PageView.pageStatus.CHECKLIST
                    || getPageStatus() == PageView.pageStatus.DRAFT)
                notificationPresenter.showNotification();


    }

    @Override
    public void CheckListMessage(String msg) {
        showToast(ActivityCheckList.this, msg);
    }

    @Override
    public void ImageSliderError(String err, ImagesViewer.ImageStatus errCode) {

    }

    @Override
    public void onPageChanged(int mode) {
        scrollHint.setVisibility(View.VISIBLE);
        AlphaAnimation aa = new AlphaAnimation(0.0f, 1.0f);
        aa.setDuration(1000);
        aa.setRepeatCount(3);
        aa.setRepeatMode(Animation.REVERSE);
        scrollHint.startAnimation(aa);
        aa.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                scrollHint.setVisibility(GONE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

    @Override
    public void TimeTrackerStatus(boolean status) {
        if (status) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    timeTrackerBtn.setVisibility(View.VISIBLE);
                }
            });

        } else {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    timeTrackerBtn.setVisibility(GONE);
                }
            });
        }

    }

    @Override
    public void onError(String error) {
        appCenterErrorLog(error);
    }

    @Override
    public void LogEvent(ArrayList<ModuleLogEvent> moduleLogEvents) {
        new LogEvent().bulkAddItems(moduleLogEvents, this);
    }

    @Override
    public void onShowChecklistLoad() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                checklistLoad.setVisibility(View.VISIBLE);
                parent.setVisibility(GONE);
            }
        });

    }

    @Override
    public void onHideCehcklistLoad() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        checklistLoad.setVisibility(GONE);
                        parent.setVisibility(View.VISIBLE);
                    }
                });
            }
        }, 200);

    }

    @Override
    public void showSavingLoad() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                checklistLoad.setVisibility(View.VISIBLE);
                parent.setVisibility(GONE);
            }
        });
    }

    @Override
    public void Finished() {
        removeParentButtuns();
        isLastPageToolbar(true);
    }


    @Override
    public void onBackClicked() {
        showParentButtons();
        isLastPageToolbar(false);
    }

    @Override
    public void CheckListHasError(String error) {
        showToast(ActivityCheckList.this, error);
        Intent intent = new Intent(ActivityCheckList.this
                , ActivityMain.class);
        intent.putExtra(CheckListError, error);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        addEvenLog(ActivityCheckList.this, -1, error, "Checklist error", "N/I", "");
        sendLogs();
        startActivity(intent);
    }

    @Override
    public void closeChecklist() {
        goToMainPage();
        Log.i(TAG, "closeChecklist: ");
    }

    @Override
    public void StopFromSaving() {
        Log.i(TAG, "StopFromSaving: ");
        notOkToSaveInstantly = true;
    }

    @Override
    public void ChecklistErrorMessage(String msg) {
        showToast(ActivityCheckList.this, msg);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 111) {
            if (resultCode == 0) {
                if (pager != null) {
                    pager.instantSaveCheckList(true);
                }
            }
        }
    }
    //endregion


    //region currentCheckList data view

    @Override
    public void CheckListDataInserted(long id) {
        HashMap<String, String> param = new HashMap<>();

        param.put("SaveChecklistId", id + "");

        this.checkListDataDataBaseId = id;
        savePicturesInDataBase(pics, id);
        savePicturesInDataBase(signatures, id);
        isCheckListDataIserted = true;

        param.put("CachedChecklistId", checkListDataDataBaseId + "");

        appCenterLog("Inserted Result", param);

        if (isAppClosed) {
            SharedPreferences.Editor editor = getSharedPreferences(Config.sharedPreferencName, MODE_PRIVATE).edit();
            editor.putLong(Config.saveByNotifId, id).apply();
        }

        if (isPictruesInserted && !instantlySaved) {
            goToMainPage();
            Log.i(TAG, "CheckListDataInserted: ");
        }
    }

    @Override
    public void CheckListDataNotInserted(String err) {
        showToast(ActivityCheckList.this, err);
    }

    @Override
    public void CheckListItemsByUserAndDate(ArrayList<UserCheckList> userCheckLists) {

    }

    @Override
    public void CheckListDataItemsEmpty() {

    }

    @Override
    public void CheckListById(UserCheckList userCheckList) {
        if (userCheckList != null) {
            try {
                pager = new CheckListPager(this, new JSONObject(userCheckList.getCheckListJson()), buttonHolder, btn_back, btn_done
                        , new ArrayList<PicturePickerItemModel>(), getPageStatus(), new JSONArray(userCheckList.getAnswerJson())
                        , imageSliderModels, SIGNATURE_DIRECTORY, ActivityCheckList.this, Integer.valueOf(shopId), getLayouts()
                        , userCheckList.getPagePosition(), getProducts(), checkListServerId + "", Config.APP_FOLDER_NAME
                        , Config.APP_FOLDER_PRICTURES);
//            pager.setListListener(ActivityCheckList.this);
                parent.addView(pager);
            } catch (JSONException e) {
                e.printStackTrace();
                appCenterErrorLog(e.getMessage());
                goToMainPage();
                Log.i(TAG, "CheckListById: " + e.getMessage());
                appCenterErrorLog(e.getMessage());
            }
        } else {
            goToMainPage();
            Log.i(TAG, "CheckListById: ");
        }

    }

    @Override
    public void CheckListNotFound() {

    }

    @Override
    public void CheckListSynced() {

    }

    @Override
    public void CheckListNotSynced() {

    }

    @Override
    public void CheckListDataAndPictures(final UserCheckList userCheckList, ArrayList<PicturePickerItemModel> answerPics) {
        if (userCheckList != null) {

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    choosenProgress.setText(userCheckList.getShop_name() + "  >>  " + userCheckList.getCheckList_name());
                }
            });

            this.checkListDataDataBaseId = userCheckList.get_ID();

            addPicturesToShP(answerPics);

            try {
                pager = new CheckListPager(this
                        , new JSONObject(userCheckList.getCheckListJson())
                        , buttonHolder
                        , btn_back
                        , btn_done
                        , answerPics
                        , getPageStatus()
                        , new JSONArray(userCheckList.getAnswerJson())
                        , imageSliderModels
                        , SIGNATURE_DIRECTORY
                        , ActivityCheckList.this
                        , Integer.valueOf(userCheckList.getShop_id())
                        , getLayouts()
                        , userCheckList.getPagePosition()
                        , getProducts()
                        , checkListServerId + ""
                        , Config.APP_FOLDER_NAME
                        , Config.APP_FOLDER_PRICTURES);
//                pager.setListListener(ActivityCheckList.this);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        parent.addView(pager);
                        checklistLoad.setVisibility(GONE);
                        parent.setVisibility(View.VISIBLE);
                    }
                });

            } catch (JSONException e) {
                e.printStackTrace();
                appCenterErrorLog(e.getMessage());
                goToMainPage();
                appCenterErrorLog(e.getMessage());
                Log.i(TAG, "CheckListDataAndPictures: ");
            }
        } else {
            goToMainPage();
            Log.i(TAG, "CheckListDataAndPictures: ");
        }
    }


    @Override
    public void NoCheckLisAndPictures() {

    }

    @Override
    public void NoDeletedItem() {

    }

    @Override
    public void onDeletedItemsRecieved(ArrayList<UserCheckList> results) {

    }

    @Override
    public void allDeletedsRemoved() {

    }

    //endregion

    private void addPicturesToShP(ArrayList<PicturePickerItemModel> answerPics) {
        JSONArray pics = GlobalFuncs.convert_PictureModel_to_JSONArrary(answerPics);

        SharedPreferences.Editor editor = getSharedPreferences(Config.sharedPreferencName, MODE_PRIVATE)
                .edit();
        editor.putString(Config.pictures, pics.toString()).apply();

    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//dd/MM/yyyy
        Date now = new Date();
        String startTime = sdfDate.format(now);
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//dd/MM/yyyy
        Date now = new Date();
        String endTime = sdfDate.format(now);
        this.endTime = endTime;
    }

    @Override
    public void StoragePermission(boolean status) {

    }

    @Override
    public void LocationPermission(boolean status) {

    }

    @Override
    public void CameraPermission(boolean status) {
        if (status) {
            triggerPresenterByStatus(getPageStatus());
        } else {
            permissionPresenter.getCameraPermission();
        }
    }

    @Override
    public void ReadStoragePermission(boolean status) {

    }

    //endregion


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 103) {
            if (grantResults[0] == OK) {
                triggerPresenterByStatus(getPageStatus());
            } else {
                goToMainPage();
                Log.i(TAG, "onRequestPermissionsResult: ");
            }
        }
    }

    //region optico view

    @Override
    public void OpticoById(Optico optico) {

    }

    @Override
    public void OpticoIserted(boolean status) {

    }

    @Override
    public void Opticos(List<Optico> opticos) {
        for (int i = 0; i < opticos.size(); i++) {
            try {

                Optico optico = opticos.get(i);

                ImageSliderModel model = new ImageSliderModel();
                model.setImageFile(new File(optico.getImgPath()));
                model.setName(optico.getOpticoName());
                model.setPrioritie(String.valueOf(optico.getPriority()));
                model.setShops(Optico.convert_String_to_ArrayListInteger(optico.getShop_id_String()));

                JSONArray results = new JSONArray(optico.getResult_id_String());

                ArrayList<ResultId> resultIds = new ArrayList<>();

                for (int j = 0; j < results.length(); j++) {


                    JSONObject result = results.getJSONObject(j);

                    ResultId resultId = new ResultId();
                    resultId.setID(result.getInt(GlobalFuncs.conf_ID));
                    resultId.setElemento(result.getInt(GlobalFuncs.conf_Elemento));
                    resultId.setPosicion(result.getInt(GlobalFuncs.conf_Posicion));
                    resultId.setSubCanal(result.getInt(GlobalFuncs.conf_Subcanal));

                    resultIds.add(resultId);

                }

                model.setResultIDS(resultIds);

                imageSliderModels.add(model);

            } catch (JSONException e) {
                e.printStackTrace();
                appCenterErrorLog(e.getMessage());
                appCenterErrorLog(e.getMessage());
            }
        }//end of list for
    }

    //endregion

    //region pictures
    @Override
    public void OpticosByCondition(List<Optico> list) {

    }

    @Override
    public void OpticosByShop(List<Optico> list) {

    }

    @Override
    public void PicturesByCheckListId(ArrayList<ResultPicture> pictures) {

    }

    @Override
    public void EmptyPicturesWithCheckListId(String message) {

    }

    @Override
    public void PictureInsertet(int count) {
        insertedImageCount++;
        if (insertedImageCount >= count) {
            isPictruesInserted = true;
            if (isCheckListDataIserted) {
                goToMainPage();
                Log.i(TAG, "PictureInsertet: ");
            }
        }
    }

    @Override
    public void PictureNotInserted() {

    }

    @Override
    public void onNotificationPublished() {

    }

    @Override
    public void onClick(View view) {
        if (view == timeTrackerBtn) {
            pager.showTimeTracker();
        }

//        if (view == startTimeTxt || view == lineStartTxt || view == cashierAttentionTxt || view == foodPreparingTxt || view == foodDeliveryTxt) {
//            TextView textView = (TextView) view;
////            setCurrentTimeOnTextView(textView);
//        }
//        if (view == cancelBtn) {
//            timesAlert.dismiss();
//        }
//        if  (view == saveBtn){
//            saveTimeDate();
//        }


    }

    //endregion

    @Override
    public void onDataRecieved(JSONArray data) {
        new ApiService(this).sendLogEvents(data, ActivityCheckList.this);
    }

    @Override
    public void onDataEmpty() {

    }

    @Override
    public void onSent(JSONArray data) {
        new LogEvent().setAllSentSynced(data);
    }

    @Override
    public void onFailedToSend() {

    }


    @Override
    public void onAtuhinticationFailed() {

    }

    @Override
    public void onInserted() {
        sendLogs();
    }
}
