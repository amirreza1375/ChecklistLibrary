package cl.bequarks.project.paraeco.ServerRequests;

public interface IResponsePicture {


     void NoPictures();

    void PicturesSynced();

    void FailedToSync(String error);

    void onPictureSynced(int toatal,int synced);

    void message(String msg);

    void imageUploadProgress(int progress);
}

