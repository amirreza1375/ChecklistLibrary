package cl.bequarks.project.paraeco.ServerRequests;

interface IResponseSyncedPics {

    void OnError(String error);

    void OnNetworkError();

    void SyncedPictures(String[] pics);

}
