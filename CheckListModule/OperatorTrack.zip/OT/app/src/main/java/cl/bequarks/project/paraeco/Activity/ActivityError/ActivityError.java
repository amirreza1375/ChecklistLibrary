package cl.bequarks.project.paraeco.Activity.ActivityError;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import cl.bequarks.project.paraeco.Activity.ActivityBase;
import cl.bequarks.project.paraeco.Activity.ActivitySplash.ActivitySplash;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.R;

public class ActivityError extends ActivityBase implements View.OnClickListener {

    public static String ERROR = "error";

    private TextView errorTxt;
    private Button submitBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_error);

        submitBtn = findViewById(R.id.button);
        errorTxt = findViewById(R.id.errorTxt);

        submitBtn.setOnClickListener(this);

        Bundle bundle = getIntent().getExtras();

        if (bundle != null){

            String error = bundle.getString(ERROR);

            errorTxt.setText(error);

            new Thread(new Runnable() {
                @Override
                public void run() {
                    MediaPlayer mediaPlayer = MediaPlayer.create(G.context, R.raw.crashsound);
                    mediaPlayer.setVolume(0.4f, 0.4f);
                    mediaPlayer.start();
                }
            }).start();

        }

    }

    @Override
    public void onClick(View v) {
        if (v == submitBtn){



            startActivity(new Intent(ActivityError.this
            ,ActivitySplash.class));
            finish();
        }
    }
}
