package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model;

import java.util.ArrayList;
import java.util.List;

public interface IAccessory {


    ArrayList<Accessory> fetchByShop(int i);

    List<Accessory> fetchByShopResultId(int i, int i2, int i3, int i4, int i5);

    String getEndDate();

    String getImg();

    String getImgPath();

    String getAccessoryName();

    String getResultId();

    String getShopId();

    String getStartDate();

}
