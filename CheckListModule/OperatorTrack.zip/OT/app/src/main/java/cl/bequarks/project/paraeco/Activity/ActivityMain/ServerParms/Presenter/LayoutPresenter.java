package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter;

import org.json.JSONArray;


import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Layout;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBResultView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.ILayoutView;
import cl.bequarks.project.paraeco.Activity.PresenterBasic;
import cl.bequarks.project.paraeco.sharedpreference.Config;

public class LayoutPresenter extends PresenterBasic<ILayoutView,Layout> implements ILayoutPresenter {

    public void Insert(final JSONArray layouts) {
    model.refreshTable(layouts, new IDBResultView() {
        @Override
        public void onSuccess() {
            view.LayoutInserted(true);
        }

        @Override
        public void onItemInserted() {
            view.onItemInserted(Config.Params.LAYOUT);
        }

        @Override
        public void onFail(String error) {
            view.LayoutInserted(false);
        }
    });
    }

    public void getLayouts() {
        view.Layouts(model.getAllItems());
    }

    public void getLayoutById(long id) {
        view.LayoutById(model.fetchById(id));
    }

    public void getLayoutsByShop(int shop_id) {
        view.LayoutsByShop(model.fetchLayoutByShop(shop_id));
    }


}
