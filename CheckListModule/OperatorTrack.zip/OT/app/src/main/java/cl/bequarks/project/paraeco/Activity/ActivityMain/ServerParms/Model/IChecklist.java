package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBArrayResultView;

import org.json.JSONObject;

public interface IChecklist {

    void fetchByType(int i, IDBArrayResultView<Checklist> callBack);
    String getCategory();
    long getCheckId();
    JSONObject getJOSN();
    String getTitle();
    int getType();
    void fetchByTypeAndSubCanal(String shopId ,int eq, int eq1, IDBArrayResultView<Checklist> callBack);

}
