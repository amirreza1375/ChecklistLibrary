package cl.bequarks.project.paraeco.DBHelper;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.sharedpreference.Config;

import static cl.bequarks.project.paraeco.DBHelper.DataBaseConfig.DATABASE_NAME;
import static cl.bequarks.project.paraeco.DBHelper.DataBaseConfig.VERSION;
import static cl.bequarks.project.paraeco.DBHelper.DataBaseConfig.getResultDB_VERSION;
import static cl.bequarks.project.paraeco.DBHelper.DataBaseConfig.setResultDB_VERSION;

public class RunTimeTableDBHelper extends SQLiteOpenHelper {

    //    public static final int DATABASE_VERSION = 1;

    private String SQL_DELETE_ENTRIES = "";
    private String SQL_CREATE_ENTRIES = "";


    public RunTimeTableDBHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    public boolean isTableExists(String tableName, boolean openDb) {
        if (getResultDB_VERSION() > 0){
            return true;
        }
        SQLiteDatabase mDatabase = getWritableDatabase();
        if(openDb) {
            if(mDatabase == null || !mDatabase.isOpen()) {
                mDatabase = getReadableDatabase();
            }

            if(!mDatabase.isReadOnly()) {
                mDatabase.close();
                mDatabase = getReadableDatabase();
            }
        }

        Cursor cursor = mDatabase.rawQuery("select DISTINCT tbl_name from sqlite_master where tbl_name = '"+tableName+"'", null);
        if(cursor!=null) {
            if(cursor.getCount()>0) {
                cursor.close();
                return true;
            }
            cursor.close();
        }
        return false;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(FeedReaderContract.UserChecklistTable.SQL_CREATE_ENTRIES);
        db.execSQL(FeedReaderContract.PictureTable.SQL_CREATE_ENTRIES);
        setResultDB_VERSION(VERSION);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over
        if (newVersion > getResultDB_VERSION()) {
            db.execSQL(FeedReaderContract.UserChecklistTable.SQL_DELETE_ENTRIES);
            db.execSQL(FeedReaderContract.PictureTable.SQL_DELETE_ENTRIES);
            onCreate(db);
        }
    }

    private void clearVersion() {
        SharedPreferences.Editor editor = G.context.getSharedPreferences(Config.sharedPreferencName,Context.MODE_PRIVATE)
                .edit();
        editor.putString(Config.version,"").apply();
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }
}
