package cl.bequarks.project.paraeco.Adapter;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;

import androidx.viewpager.widget.ViewPager;

/**
 * this is custom view pager
 * force touch event not to swipe
 */

public class CustomViewPager extends ViewPager {

    private static final String TAG = "CustomViewPager";
    private boolean enabled = true;

    public CustomViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.enabled = true;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
                    return false;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent event) {


        return false;
    }

    public void setPagingEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}
