package cl.bequarks.project.paraeco.Activity.ActivityProfile.View;

import android.graphics.Bitmap;

/**
 * Created by shahr on 2/16/2019.
 */

public interface IProfileView {

    void showDialog();
    void dismissDialog();

    void setProfilePic(Bitmap bitmap);
    void setName(String name);
    void setEmail(String email);

    void onValidPass();
    void onInvalidPass(String error);

    void onChangePassword(String message);
    void onNotChagePassword(String message);

    void onSuccessRemoveUserInfo();
    void onFailRemoveUserInfo();


    void uploadSuccess(String newUrl);
    void uploadFail(String error);

    void profilePicDownloaded();
    void showProfileDialog();
    void dismissProfileDialog();

}
