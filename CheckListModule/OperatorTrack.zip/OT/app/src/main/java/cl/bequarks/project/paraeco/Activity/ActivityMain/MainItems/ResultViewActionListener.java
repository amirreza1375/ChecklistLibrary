package cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems;

public interface ResultViewActionListener {
    void onItemClicked(boolean isDraft, boolean isSynced, long checklistId
            , long checkListDataId, String shopId, String shopName, String checkListName);

    void onItemLongCicked(String Error, long id,int position,ResultHolder holder);

    void removeItem(long id);

    void innnerUpdateStart();

    void updateRow(int position,long id);
}
