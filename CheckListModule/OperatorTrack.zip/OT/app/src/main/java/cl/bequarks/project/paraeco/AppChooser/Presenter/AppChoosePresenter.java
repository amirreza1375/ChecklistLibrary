package cl.bequarks.project.paraeco.AppChooser.Presenter;

import android.view.ViewGroup;

import cl.bequarks.project.paraeco.AppChooser.Model.AppChooseModel;
import cl.bequarks.project.paraeco.AppChooser.Model.IChooseStatusListener;
import cl.bequarks.project.paraeco.AppChooser.View.IAppChooseView;

public class AppChoosePresenter implements IAppChoosePresenter {

    private ViewGroup root;
    private IAppChooseView view;

    public AppChoosePresenter(ViewGroup root, IAppChooseView view){

        this.root = root;
        this.view = view;
    }

    @Override
    public void showAppChooser() {
        AppChooseModel model = new AppChooseModel();
        model.askUserApp(root, new IChooseStatusListener() {
            @Override
            public void onAppChoosen() {
                view.AppChoosen();
            }
        });
    }
}
