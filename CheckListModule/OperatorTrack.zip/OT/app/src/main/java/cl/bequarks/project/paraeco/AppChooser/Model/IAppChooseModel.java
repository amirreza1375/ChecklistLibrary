package cl.bequarks.project.paraeco.AppChooser.Model;

import android.app.AlertDialog;
import android.view.ViewGroup;

import java.util.ArrayList;

public interface IAppChooseModel {

    void askUserApp(ViewGroup root , IChooseStatusListener listener);

    void setAppInfo(int position);

    AlertDialog.Builder initDialog(ViewGroup root);

    ArrayList<String> getAppNames();

}
