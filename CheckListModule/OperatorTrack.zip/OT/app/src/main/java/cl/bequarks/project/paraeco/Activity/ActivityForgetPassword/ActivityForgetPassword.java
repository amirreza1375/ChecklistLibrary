package cl.bequarks.project.paraeco.Activity.ActivityForgetPassword;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.google.android.material.snackbar.Snackbar;

import cl.bequarks.project.paraeco.Activity.ActivityBase;
import cl.bequarks.project.paraeco.Activity.ActivityForgetPassword.Model.ForgetPassword;
import cl.bequarks.project.paraeco.Activity.ActivityForgetPassword.Presenter.ForgetPasswordPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityForgetPassword.View.IForgetPasswordView;
import cl.bequarks.project.paraeco.Activity.ActivityLogin.ActivityLogin;
import cl.bequarks.project.paraeco.R;
import cl.bequarks.project.paraeco.sharedpreference.Config;
public class ActivityForgetPassword extends ActivityBase implements IForgetPasswordView,View.OnClickListener{

    private ForgetPasswordPresenter presenter;
    private ForgetPassword model;


    private ProgressBar top_loading;
    private Button btn_send;
    private EditText email;
    private ImageView back;
    private ConstraintLayout parent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_new);

        //region find views
        back = findViewById(R.id.back);
        top_loading = findViewById(R.id.top_loading);
        btn_send = findViewById(R.id.btn_send);
        email = findViewById(R.id.edt_email);
        parent = findViewById(R.id.parent);
        //endregion

        //region MVP
        presenter = new ForgetPasswordPresenter();
        presenter.attachView(this);
        model = new ForgetPassword();
        presenter.addModel(model);
        //endregion

        btn_send.setOnClickListener(this);
        back.setOnClickListener(this);

    }

    private String getEmail(){
        return email.getText().toString();
    }

    private String getAuthKey(){
        //TODO: how we access to AuthKey when there isnt any login?
        String authKey = getSharedPreferences(Config.sharedPreferencName,MODE_PRIVATE)
                .getString(Config.tokken,"");
        return authKey;
    }

    @SuppressLint ("HardwareIds")
    private String getDevId(){
        return Settings.Secure.getString(ActivityForgetPassword.this.getContentResolver(),
                Settings.Secure.ANDROID_ID);
    }
    private String getVersionApp(){
        PackageInfo pInfo = null;
        try {
            pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        if (pInfo != null) {
            return pInfo.versionName;
        }
        return "";
    }

    @Override
    public void OnValidEmail() {
        presenter.sendForgetPasswordEmail(getEmail(),getDevId());
    }

    @Override
    public void OnInvalidEmail() {
        this.email.setError(getResources().getString(R.string.invalid_email));
    }

    @Override
    public void OnRequestSuccess(String answer) {
        Snackbar.make(parent,answer, Snackbar.LENGTH_INDEFINITE).setAction("Si"
                , new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        startActivity(new Intent(ActivityForgetPassword.this, ActivityLogin.class));
                        finish();
                    }
                }).show();

    }

    @Override
    public void OnRequestFailed(String error) {
        Toast.makeText(this, error, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClick(View view) {
        if (view == btn_send){
            presenter.checkValidation(getEmail());
        }
        if (view == back){
            overridePendingTransition(R.anim.open_scale,R.anim.close_scale);
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.open_scale,R.anim.close_scale);
        finish();
    }
}