package cl.bequarks.project.paraeco.AppChooser.View;

public interface IAppChooseView {

    void showAppChooseDialog();

    void AppChoosen();

    void AppNotChoosen();

}
