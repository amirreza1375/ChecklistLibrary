package cl.bequarks.project.paraeco.DBHelper;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.UserCheckList;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.sharedpreference.Config;

import static cl.bequarks.project.paraeco.DBHelper.DataBaseConfig.LOG_DATABASE_NAME;
import static cl.bequarks.project.paraeco.DBHelper.DataBaseConfig.LOG_VERSION;
import static cl.bequarks.project.paraeco.DBHelper.DataBaseConfig.getLoggerDBVersion;
import static cl.bequarks.project.paraeco.DBHelper.DataBaseConfig.setLoggerDBVersion;

public class LoggerTableDBHelper  extends SQLiteOpenHelper {

    //    public static final int DATABASE_VERSION = 1;

    private String SQL_DELETE_ENTRIES = "";
    private String SQL_CREATE_ENTRIES = "";

    public static LoggerTableDBHelper loggerTableDBHelper;


    public LoggerTableDBHelper(Context context) {
        super(context, LOG_DATABASE_NAME, null, LOG_VERSION);
    }

    public static LoggerTableDBHelper getInstance(Context context){
        if (loggerTableDBHelper == null)
            loggerTableDBHelper = new LoggerTableDBHelper(context);
        return loggerTableDBHelper;
    }

    public boolean isTableExists(String tableName, boolean openDb) {
        if (getLoggerDBVersion() > 0)
            return true;

        SQLiteDatabase mDatabase = new UserCheckList().getUserCheckListTableDB();
        if(openDb) {
            if(mDatabase == null || !mDatabase.isOpen()) {
                mDatabase = getReadableDatabase();
            }

            if(!mDatabase.isReadOnly()) {
                mDatabase.close();
                mDatabase = getReadableDatabase();
            }
        }

        Cursor cursor = mDatabase.rawQuery("select DISTINCT tbl_name from sqlite_master where tbl_name = '"+tableName+"'", null);
        if(cursor!=null) {
            if(cursor.getCount()>0) {
                cursor.close();
                return true;
            }
            cursor.close();
        }
        return false;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(FeedReaderContract.LogTable.SQL_CREATE_ENTRIES);
        setLoggerDBVersion(LOG_VERSION);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over
        if (newVersion > getLoggerDBVersion()) {
            db.execSQL(FeedReaderContract.LogTable.SQL_DELETE_ENTRIES);
            clearVersion();
            onCreate(db);
        }
    }

    private void clearVersion() {
        SharedPreferences.Editor editor = G.context.getSharedPreferences(Config.sharedPreferencName,Context.MODE_PRIVATE)
                .edit();
        editor.putString(Config.version,"").apply();
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }
}
