package cl.bequarks.project.paraeco.Activity.ActivityForgetPassword.Model;
import cl.bequarks.project.paraeco.ServerRequests.ApiService;
import cl.bequarks.project.paraeco.ServerRequests.IResponseApiToModel2;
import cl.bequarks.project.paraeco.ServerRequests.IResponseServerToApiForForgetPassword;

public class ForgetPassword implements IForgetPassword , ApiService.ApiAuthinticationFailListener {

    private String email;
    private String devid;


    public String getDevid() {
        return devid;
    }

    public String getEmail() {
        return email;
    }
    public void setDevid(String devid) {
        this.devid=devid;
    }

    public void setEmail(String email) {this.email=email;}


    //region constructor
    public ForgetPassword(){};
    public ForgetPassword(String email, String devid) {
        this.email = email;
        this.devid = devid;

    }
    //endregion




    @Override
    public void sendForgetPasswordRequest(final IResponseApiToModel2<String> callback) {
        new ApiService(this).forget_password(this, new IResponseServerToApiForForgetPassword() {
            @Override
            public void onEmailSent(String message) {
                callback.onSuccess(message);
            }

            @Override
            public void onWrongEmail(String error) {
                callback.onFail(error);
            }

            @Override
            public void onFail(String error) {
                callback.onFail(error);
            }

        });
    }

    @Override
    public void onAtuhinticationFailed() {

    }
}
