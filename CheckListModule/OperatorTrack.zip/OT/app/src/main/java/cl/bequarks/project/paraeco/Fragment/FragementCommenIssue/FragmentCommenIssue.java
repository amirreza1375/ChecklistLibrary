package cl.bequarks.project.paraeco.Fragment.FragementCommenIssue;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;

import java.util.ArrayList;
import java.util.List;

import cl.bequarks.project.paraeco.Activity.ActivityLogin.ActivityLogin;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Version;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.VersionPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IVersionView;
import cl.bequarks.project.paraeco.Adapter.AdapterRecycleCommonIssues;
import cl.bequarks.project.paraeco.Fragment.FragementCommenIssue.Model.CommenIssues;
import cl.bequarks.project.paraeco.Fragment.FragementCommenIssue.Presenter.PresenterCommenIssues;
import cl.bequarks.project.paraeco.Fragment.FragementCommenIssue.View.ICommenIssuesView;
import cl.bequarks.project.paraeco.Fragment.FragmentIssue;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.Model.ModelCommonIssues;
import cl.bequarks.project.paraeco.R;

/**
 * Created by Be Quarks on 26/02/2019.
 */

public class FragmentCommenIssue extends FragmentIssue<ModelCommonIssues, AdapterRecycleCommonIssues> implements ICommenIssuesView, IVersionView {


    private LinearLayout empty_box;
    PresenterCommenIssues presenter;

    CommenIssues model;
    List<ModelCommonIssues> list = new ArrayList<>();

    private Version version = new Version();
    private VersionPresenter versionPresenter = new VersionPresenter(this,version);
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        empty_box = view.findViewById(R.id.empty_box);
        presenter = new PresenterCommenIssues();
        model= new CommenIssues();
        presenter.addModel(model);
        presenter.attachView(this);
        presenter.getAllCommenIssues();
    }

    @Override
    protected void setTitle() {
        title = G.context.getString(R.string.common_issues);
    }

    public FragmentCommenIssue(){setTitle();}

    //region view presenter
    @Override
    public void onClick(View view) {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_commen_issue, container, false);
    }

    @Override
    public void failedToGetArtices(String error) {
        if(error!=null && error.contains("Error Authorization")){
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    presenter.logout();
                    versionPresenter.DeleteVersion();
                }
            },1000);
        }
        showToast(error);

    }

    @Override
    public void showCommenIssue(List<ModelCommonIssues> list) {}

    @Override
    public void JsonObjectHasProblem(String error, int indexJsonObject) {
        Toast.makeText(getmContext(),error+" in "+indexJsonObject,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void initializeRecycleView(List<ModelCommonIssues> list) {
        this.list = list;
        if(recyclerView.getAdapter()==null) {
            adapter = new AdapterRecycleCommonIssues(getContext(), this.list);
            recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
            recyclerView.setAdapter(adapter);
        }else{
            recyclerView.getAdapter().notifyDataSetChanged();
        }
        if (list.size() > 0){
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    empty_box.setVisibility(View.INVISIBLE);
                }
            });
        }
    }

    @Override
    public void getEmptyList(String error) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                empty_box.setVisibility(View.VISIBLE);
            }
        });
//            Toast.makeText(getmContext(),"empty list",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void refreshingStatus(Boolean status) {
        refresh.setRefreshing(status);
    }

    @Override
    public void sendToActivityLogin() {
        getmContext().startActivity(new Intent(mContext, ActivityLogin.class));
        presenter.killFragment();
    }

    @Override
    public void onRefresh() {
        presenter.getAllCommenIssues();
    }

    //endregion

    @Override
    public void onDestroy() {
        super.onDestroy();
        presenter.killFragment();
    }

    @Override
    public void onVersionChanged() {

    }

    @Override
    public void ServerVersion(String version) {

    }

    @Override
    public void onDeleteVersion() {

    }

    @Override
    public void onCantDeleteVersion() {}
}
