package cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.View.IDBCheckListResultView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBArrayResultView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBResultView;

interface ICheckListData {

    void fetchByUserAndDate(String user, String date, IDBArrayResultView<UserCheckList> checkListDataIDBArrayResultView);
    void fetchCheckListById(long id , IDBCheckListResultView<UserCheckList> idbCheckListResultView);
    void fetchCheckListAndPicturesById(long id,IDBCheckListAndPicturesResultView<UserCheckList> idbCheckListAndPicturesResultView);
    void fetchDeletedItems(String user, IDBArrayResultView<UserCheckList> checkListDataIDBArrayResultView);
    void removeAllDeleteds(IDBResultView resultView);
    ArrayList<UserCheckList> fetchNotDeletedItems();
    long getLastRowId();
    boolean deleteUserData(UserCheckList userCheckList);

}
