package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View;

import java.util.ArrayList;

public interface IDBArrayResultView <M>{
    void onSuccess(ArrayList<M> results);
    void onFail(String error);
}
