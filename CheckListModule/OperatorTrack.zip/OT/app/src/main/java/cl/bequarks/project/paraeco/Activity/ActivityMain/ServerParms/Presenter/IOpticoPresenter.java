package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter;

import org.json.JSONArray;

public interface IOpticoPresenter {
    void Insert(JSONArray jSONArray);

    void OpticoBtShop(int i);

    void getOpticoById(long j);

    void getOpticos();

    void getOpticosByCondition(int i, int i2, int i3, int i4, int i5);
}
