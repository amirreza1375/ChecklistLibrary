package cl.bequarks.project.paraeco.EvenLogger;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.checklist.Database.ModuleLogEvent;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.DBModelBaseTemp;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBArrayResultView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBResultView;
import cl.bequarks.project.paraeco.DBHelper.FeedReaderContract;
import cl.bequarks.project.paraeco.DBHelper.LogEventTableDBHelper;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.Logger.LogMonitorDataListener;
import cl.bequarks.project.paraeco.sharedpreference.Config;

public class LogEvent extends DBModelBaseTemp<LogEvent> {

    private long id;
    private String appVersion, token, user, internet, date, time, phone, oldVersion, newVersion, serverData, checklistJson, eventName, answerJson, syncData;
    private int isSynced;

    public LogEvent() {

    }

    public LogEvent(String appVersion, String token, String user, String internet, String date, String time, String phone, String oldVersion, String newVersion, String serverData, String checklistJson, String eventName, String answerJson, String syncData, int isSynced) {
        this.appVersion = appVersion;
        this.token = token;
        this.user = user;
        this.internet = internet;
        this.date = date;
        this.time = time;
        this.phone = phone;
        this.oldVersion = oldVersion;
        this.newVersion = newVersion;
        this.serverData = serverData;
        this.checklistJson = checklistJson;
        this.eventName = eventName;
        this.answerJson = answerJson;
        this.syncData = syncData;
        this.isSynced = isSynced;
    }

    @Override
    public SQLiteDatabase dropAndCreateTable() {
        SQLiteDatabase db = LogEventTableDBHelper.getInstance(G.context).getWritableDatabase();
        if (!LogEventTableDBHelper.getInstance(G.context).isTableExists(FeedReaderContract.LogEventTable.TABLE_NAME, true)) {
            db.execSQL(FeedReaderContract.LogEventTable.SQL_CREATE_ENTRIES);
        }
        return db;
    }


    public void getNotSyncedJsonArray(final LogMonitorDataListener callBack) {
        getAllNotSyncedItems(new IDBArrayResultView<LogEvent>() {
            @Override
            public void onSuccess(ArrayList<LogEvent> results) {
                callBack.onDataRecieved(getJSONArrayFromArrayListLogMonitor(results));
            }

            @Override
            public void onFail(String error) {

            }
        });
    }

    public JSONArray getJSONArrayFromArrayListLogMonitor(ArrayList<LogEvent> logEvents) {
        JSONArray datas = new JSONArray();
        for (int i = 0; i < logEvents.size(); i++) {

            JSONObject data = new JSONObject();

            LogEvent logEvent = logEvents.get(i);

            try {
                data.put(FeedReaderContract.LogEventTable._ID, logEvent.getId());
                data.put(FeedReaderContract.LogEventTable.APP_VERIOSN, logEvent.getAppVersion());
                data.put(FeedReaderContract.LogEventTable.TOKEN, logEvent.getToken());
                data.put(FeedReaderContract.LogEventTable.USER, logEvent.getUser());
                data.put(FeedReaderContract.LogEventTable.INTERNET, logEvent.getInternet());
                data.put(FeedReaderContract.LogEventTable.DATE, logEvent.getDate());
                data.put(FeedReaderContract.LogEventTable.TIME, logEvent.getTime());
                data.put(FeedReaderContract.LogEventTable.PHONE, logEvent.getPhone());
                data.put(FeedReaderContract.LogEventTable.OLD_VERSION, logEvent.getOldVersion());
                data.put(FeedReaderContract.LogEventTable.NEW_VERSION, logEvent.getNewVersion());
                data.put(FeedReaderContract.LogEventTable.SERVER_DATA, logEvent.getServerData());
                data.put(FeedReaderContract.LogEventTable.CHECKLIST_JSON, logEvent.getChecklistJson());
                data.put(FeedReaderContract.LogEventTable.EVENT_NAME, logEvent.getEventName());
                data.put(FeedReaderContract.LogEventTable.ANSWER_JSON, logEvent.getAnswerJson());
                data.put(FeedReaderContract.LogEventTable.SYNC_DATA, logEvent.getSyncData());
                data.put(FeedReaderContract.LogEventTable.IS_SYNCED, logEvent.getIsSynced());


                datas.put(data);
            } catch (JSONException e) {
                e.printStackTrace();
            }


        }

        return datas;
    }

    public void getAllNotSyncedItems(final IDBArrayResultView<LogEvent> callBack) {
        if (LogEventTableDBHelper.getInstance(G.context).isTableExists(FeedReaderContract.LogEventTable.TABLE_NAME, true)) {
            new Thread(new Runnable() {
                @Override
                public void run() {

                    SQLiteDatabase db = getDataBaseConnection();
                    if (db.isOpen()) {
                        String SQL = "SELECT * FROM " + FeedReaderContract.LogEventTable.TABLE_NAME
                                + " where " + FeedReaderContract.LogEventTable.IS_SYNCED + " ='" + 0 + "'";
                        Cursor cursor = db.rawQuery(SQL, null);
                        ArrayList<LogEvent> logEvents = getItemsByCursor(cursor, db);
                        callBack.onSuccess(logEvents);
                    } else {
                        db = getDataBaseConnection();
                        String SQL = "SELECT * FROM " + FeedReaderContract.LogEventTable.TABLE_NAME
                                + " where " + FeedReaderContract.LogEventTable.IS_SYNCED + " ='" + 0 + "'";
                        Cursor cursor = db.rawQuery(SQL, null);
                        ArrayList<LogEvent> logEvents = getItemsByCursor(cursor, db);
                        callBack.onSuccess(logEvents);
                    }

                }
            }).start();
        } else {
            dropAndCreateTable();
            callBack.onFail("Table not exist");
        }
    }

    @Override
    public long insert(LogEvent item, SQLiteDatabase DB, IDBResultView callBack) {
        if (DB.isOpen()) {
            long id = DB.insert(FeedReaderContract.LogEventTable.TABLE_NAME, null, getValuse(item));
            if (id > 0)
                callBack.onSuccess();
            else
                callBack.onFail("No inserted");
            return id;
        } else {
            DB = getDataBaseConnection();
            long id = DB.insert(FeedReaderContract.LogEventTable.TABLE_NAME, null, getValuse(item));
            if (id > 0)
                callBack.onSuccess();
            else
                callBack.onFail("No inserted");
            return id;
        }
    }

    public long insert(LogEvent item) {
        SQLiteDatabase DB = getDataBaseConnection();

        if (!LogEventTableDBHelper.getInstance(G.context).isTableExists(FeedReaderContract.LogEventTable.TABLE_NAME, true)) {
            DB = dropAndCreateTable();
        }

        if (DB.isOpen()) {

            long id = DB.insert(FeedReaderContract.LogEventTable.TABLE_NAME, null, getValuse(item));

            return id;
        } else {
            DB = getDataBaseConnection();
            long id = DB.insert(FeedReaderContract.LogEventTable.TABLE_NAME, null, getValuse(item));

            return id;
        }

    }

    @Override
    public LogEvent getByJson(JSONObject json) {
        return null;
    }

    @Override
    public void refreshTable(JSONArray json, IDBResultView callback) {

    }

    @Override
    public SQLiteDatabase getDataBaseConnection() {
        return LogEventTableDBHelper.getInstance(G.context).getWritableDatabase();
    }

    @Override
    public LogEvent fetchById(long id) {
        return null;
    }

    @Override
    public LogEvent getItemByCursor(Cursor cursor) {
        return null;
    }

    public void setAllSentSynced(JSONArray data) {

        String ides = "";
        for (int i = 0; i < data.length(); i++) {
            try {
                String id = data.getJSONObject(i).getString(FeedReaderContract.LogEventTable._ID);
                if (data.length() == 1) {
                    ides = id;
                } else {
                    if (i == data.length() - 1) {
                        ides += id;
                    } else {
                        ides += id + ",";
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }//here we have all ides in IDES variable like this 1,3,5,6,7,23

        String SQL = " UPDATE " + FeedReaderContract.LogEventTable.TABLE_NAME
                + " SET " + FeedReaderContract.LogEventTable.IS_SYNCED + " = '1'" +
                " WHERE " + FeedReaderContract.LogEventTable._ID + " IN ("
                + ides + " ) ";

        SQLiteDatabase db = getDataBaseConnection();
        if (db.isOpen()) {
            db.execSQL(SQL);
        } else {
            db = getDataBaseConnection();
            db.execSQL(SQL);
        }

    }

    @Override
    public LogEvent getItemForCursor(Cursor cursor) {


        long ID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.LogEventTable._ID));
        String AV = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogEventTable.APP_VERIOSN));
        String token = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogEventTable.TOKEN));
        String user = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogEventTable.USER));
        String internet = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogEventTable.INTERNET));
        String phone = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogEventTable.PHONE));
        String oldversion = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogEventTable.OLD_VERSION));
        String newversion = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogEventTable.NEW_VERSION));
        String date = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogEventTable.DATE));
        String time = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogEventTable.TIME));
        String serverdata = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogEventTable.SERVER_DATA));
        String checklistjson = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogEventTable.CHECKLIST_JSON));
        String eventname = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogEventTable.EVENT_NAME));
        String answerjson = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogEventTable.ANSWER_JSON));
        String syncdata = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogEventTable.SYNC_DATA));
        int issynced = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.LogEventTable.IS_SYNCED));

        LogEvent logEvent = new LogEvent(AV, token, user, internet, date, time, phone, oldversion, newversion
                , serverdata, checklistjson, eventname, answerjson, syncdata, issynced);
        logEvent.setId(ID);

        return logEvent;
    }

    @Override
    public boolean updateImgPath(SQLiteDatabase db, String URL, long id, IDBResultView callBack) {
        return false;
    }

    @Override
    public ArrayList<LogEvent> getAllItems() {
        ArrayList<LogEvent> logEvents = new ArrayList<>();
        if (LogEventTableDBHelper.getInstance(G.context).isTableExists(FeedReaderContract.LogEventTable.TABLE_NAME, true)) {

            String SQL = "SELECT * FROM " + FeedReaderContract.LogEventTable.TABLE_NAME;
            Cursor cursor = getDataBaseConnection().rawQuery(SQL, null);
            logEvents = getItemsByCursor(cursor, getDataBaseConnection());
        }
        return logEvents;
    }

    @Override
    public ArrayList<LogEvent> getItemsByCursor(Cursor cursor, SQLiteDatabase db) {
        try {
            ArrayList<LogEvent> logEvents = new ArrayList<>();
            if (cursor.moveToFirst()) {
                while (!cursor.isAfterLast()) {

                    logEvents.add(getItemForCursor(cursor));

                    cursor.moveToNext();
                }
            }

            cursor.close();

            return logEvents;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cursor.close();
        }
        return new ArrayList<>();
    }

    @Override
    public String getImgURLById(long id) {
        return null;
    }

    @Override
    public ContentValues getValuse(LogEvent item) {
        ContentValues values = new ContentValues();

        values.put(FeedReaderContract.LogEventTable.APP_VERIOSN, item.getAppVersion());
        values.put(FeedReaderContract.LogEventTable.TOKEN, item.getToken());
        values.put(FeedReaderContract.LogEventTable.USER, item.getUser());
        values.put(FeedReaderContract.LogEventTable.INTERNET, item.getInternet());
        values.put(FeedReaderContract.LogEventTable.DATE, item.getDate());
        values.put(FeedReaderContract.LogEventTable.TIME, item.getTime());
        values.put(FeedReaderContract.LogEventTable.PHONE, item.getPhone());
        values.put(FeedReaderContract.LogEventTable.OLD_VERSION, item.getOldVersion());
        values.put(FeedReaderContract.LogEventTable.NEW_VERSION, item.getNewVersion());
        values.put(FeedReaderContract.LogEventTable.SERVER_DATA, item.getServerData());
        values.put(FeedReaderContract.LogEventTable.CHECKLIST_JSON, item.getChecklistJson());
        values.put(FeedReaderContract.LogEventTable.EVENT_NAME, item.getEventName());
        values.put(FeedReaderContract.LogEventTable.ANSWER_JSON, item.getAnswerJson());
        values.put(FeedReaderContract.LogEventTable.SYNC_DATA, item.getSyncData());
        values.put(FeedReaderContract.LogEventTable.IS_SYNCED, item.getIsSynced());

        return values;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getInternet() {
        return internet;
    }

    public void setInternet(String internet) {
        this.internet = internet;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getOldVersion() {
        return oldVersion;
    }

    public void setOldVersion(String oldVersion) {
        this.oldVersion = oldVersion;
    }

    public String getNewVersion() {
        return newVersion;
    }

    public void setNewVersion(String newVersion) {
        this.newVersion = newVersion;
    }

    public String getServerData() {
        return serverData;
    }

    public void setServerData(String serverData) {
        this.serverData = serverData;
    }

    public String getChecklistJson() {
        return checklistJson;
    }

    public void setChecklistJson(String checklistJson) {
        this.checklistJson = checklistJson;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getAnswerJson() {
        return answerJson;
    }

    public void setAnswerJson(String answerJson) {
        this.answerJson = answerJson;
    }

    public String getSyncData() {
        return syncData;
    }

    public void setSyncData(String syncData) {
        this.syncData = syncData;
    }

    public int getIsSynced() {
        return isSynced;
    }

    public void setIsSynced(int isSynced) {
        this.isSynced = isSynced;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void bulkAddItems(final ArrayList<ModuleLogEvent> moduleLogEvents, final BulkInsertListener callBack) {
        new Thread(new Runnable() {
            @Override
            public void run() {


                SQLiteDatabase db = getDataBaseConnection();
                if (!LogEventTableDBHelper.getInstance(G.context).isTableExists(FeedReaderContract.LogEventTable.TABLE_NAME, true)) {
                    db = dropAndCreateTable();
                }
                for (int i = 0; i < moduleLogEvents.size(); i++) {

                    ModuleLogEvent moduleLogEvent = moduleLogEvents.get(i);

                    LogEvent logEvent = new LogEvent(Config.getAppVersion(G.context)
                            , Config.getTokken()
                            , Config.getUserId(G.context) + " - " + Config.getUser(G.context)
                            , Config.getNetWorkType()
                            , moduleLogEvent.getDate()
                            , moduleLogEvent.getTime()
                            , Config.getphoneModel()
                            , Config.getServerVersion(G.context)
                            , ""
                            , moduleLogEvent.getServerData()
                            , moduleLogEvent.getChecklistJson()
                            , moduleLogEvent.getEventName()
                            , moduleLogEvent.getAnswerJson()
                            , moduleLogEvent.getSyncData()
                            , 0);
                    insert(logEvent, db, new IDBResultView() {
                        @Override
                        public void onSuccess() {

                        }

                        @Override
                        public void onItemInserted() {

                        }

                        @Override
                        public void onFail(String error) {

                        }
                    });

                }
                callBack.onInserted();
            }
        }).start();
//        db.close();
    }

    public interface BulkInsertListener {
        void onInserted();
    }
}
