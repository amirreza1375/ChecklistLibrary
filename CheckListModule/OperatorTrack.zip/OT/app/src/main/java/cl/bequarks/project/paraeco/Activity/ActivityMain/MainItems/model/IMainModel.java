package cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.model;

interface IMainModel {

    void SyncAll(IDBSyncResultView<ItemQueueModel> resultView);

    void Sync(ItemQueueModel itemQueueModel,IDBSyncResultView<ItemQueueModel> resultView);

    void Push(ItemQueueModel model);

    ItemQueueModel Pop();
}
