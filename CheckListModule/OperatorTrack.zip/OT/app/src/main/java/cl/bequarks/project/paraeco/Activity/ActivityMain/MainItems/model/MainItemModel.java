package cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.model;

import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.UserCheckList;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.ServerRequests.ApiService;

public class MainItemModel implements IMainModel,ApiService.ApiAuthinticationFailListener {
    public static final String TAG = "MainItemModel";

    private static final float ROTATE_FROM = 0.0f;
    private static final float ROTATE_TO = -10.0f * 360.0f;

    private ArrayList<ItemQueueModel> items;
    private SyncListener listener;

    public MainItemModel() {
        items = new ArrayList<>();
    }

    @Override
    public void SyncAll(final IDBSyncResultView<ItemQueueModel> resultView  ) {

        Log.i(TAG, "SyncAll: before " + items.size());
        if (items.size() > 0) {
            Log.i(TAG, "SyncAll: after " + items.size());

            Sync(Pop(), new IDBSyncResultView<ItemQueueModel>() {
                @Override
                public void onSuccess(ItemQueueModel result) {
                    resultView.onSuccess(result);
                }

                @Override
                public void onFail(ItemQueueModel result, String error) {
                    resultView.onFail(result, error);
                }
            });

        }

    }

    @Override
    public void Sync(final ItemQueueModel itemQueueModel, final IDBSyncResultView<ItemQueueModel> resultView) {

//        final UserCheckList userCheckList = UserCheckList.findById(UserCheckList.class, itemQueueModel.getId());
//
//
//        if (!userCheckList.isProccessing()) {
//
//            RotateAnimation syncAnimation = new RotateAnimation(ROTATE_FROM, ROTATE_TO,
//                    Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
//            syncAnimation.setDuration(1000 * 5);
//            syncAnimation.setRepeatCount(Animation.INFINITE);
//            syncAnimation.setRepeatMode(Animation.INFINITE);
//
//
//            itemQueueModel.getHolder().statusImg.startAnimation(syncAnimation);
//            syncAnimation.reset();
//            syncAnimation.start();
//            userCheckList.setProccessing(true);
//            userCheckList.save();
//
//            listener.onSyncStart(itemQueueModel,true);
//
//            final ServerJSONCleanUp serverJSONCleanUp = new ServerJSONCleanUp(itemQueueModel.getAnswer());
//
//            new android.os.Handler().postDelayed(new Runnable() {
//                @Override
//                public void run() {
//
//
//                    new ApiService(MainItemModel.this).sendSurvey(itemQueueModel.getShopId()
//                            , itemQueueModel.getCehckListId()
//                            , itemQueueModel.getStartTime()
//                            , itemQueueModel.getEndTime()
//                            , serverJSONCleanUp.cleanUpJSON().toString()
//                            , itemQueueModel.getPictures()
//                            , new ISendSurveyListener() {
//                                @Override
//                                public void onFailed(String error) {
//                                    listener.message("failed sync userCheckList");
//                                    Log.i(TAG, "onFailed: ");
//                                    userCheckList.setProccessing(false);
//                                    userCheckList.save();
//                                    listener.onSyncFinished(itemQueueModel,false);
//                                    itemQueueModel.getHolder().statusImg.clearAnimation();
//                                    resultView.onFail(itemQueueModel, "");
//                                    if (listener != null) {
//                                        listener.onSynced(false);
//                                        Log.i(TAG, "onFailed: on synced");
//                                    }
//                                    MediaPlayer mediaPlayer = MediaPlayer.create(G.context, R.raw.error);
//                                    mediaPlayer.setVolume(0.08f, 0.08f);
//                                    mediaPlayer.start();
//                                }
//
//                                @Override
//                                public void onSurveySent(double serverId) {
//                                    listener.message(serverId+"");
//                                    Log.i(TAG, "onSurveySent: ");
//                                    sendSignatures(itemQueueModel, listener, serverId+"", resultView);
//                                }
//                            });
//                }
//            }, 1000);
//        }

    }

    private void sendSignatures(final ItemQueueModel itemQueueModel, final SyncListener listener, final String surveyId
            , final IDBSyncResultView<ItemQueueModel> resultView){
//        final UserCheckList userCheckList = UserCheckList.findById(UserCheckList.class, itemQueueModel.getId());
//
//        try {
//            new ApiService(this).sendSignaturePicture(new JSONArray(itemQueueModel.getAnswer())
//                    , itemQueueModel.getCehckListId()
//                    , surveyId
//                    , new IResponsePicture() {
//                        @Override
//                        public void NoPictures() {
//                            listener.message("no signature");
//                            sendPictures(itemQueueModel,listener,surveyId,resultView);
//                        }
//
//                        @Override
//                        public void PicturesSynced() {
//                            listener.message("signatures synced");
//                            sendPictures(itemQueueModel,listener,surveyId,resultView);
//                        }
//
//                        @Override
//                        public void FailedToSync(String error) {
//                            listener.message("signatures error");
//                            userCheckList.setProccessing(false);
//                            userCheckList.save();
//                            listener.onSyncFinished(itemQueueModel,false);
//                            itemQueueModel.getHolder().statusImg.clearAnimation();
//                            resultView.onFail(itemQueueModel, "");
//                            if (listener != null) {
//                                listener.onSynced(false);
//                                Log.i(TAG, "FailedToSync: on synced");
//                            }
//                            MediaPlayer mediaPlayer = MediaPlayer.create(G.context, R.raw.error);
//                            mediaPlayer.setVolume(0.08f, 0.08f);
//                            mediaPlayer.start();
//                        }
//
//                        @Override
//                        public void message(String msg) {
//
//                        }
//                    });
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }

    }

    private void sendPictures(final ItemQueueModel itemQueueModel, final SyncListener listener, String surveyId
            , final IDBSyncResultView<ItemQueueModel> resultView) {

//        final UserCheckList userCheckList = UserCheckList.findById(UserCheckList.class, itemQueueModel.getId());
//
//
//        new ApiService(this).sendPictures(itemQueueModel.getItemPictures()
//                , surveyId
//                , itemQueueModel.getId()
//                , new IResponsePicture() {
//                    @Override
//                    public void NoPictures() {
//                        listener.message("no pic");
//                        Log.i(TAG, "PicturesSynced: ");
//                        UserCheckList userCheckList = UserCheckList.findById(UserCheckList.class, itemQueueModel.getId());
//                        userCheckList.setSynced(true);
//                        userCheckList.setPicsSynced(true);
//                        userCheckList.setProccessing(false);
//                        userCheckList.save();
//                        listener.onSyncFinished(itemQueueModel,false);
//                        itemQueueModel.getHolder().statusImg.clearAnimation();
//                        itemQueueModel.getHolder().statusImg.setImageResource(R.drawable.item_icon_sync);
//                        new Thread(new Runnable() {
//                            @Override
//                            public void run() {
//                                MediaPlayer mediaPlayer = MediaPlayer.create(G.context, R.raw.tik);
//                                mediaPlayer.setVolume(0.08f, 0.08f);
//                                mediaPlayer.start();
//                            }
//                        }).start();
//
//
//                        resultView.onSuccess(itemQueueModel);
//
//
//                        new android.os.Handler().postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                if (listener != null) {
//                                    listener.onSynced(true);
//                                    Log.i(TAG, "PicturesSynced: on synced");
//                                }
//                            }
//                        }, 600);
//
//                    }
//
//                    @Override
//                    public void PicturesSynced() {
//                        listener.message("pics synced");
//                        Log.i(TAG, "PicturesSynced: ");
//                        UserCheckList userCheckList = UserCheckList.findById(UserCheckList.class, itemQueueModel.getId());
//                        userCheckList.setSynced(true);
//                        userCheckList.setPicsSynced(true);
//                        userCheckList.setProccessing(false);
//                        userCheckList.save();
//                        listener.onSyncFinished(itemQueueModel,false);
//                        itemQueueModel.getHolder().statusImg.clearAnimation();
//                        itemQueueModel.getHolder().statusImg.setImageResource(R.drawable.item_icon_sync);
//                        new Thread(new Runnable() {
//                            @Override
//                            public void run() {
//                                MediaPlayer mediaPlayer = MediaPlayer.create(G.context, R.raw.tik);
//                                mediaPlayer.setVolume(0.08f, 0.08f);
//                                mediaPlayer.start();
//                            }
//                        }).start();
//
//
//                        resultView.onSuccess(itemQueueModel);
//
//
//                        new android.os.Handler().postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                if (listener != null) {
//                                    listener.onSynced(true);
//                                    Log.i(TAG, "PicturesSynced: on synced");
//                                }
//                            }
//                        }, 600);
//
//
//                    }
//
//                    @Override
//                    public void FailedToSync(String error) {
//                        listener.message("faild sync pics");
//                        Log.i(TAG, "FailedToSync: ");
//                        userCheckList.setProccessing(false);
//                        userCheckList.save();
//                        listener.onSyncFinished(itemQueueModel,false);
//                        itemQueueModel.getHolder().statusImg.clearAnimation();
//                        resultView.onFail(itemQueueModel, "");
//                        if (listener != null) {
//                            listener.onSynced(false);
//                            Log.i(TAG, "FailedToSync: on synced");
//                        }
//                        MediaPlayer mediaPlayer = MediaPlayer.create(G.context, R.raw.error);
//                        mediaPlayer.setVolume(0.08f, 0.08f);
//                        mediaPlayer.start();
//
//                    }
//
//                    @Override
//                    public void message(String msg) {
//                        listener.message(msg);
//                    }
//                });
    }

    @Override
    public void Push(ItemQueueModel itemQueueModel) {
        if (!isItemExist(itemQueueModel)) {
            items.add(itemQueueModel);
        }
    }

    @Override
    public ItemQueueModel Pop() {
        ItemQueueModel model = items.get(items.size() - 1);
        items.remove(items.size() - 1);
        return model;
    }

    private boolean isItemExist(ItemQueueModel model) {
        for (int i = 0; i < items.size(); i++) {
            if (model.getId() == items.get(i).getId()) {
                return true;
            }
        }
        return false;
    }

    public SyncListener getListener() {
        return listener;
    }

    public void setListener(SyncListener listener) {
        this.listener = listener;
    }

    @Override
    public void onAtuhinticationFailed() {
        ApiService.logOutOnUserAuthFailed(G.context);
    }

    public interface SyncListener {
        void onSynced(boolean isSynced);
        void onSyncStart(ItemQueueModel itemQueueModel, boolean isProccessing);
        void onSyncFinished(ItemQueueModel itemQueueModel, boolean isProccessing);

        void message(String msg);
    }

    public List<UserCheckList> getChecklist() {
        UserCheckList checklist = new UserCheckList();
        return checklist.fetchNotDeletedItems();
    }

    public List<UserCheckList> getChecklist(String key, String date) {
        List<UserCheckList> allChecklist = getChecklist();

        ArrayList<UserCheckList> resultChecklist = new ArrayList<>();
        for (UserCheckList checklist : allChecklist) {
            String fullName =
                    checklist.getShop_name().toLowerCase().trim() +
                            //checklist.getProduct_name().toLowerCase().trim()+
                            checklist.getCheckList_name().toLowerCase().trim();

            String nonSpanishFullName = fullName
                    .replace('á', 'a')
                    .replace('é', 'e')
                    .replace('í', 'i')
                    .replace('ó', 'o')
                    .replace('ú', 'u')
                    .replace('ü', 'u')
                    .replace('ñ', 'n')
                    .replace('ń', 'n');
            if (nonSpanishFullName.contains(key.toLowerCase().trim()) && checklist.getDate().equals(date)) {
                resultChecklist.add(checklist);
                //allShops.remove(shop);
            }
        }
        return resultChecklist;
    }



}
