package cl.bequarks.project.paraeco.ServerRequests;

import org.json.JSONArray;

public interface IResponseServerToApiForGetParams {

    void Accessories(JSONArray jSONArray);

    void Categories(JSONArray jSONArray);

    void CheckLists(JSONArray jSONArray);

    void Layouts(JSONArray jSONArray);

    void Opticos(JSONArray jSONArray);

    void Shops(JSONArray jSONArray);

    void onError(String error);
    void showDialog();

    void dismissDialog(String sorce);
    void onSuccessGetParams();
    void allTableRefresh();

    void Products(JSONArray productsdb);

    void onItemRefteshed(int numberOfRefreshedTable, int totalNumberOfTables,String refreshedItemName);

    void AllItemsCounts(int count);
}
