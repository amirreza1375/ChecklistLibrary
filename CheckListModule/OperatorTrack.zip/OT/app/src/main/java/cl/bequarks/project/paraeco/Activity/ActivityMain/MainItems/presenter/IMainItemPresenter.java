package cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.presenter;

interface IMainItemPresenter {

    void SyncItems();

//    void SyncItem(UserCheckList userCheckList, MainItemsRecyclerAdapter.ViewHolder holder);
//
//    void addItemToQueue(UserCheckList userCheckList, MainItemsRecyclerAdapter.ViewHolder statusImg);

}
