package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model;


import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBResultView;
import cl.bequarks.project.paraeco.DBHelper.FeedReaderContract;
import cl.bequarks.project.paraeco.DBHelper.TableDbHelper;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.Global.SaveImage;

import static cl.bequarks.project.paraeco.sharedpreference.Config.APP_FOLDER_OPTICO;
import static cl.bequarks.project.paraeco.sharedpreference.Config.removeFolderEntries;

public class Optico extends DBModelBaseTemp<Optico> implements IOptico {


    public static String conf_endtDate = "endDate";
    public static String conf_img = "img";
    public static String conf_optico_id = "optico_id";
    public static String conf_optico_name = "optico_name";
    public static String conf_priority = "priority";
    public static String conf_result_id = "result_id";
    public static String conf_shop_id = "shop_id";
    public static String conf_startDate = "startDate";

    //region Field of DB
    private long _ID;
    private String endtDate;
    private String img;
    private String img_path;
    private int optico_id;
    private String optico_name;
    private int priority;
    private String result_id;
    private String shop_id;
    private String startDate;
    private String shop_id_String;
    private String result_id_String;
    //endregion

    //region Constructor
    public Optico(String optico_name, String result_id, String img, String startDate,
                  String endtDate, String img_path, String shop_id,
                  int optico_id, int priority) {
        this.optico_name = optico_name;
        this.result_id = result_id;
        this.img = img;
        this.startDate = startDate;
        this.endtDate = endtDate;
        this.img_path = img_path;
        this.shop_id = shop_id;
        this.optico_id = optico_id;
        this.priority = priority;
        this.result_id_String = result_id.toString();
        this.shop_id_String = shop_id.toString();
    }

    public Optico() {
    }

    @Override
    public SQLiteDatabase dropAndCreateTable() {
        TableDbHelper dbHelper = TableDbHelper.getInstanceOptico(G.context);
//
        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL(FeedReaderContract.OpticoTable.SQL_DELETE_ENTRIES);
        db.execSQL(FeedReaderContract.OpticoTable.SQL_CREATE_ENTRIES);

        return db;
    }
    //endregion

    //region IOptic
    @Override
    public String getOpticoName() {
        return this.optico_name;
    }

    @Override
    public String getResultId() {
        return this.result_id;
    }

    @Override
    public String getImg() {
        return this.img;
    }

    @Override
    public String getStartDate() {
        return this.startDate;
    }

    @Override
    public String getEndDate() {
        return this.endtDate;
    }

    @Override
    public String getImgPath() {
        return this.img_path;
    }

    @Override
    public int getOpticoId() {
        return this.optico_id;
    }

    @Override
    public int getPriority() {
        return this.priority;
    }

    @Override
    public ArrayList<Optico> fetchByShop(int shop_id) {
        List<Optico> opticoDBS = getAllItems();
        ArrayList<Optico> filteredOpticos = new ArrayList();
        for (int i = 0; i < opticoDBS.size(); i++) {
            boolean EXIST = false;
            ArrayList<Integer> shop = convert_String_to_ArrayListInteger((opticoDBS.get(i)).getShop_id_String());
            for (int j = 0; j < shop.size(); j++) {
                if (shop.get(j) == shop_id) {
                    EXIST = true;
                    break;
                }
            }
            if (EXIST) {
                filteredOpticos.add(opticoDBS.get(i));
            }
        }
        return filteredOpticos;
    }

    @Override
    public List<Optico> fetchByShopResultId(int shop_id, int ID, int subcanal, int Posiction, int Elemento) {
        List<Optico> opticoDBS = getAllItems();
        ArrayList<Optico> filteredOpticos = new ArrayList();
        int i = 0;
        while (i < opticoDBS.size()) {
            boolean EXIST = false;
            ArrayList<Integer> shop = convert_String_to_ArrayListInteger((opticoDBS.get(i)).getShop_id_String());
            for (int j = 0; j < shop.size(); j++) {
                if (shop.get(j) == shop_id && IsResultOk(
                        ID, subcanal, Posiction, Elemento,
                        convert_String_to_JSONArray((opticoDBS.get(i)).getResult_id_String()))) {
                    EXIST = true;
                    break;
                }
            }
            if (EXIST) {
                filteredOpticos.add(opticoDBS.get(i));
            }
            i++;
        }
        return filteredOpticos;
    }


    public String getShop_id_String() {
        return this.shop_id_String;
    }

    public String getResult_id_String() {
        return this.result_id_String;
    }

    public void setImg_path(String path) {
        this.img_path = path;
    }
    //endregion

    //region method of base model


    @Override
    public Optico getByJson(JSONObject json) {
        try {
            return new Optico(
                    json.getString(Optico.conf_optico_name),
                    json.getJSONArray(Optico.conf_result_id).toString(),
                    json.getString(Optico.conf_img),
                    json.getString(Optico.conf_startDate),
                    json.getString(Optico.conf_endtDate),
                    "",
                    json.getString(Optico.conf_shop_id),
                    json.getInt(Optico.conf_optico_id),
                    json.getInt(Optico.conf_priority));
        } catch (JSONException e) {
            e.printStackTrace();
            Optico optico = new Optico();
            optico.errorMessage = e.getMessage();
            return optico;
        }
    }

    @Override
    public void refreshTable(final JSONArray json, final IDBResultView callback) {
//        deleteAllTable("Optico");
        removeFolderEntries(APP_FOLDER_OPTICO);
        final SQLiteDatabase db = dropAndCreateTable();
        new Thread(new Runnable() {
            @Override
            public void run() {
                Log.i(MODEL_TAG, "Optico -> Insert start");
//                db.beginTransaction();
                for (int i = 0; i < json.length(); i++) {
                    try {

                        Optico optico = getByJson(json.getJSONObject(i));
                        if (optico.getErrorMessage() == null) {
                            updateImgPath(db, optico.getImg(), insert(optico, db, callback), callback);
                        } else {
                            callback.onFail(optico.getErrorMessage());

                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        callback.onFail("Optico have some problem");

                    }
                }
                Log.i(MODEL_TAG, "Optico -> Insert finished");
//                db.endTransaction();
//                db.close();
                callback.onSuccess();
//                downloadImages(callback);
//                db.close();

            }
        }).start();
    }

    @Override
    public SQLiteDatabase getDataBaseConnection() {
        return TableDbHelper.getInstanceOptico(G.context).getWritableDatabase();
    }

    @Override
    public Optico fetchById(long id) {
        TableDbHelper dbHelper = TableDbHelper.getInstanceOptico(G.context);

        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.OpticoTable.TABLE_NAME
                + " where " + FeedReaderContract.OpticoTable._ID + "='" + id + "'", null);
        cursor.moveToNext();
        return getItemByCursor(cursor);
    }

    @Override
    public long insert(Optico optico, SQLiteDatabase db, IDBResultView callBack) {

        ContentValues values = new ContentValues();
        values.put(FeedReaderContract.OpticoTable.optico_id, optico.getOpticoId());
        values.put(FeedReaderContract.OpticoTable.optico_name, optico.getOpticoName());
        values.put(FeedReaderContract.OpticoTable.shop_id, optico.getShop_id());
        values.put(FeedReaderContract.OpticoTable.priority, optico.getPriority());
        values.put(FeedReaderContract.OpticoTable.result_id, optico.getResultId());
        values.put(FeedReaderContract.OpticoTable.img, optico.getImg());
        values.put(FeedReaderContract.OpticoTable.img_path, optico.getImgPath());
        values.put(FeedReaderContract.OpticoTable.startDate, optico.getStartDate());
        values.put(FeedReaderContract.OpticoTable.endtDate, optico.getEndDate());
        long newRowId = db.insert(FeedReaderContract.OpticoTable.TABLE_NAME, null, values);
        return newRowId;

    }

    @Override
    public Optico getItemByCursor(Cursor cursor) {
        if (cursor != null) {
            try {
                long ID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.OpticoTable._ID));
                int opticoId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.OpticoTable.optico_id));
                String opticoName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.OpticoTable.optico_name));
                String shopId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.OpticoTable.shop_id));
                int priority = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.OpticoTable.priority));
                String resultID = cursor.getString(cursor.getColumnIndex(FeedReaderContract.OpticoTable.result_id));
                String img = cursor.getString(cursor.getColumnIndex(FeedReaderContract.OpticoTable.img));
                String imgPath = cursor.getString(cursor.getColumnIndex(FeedReaderContract.OpticoTable.img_path));
                String startDate = cursor.getString(cursor.getColumnIndex(FeedReaderContract.OpticoTable.startDate));
                String endDate = cursor.getString(cursor.getColumnIndex(FeedReaderContract.OpticoTable.endtDate));

                Optico optico = new Optico(opticoName, resultID, img, startDate, endDate, imgPath, shopId, opticoId, priority);
                optico.set_ID(ID);
                return optico;
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                cursor.close();
            }
        }
        return new Optico();
    }

    public Optico getItemForCursor(Cursor cursor) {
        if (cursor != null) {

            long ID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.OpticoTable._ID));
            int opticoId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.OpticoTable.optico_id));
            String opticoName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.OpticoTable.optico_name));
            String shopId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.OpticoTable.shop_id));
            int priority = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.OpticoTable.priority));
            String resultID = cursor.getString(cursor.getColumnIndex(FeedReaderContract.OpticoTable.result_id));
            String img = cursor.getString(cursor.getColumnIndex(FeedReaderContract.OpticoTable.img));
            String imgPath = cursor.getString(cursor.getColumnIndex(FeedReaderContract.OpticoTable.img_path));
            String startDate = cursor.getString(cursor.getColumnIndex(FeedReaderContract.OpticoTable.startDate));
            String endDate = cursor.getString(cursor.getColumnIndex(FeedReaderContract.OpticoTable.endtDate));

            Optico optico = new Optico(opticoName, resultID, img, startDate, endDate, imgPath, shopId, opticoId, priority);
            optico.set_ID(ID);
            return optico;
        }
        return new Optico();
    }

    @Override
    public boolean updateImgPath(final SQLiteDatabase db, String URL, final long id, final IDBResultView callBack) {
        new SaveImage().saveImage(URL, SaveImage.saveImage.OPTICO, new SaveImage.ImageSaverListener() {
            @Override
            public void onImageSaved(String path) {

                // Gets the data repository in write mode

                ContentValues values = new ContentValues();
                values.put(FeedReaderContract.OpticoTable.img_path, path);

                db.update(FeedReaderContract.OpticoTable.TABLE_NAME, values, FeedReaderContract.OpticoTable._ID + "=" + id, null);
//                            db.close();
                callBack.onItemInserted();
            }
        });

        return true;
    }

    @Override
    public ArrayList<Optico> getAllItems() {
        TableDbHelper dbHelper = TableDbHelper.getInstanceOptico(G.context);
//
        // Gets the data repository in write mode

        if (dbHelper.isTableExists(FeedReaderContract.OpticoTable.TABLE_NAME, true)) {

            final SQLiteDatabase db = dbHelper.getWritableDatabase();

            Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.OpticoTable.TABLE_NAME, null);
//            db.close();
            return getItemsByCursor(cursor, db);
        } else {
            return new ArrayList<>();
        }
    }

    @Override
    public ArrayList<Optico> getItemsByCursor(Cursor cursor, SQLiteDatabase db) {
        try {
            ArrayList<Optico> opticos = new ArrayList<>();
            if (cursor.moveToFirst()) {
                while (!cursor.isAfterLast()) {

                    opticos.add(getItemForCursor(cursor));

                    cursor.moveToNext();
                }
            }
            cursor.close();
//            db.close();
            return opticos;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
//            db.close();
            cursor.close();
        }
//        db.close();
        return new ArrayList<>();
    }

    @Override
    public String getImgURLById(long id) {
        Optico optico = fetchById(id);
        return optico.getImg();
    }

    @Override
    public ContentValues getValuse(Optico item) {
        return null;
    }
//
//    @Override
//    public void downloadImages(IDBResultView callBack) {
//        ArrayList<Optico> opticos = getAllItems();
//        for (int i = 0 ; i < opticos.size() ; i++){
//            updateImgPath(opticos.get(i).getImg(),opticos.get(i).get_ID(),callBack);
//        }
//    }
    //endregion

    public static String convert_ArrayListInteger_to_String(ArrayList<Integer> shops) {
        String shops_str = "";
        for (int i = 0; i < shops.size(); i++) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(shops_str);
            stringBuilder.append(shops.get(i));
            stringBuilder.append(",");
            shops_str = stringBuilder.toString();
        }
        return shops_str;
    }

    public static ArrayList<Integer> convert_String_to_ArrayListInteger(String shops_str) {
        ArrayList<Integer> shops = new ArrayList();
        try {
            JSONArray shopsArray = new JSONArray(shops_str);
            for (int i = 0; i < shopsArray.length(); i++) {
                shops.add(shopsArray.getInt(i));
            }
            return shops;
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            if (shops_str == null) {
                return new ArrayList();
            }
            if (shops_str.length() == 0) {
                return new ArrayList();
            }
            String[] shop_str_array = shops_str.split(",");

            for (String shop_id : shop_str_array) {
                shops.add(Integer.parseInt(shop_id));
            }
            return shops;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return new ArrayList<Integer>();
    }

    public static JSONArray convert_String_to_JSONArray(String resultId_str) {
        try {
            return new JSONArray(resultId_str);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean IsResultOk(int ID, int subcanal, int Posiction, int Elemento, JSONArray result_id) {
        boolean FLAG_EXIST = true;
        int i = 0;
        if (result_id == null || result_id.length() == 0) {
            return false;
        }
        while (i < result_id.length()) {
            try {
                JSONObject result = result_id.getJSONObject(i);
                int resID = Integer.parseInt(result.getString("ID"));
                int resSubcanal = Integer.parseInt(result.getString("subcanal"));
                int resPosicion = Integer.parseInt(result.getString("Posicion"));
                int resElemento = Integer.parseInt(result.getString("Elemento"));
                if (resID != ID) {
                    FLAG_EXIST = false;
                } else if (resSubcanal != subcanal) {
                    FLAG_EXIST = false;
                } else if (resElemento != Elemento) {
                    FLAG_EXIST = false;
                } else if (resPosicion != Posiction) {
                    FLAG_EXIST = false;
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            i++;
        }
        return FLAG_EXIST;
    }

    public String getShop_id() {
        return shop_id;
    }

    public void setShop_id(String shop_id) {
        this.shop_id = shop_id;
    }

    public long get_ID() {
        return _ID;
    }

    public void set_ID(long _ID) {
        this._ID = _ID;
    }
}
