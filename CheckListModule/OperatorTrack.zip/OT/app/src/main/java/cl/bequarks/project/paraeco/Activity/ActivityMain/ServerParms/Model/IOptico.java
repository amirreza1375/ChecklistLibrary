package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model;

import java.util.ArrayList;
import java.util.List;

public interface IOptico {

    ArrayList<Optico> fetchByShop(int i);

    List<Optico> fetchByShopResultId(int i, int i2, int i3, int i4, int i5);

    String getEndDate();

    String getImg();

    String getImgPath();

    int getOpticoId();

    String getOpticoName();

    int getPriority();

    String getResultId();

    String getStartDate();

}
