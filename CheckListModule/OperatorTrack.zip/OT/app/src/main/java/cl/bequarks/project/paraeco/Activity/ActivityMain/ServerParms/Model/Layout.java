package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBResultView;
import cl.bequarks.project.paraeco.DBHelper.FeedReaderContract;
import cl.bequarks.project.paraeco.DBHelper.TableDbHelper;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.Global.SaveImage;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static cl.bequarks.project.paraeco.sharedpreference.Config.APP_FOLDER_LAYOUT;
import static cl.bequarks.project.paraeco.sharedpreference.Config.removeFolderEntries;

public class Layout extends DBModelBaseTemp<Layout> implements ILayout {


    public static String conf_countpos = "countpos";
    public static String conf_img = "img";
    public static String conf_order_id = "order_id";
    public static String conf_order_name = "name";
    public static String conf_positions = "positions";
    public static String conf_positions_img = "img";
    public static String conf_positions_name = "name";
    public static String conf_positions_phone_id = "phone_id";
    public static String conf_replacements = "replacements";
    public static String conf_shop = "shop";

    //region Field of DB
    private long _ID;
    private int countpos;
    private String image_path;
    private String img;
    private int order_id;
    private String name;
    private String positions;
    private String replacements;
    private String shop;
    private String shop_String;
    //endregion

    //region Constructor
    public Layout(
            int order_id, String name, String img, String shop, int countpos,
            String positions, String image_path, String replacements
    ) {
        this.order_id = order_id;
        this.name = name;
        this.img = img;
        this.shop = shop;
        this.countpos = countpos;
        this.positions = positions;
        this.image_path = image_path;
        this.replacements = replacements;
    }

    public Layout() {
    }

    @Override
    public SQLiteDatabase dropAndCreateTable() {
        TableDbHelper dbHelper = TableDbHelper.getInstanceLayout(G.context);
//
        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL(FeedReaderContract.LayoutTable.SQL_DELETE_ENTRIES);
        db.execSQL(FeedReaderContract.LayoutTable.SQL_CREATE_ENTRIES);

        return db;
    }
    //endregion Constructor

    //region ILayout
    @Override
    public int getOrderId() {
        return this.order_id;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public String getImg() {
        return this.img;
    }

    @Override
    public String getImgPath() {
        return this.image_path;
    }

    @Override
    public String getShops() {
        return this.shop;
    }

    @Override
    public int countPos() {
        return this.countpos;
    }

    @Override
    public String getReplaceMent() {
        return this.replacements;
    }

    @Override
    public String getPositions() {
        return this.positions;
    }

    @Override
    public ArrayList<Layout> fetchLayoutByShop(int shop_id) {
        List<Layout> layoutDBS = getAllItems();
        ArrayList<Layout> filteredLayouts = new ArrayList();
        for (int i = 0; i < layoutDBS.size(); i++) {
            boolean FLAG_EXIST = false;
            ArrayList<Integer> shops = Optico.convert_String_to_ArrayListInteger((layoutDBS.get(i)).getShop_String());
            for (int j = 0; j < shops.size(); j++) {
                if (shops.get(i) == shop_id) {
                    FLAG_EXIST = true;
                    break;
                }
            }
            if (FLAG_EXIST) {
                filteredLayouts.add(layoutDBS.get(i));
            }
        }
        return filteredLayouts;
    }


    public void setImage_path(String path) {
        this.image_path = path;
    }

    public String getShop_String() {
        return this.shop_String;
    }
    //endregion ILayout

    //region method of base model

    @Override
    public Layout getByJson(JSONObject json) {
        try {
            Layout layout = new Layout(
                    json.getInt(Layout.conf_order_id),
                    json.getString(Layout.conf_order_name),
                    json.getString(Layout.conf_img),
                    json.getString(Layout.conf_shop),
                    json.getInt(Layout.conf_countpos),
                    json.getJSONArray(Layout.conf_positions).toString(),
                    "",
                    json.getJSONArray(Layout.conf_replacements).toString()
            );
            return layout;
        } catch (JSONException e) {
            Layout layout = new Layout();
            layout.errorMessage = e.getMessage();
            e.printStackTrace();
            return layout;
        }
    }

    @Override
    public void refreshTable(final JSONArray json, final IDBResultView callback) {
        removeFolderEntries(APP_FOLDER_LAYOUT);
        final SQLiteDatabase db = dropAndCreateTable();
        new Thread(new Runnable() {
            @Override
            public void run() {
                Log.i(MODEL_TAG, "Layout -> Insert start");
//                db.beginTransaction();
                for (int i = 0; i < json.length(); i++) {
                    try {

                        Layout layout = getByJson(json.getJSONObject(i));
                        if (layout.getErrorMessage() == null) {
                            updateImgPath(db, layout.getImg(), insert(layout, db, callback), callback);
                        } else {
                            callback.onFail(layout.errorMessage);

                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        callback.onFail("layout have some problem");

                    }
                }
                Log.i(MODEL_TAG, "Layout -> Insert finished");
//                db.endTransaction();
//                db.close();
                callback.onSuccess();
//                db.close();

            }
        }).start();
    }

    @Override
    public SQLiteDatabase getDataBaseConnection() {
        return TableDbHelper.getInstanceLayout(G.context).getWritableDatabase();
    }

    @Override
    public Layout fetchById(long id) {
        TableDbHelper dbHelper = TableDbHelper.getInstanceLayout(G.context);

        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.LayoutTable.TABLE_NAME
                + " where " + FeedReaderContract.LayoutTable._ID + "='" + id + "'", null);
        cursor.moveToNext();
//        db.close();
        return getItemByCursor(cursor);
    }

    @Override
    public long insert(Layout layout, SQLiteDatabase db, IDBResultView callBack) {

        ContentValues values = new ContentValues();
        values.put(FeedReaderContract.LayoutTable.order_id, layout.getOrderId());
        values.put(FeedReaderContract.LayoutTable.order_name, layout.getName());
        values.put(FeedReaderContract.LayoutTable.img, layout.getImg());
        values.put(FeedReaderContract.LayoutTable.shop, layout.getShops());
        values.put(FeedReaderContract.LayoutTable.countpos, layout.countPos());
        values.put(FeedReaderContract.LayoutTable.positions, layout.getPositions());
        values.put(FeedReaderContract.LayoutTable.replacements, layout.getReplaceMent());
        values.put(FeedReaderContract.LayoutTable.imgPath, layout.getImgPath());
        long newRowId = db.insert(FeedReaderContract.LayoutTable.TABLE_NAME, null, values);
        return newRowId;

    }

    @Override
    public Layout getItemByCursor(Cursor cursor) {
        if (cursor != null) {
            try {
                long ID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.LayoutTable._ID));
                int orderId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.LayoutTable.order_id));
                String orderName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LayoutTable.order_name));
                String img = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LayoutTable.img));
                String shop = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LayoutTable.shop));
                int countpos = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.LayoutTable.countpos));
                String positions = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LayoutTable.positions));
                String replacements = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LayoutTable.replacements));
                String imgPath = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LayoutTable.imgPath));

                Layout layout = new Layout(orderId, orderName, img, shop, countpos, positions, imgPath, replacements);
                layout.set_ID(ID);
                return layout;
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                cursor.close();
            }
        }
        return new Layout();
    }

    @Override
    public Layout getItemForCursor(Cursor cursor) {
        if (cursor != null) {
            long ID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.LayoutTable._ID));
            int orderId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.LayoutTable.order_id));
            String orderName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LayoutTable.order_name));
            String img = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LayoutTable.img));
            String shop = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LayoutTable.shop));
            int countpos = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.LayoutTable.countpos));
            String positions = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LayoutTable.positions));
            String replacements = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LayoutTable.replacements));
            String imgPath = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LayoutTable.imgPath));

            Layout layout = new Layout(orderId, orderName, img, shop, countpos, positions, imgPath, replacements);
            layout.set_ID(ID);
            return layout;

        }
        return new Layout();
    }


    @Override
    public boolean updateImgPath(final SQLiteDatabase db, String URL, final long id, final IDBResultView callBack) {
        new SaveImage().saveImage(URL, SaveImage.saveImage.LAYOUT, new SaveImage.ImageSaverListener() {
            @Override
            public void onImageSaved(String path) {
//                            TableDbHelper dbHelper = new TableDbHelper(G.context, FeedReaderContract.LayoutTable.SQL_DELETE_ENTRIES
//                                    , FeedReaderContract.LayoutTable.SQL_CREATE_ENTRIES);
////
//                            // Gets the data repository in write mode
//                            final SQLiteDatabase db = dbHelper.getWritableDatabase();

                ContentValues values = new ContentValues();
                values.put(FeedReaderContract.LayoutTable.imgPath, path);

                db.update(FeedReaderContract.LayoutTable.TABLE_NAME, values, FeedReaderContract.LayoutTable._ID + "=" + id, null);
//                db.close();
                callBack.onItemInserted();
            }
        });

        return true;
    }

    @Override
    public ArrayList<Layout> getAllItems() {
        TableDbHelper dbHelper = TableDbHelper.getInstanceLayout(G.context);
//
        // Gets the data repository in write mode
        if (dbHelper.isTableExists(FeedReaderContract.LayoutTable.TABLE_NAME, true)) {

            final SQLiteDatabase db = dbHelper.getWritableDatabase();

            Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.LayoutTable.TABLE_NAME, null);
//            db.close();
            return getItemsByCursor(cursor, db);
        } else {
            return new ArrayList<>();
        }
    }

    @Override
    public ArrayList<Layout> getItemsByCursor(Cursor cursor, SQLiteDatabase db) {
        try {
            ArrayList<Layout> layouts = new ArrayList<>();
            if (cursor.moveToFirst()) {
                while (!cursor.isAfterLast()) {

                    layouts.add(getItemForCursor(cursor));

                    cursor.moveToNext();
                }
            }
            cursor.close();
//            db.close();
            return layouts;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
//            db.close();
            cursor.close();
        }
//        db.close();
        return new ArrayList<>();
    }

    @Override
    public String getImgURLById(long id) {
        Layout layout = fetchById(id);
        return layout.getImg();
    }

    @Override
    public ContentValues getValuse(Layout item) {
        return null;
    }

//    @Override
//    public void downloadImages(IDBResultView callBack) {
//        ArrayList<Layout> accessories = getAllItems();
//        for (int i = 0 ; i < accessories.size() ; i++){
//            updateImgPath(accessories.get(i).getImg(),accessories.get(i).get_ID(),callBack);
//        }
//    }

    public long get_ID() {
        return _ID;
    }

    public void set_ID(long _ID) {
        this._ID = _ID;
    }
    //endregion
}
