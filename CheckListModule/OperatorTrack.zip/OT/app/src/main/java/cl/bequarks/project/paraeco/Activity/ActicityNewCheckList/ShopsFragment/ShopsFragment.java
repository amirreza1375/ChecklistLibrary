package cl.bequarks.project.paraeco.Activity.ActicityNewCheckList.ShopsFragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Shop;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.ShopPresenter;
import cl.bequarks.project.paraeco.Global.EasyLocationProvider;
import cl.bequarks.project.paraeco.Global.GPSTracker;
import cl.bequarks.project.paraeco.Permissions.Model.Permission;
import cl.bequarks.project.paraeco.Permissions.Presenter.PermissionPresenter;
import cl.bequarks.project.paraeco.Permissions.View.IPermissionView;
import cl.bequarks.project.paraeco.R;

import static android.content.Context.LOCATION_SERVICE;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ShopsFragment} interface
 * to handle interaction events.
 * Use the {@link ShopsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ShopsFragment extends Fragment implements ShopRecyclerAdapter.ShopClickListener
,IPermissionView {

    public static final String TAG = "asyncTag";

    private EasyLocationProvider easyLocationProvider;

    private SearchForShops searchForShops;

    private PermissionPresenter permissionPresenter;

    AlertDialog dialogLoading;
    LinearLayout parent;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    public static String SHOPTYPE = "SHOPTYPE";

    //region presenters
    private ShopPresenter shopPresenter;
    private Shop shop;
    //endregion

    private String currentType;

    private LoadShops loadShops;

    private ArrayList<SearchForShops> searches;

    private RecyclerView recyclerView;
    private ArrayList<Shop> shops;
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private ShopActionLisntener mListener;

    private int tryCount = 0;
    private int MAX_TRY_COUNT = 6;
    private Handler timeOut;
    private Runnable runnable;

    List<Shop> allShops;

    public ShopsFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment ShopsFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ShopsFragment newInstance(String shopType) {
        ShopsFragment fragment = new ShopsFragment();
        Bundle args = new Bundle();
        args.putString(SHOPTYPE, shopType);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        permissionPresenter = new PermissionPresenter();
        permissionPresenter.addModel(new Permission(getActivity()));
        permissionPresenter.attachView(this);

//        this.tryCount = 0;

//        this.searches = new ArrayList<>();

        recyclerView = view.findViewById(R.id.recycler);
        shops = new ArrayList<>();
        parent = view.findViewById(R.id.parent);

        showShopsLoading();

//        getShops();

        timeOut = new Handler(Looper.getMainLooper());
        runnable = new Runnable() {
            @Override
            public void run() {
                if (dialogLoading != null) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (dialogLoading != null)
                                dialogLoading.dismiss();
                        }
                    });
                }
                showTimeOutMessage();
            }
        };

        timeOut.postDelayed(runnable, 1000 * 10);

        if (isGPSProviderEnable()) {
            getCurrentLocation();
        } else {
            showToast(getActivity(), getString(R.string.turn_gps_on_msg));
            terminateAllThreads();
            finishCurrentActivity();
        }

    }

    private void showTimeOutMessage() {
        Snackbar.make(parent,getString(R.string.noShopFindUpToNow), Snackbar.LENGTH_INDEFINITE).setAction(getString(R.string.finish),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finishCurrentActivity();
                    }
                }).show();
    }

    private void kickOut() {
        if (this.shops != null) {
            if (this.shops.size() == 0) {
                if (getActivity() != null) {
                    terminateAllThreads();
                    getActivity().finish();
                    showToast(getActivity(), getString(R.string.no_shops_around));
                }
            }
        } else {
            if (getActivity() != null) {
                terminateAllThreads();
                getActivity().finish();
                showToast(getActivity(), getString(R.string.no_shops_around));
            }
        }
    }

    private void getCurrentLocation() {
//        tryCount++;
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {

        GPSTracker.getInstance(getActivity(), new GPSTracker.GPSListener() {
            @Override
            public void onLocationTracked(double lat, double latLong) {
//                getShops();
                shops.clear();
                shops = searchByLocationAndType(lat,latLong,currentType);
                if (shops.size() == 0){
                    timeOut.removeCallbacks(runnable);
                    singleDismiss();
                    Toast.makeText(getActivity(), getString(R.string.no_shops_around), Toast.LENGTH_SHORT).show();
                    getActivity().finish();
                }else{
                    timeOut.removeCallbacks(runnable);
                    singleDismiss();
                    setupRecycler();
                }
            }

            @Override
            public void onLocationError(String msg) {
                timeOut.removeCallbacks(runnable);
                singleDismiss();
                Toast.makeText(getActivity(), getString(R.string.GPSnotWorkTurnOnHightPerformance), Toast.LENGTH_SHORT).show();
                getActivity().finish();
            }
        }).getCurrentLocation();
//
//                new GPSTracker(getActivity(), new GPSTracker.GPSListener() {
//                    @Override
//                    public void onLocationTracked(final double lat, final double latLong) {
////                        searches.add(new SearchForShops(lat, latLong));
////                        searches.get(searches.size() - 1).execute("");
//
////                        new Thread(new Runnable() {
////                            @Override
////                            public void run() {
//                                getShops();
//                                shops.clear();
//                                shops = searchByLocationAndType(lat,latLong,currentType);
//                                if (shops.size() == 0){
//                                    timeOut.removeCallbacks(runnable);
//                                    singleDismiss();
//                                    Toast.makeText(getActivity(), getString(R.string.no_shops_around), Toast.LENGTH_SHORT).show();
//                                    getActivity().finish();
//                                }else{
//                                    timeOut.removeCallbacks(runnable);
//                                    singleDismiss();
//                                    setupRecycler();
//                                }
////                            }
////                        }).start();
//
//                    }
//
//                    @Override
//                    public void onLocationError(String msg) {
//                        timeOut.removeCallbacks(runnable);
//                        singleDismiss();
//                        Toast.makeText(getActivity(), getString(R.string.GPSnotWorkTurnOnHightPerformance), Toast.LENGTH_SHORT).show();
//                        getActivity().finish();
//                    }
//                });
//            }
//        }, 1000);
    }

    private void getShops() {
            if (allShops == null) {
//                allShops = Shop.listAll(Shop.class);
                allShops = new Shop().getAllShops();
            } else {
                if (allShops.size() == 0) {
//                    allShops = Shop.listAll(Shop.class);
                    allShops = new Shop().getAllShops();
                }
            }

    }

    private ArrayList<Shop> searchByLocationAndType(double lat, double latlong, String type) {
        ArrayList<Shop> locatedShops = new ArrayList<>();
        getShops();
        for (int i = 0; i < allShops.size(); i++) {
            if (isTypeOk(type, allShops.get(i).getSurveyTypes())) {
                double dis = getDistanceFromLatLonInKm(lat, latlong, allShops.get(i).getLat(), allShops.get(i).getLat_long());
                if (true) {
                    locatedShops.add(allShops.get(i));
                }
            }
        }
        return locatedShops;
    }

    private boolean isTypeOk(String type, String typesStr) {
        if (typesStr == null)
            return true;
        if (typesStr.equals(""))
            return true;
        if (typesStr.length() == 0)
            return true;

        String types[] = typesStr.split(",");
        for (String shopType : types) {
            if (shopType.equals(type))
                return true;
        }
        return false;
    }

    private void terminateAllThreads() {
        for (int i = 0; i < searches.size(); i++) {
            if (searches.get(i) != null) {
                searches.get(i).cancel(true);
            }
            searches.remove(i);
            i--;
        }
    }

    @Override
    public void StoragePermission(boolean status) {

    }

    @Override
    public void LocationPermission(boolean status) {
        if (!status){
            showToast(getActivity(),getString(R.string.permissionErrorGPS));
            finishCurrentActivity();
        }
    }

    @Override
    public void CameraPermission(boolean status) {

    }

    @Override
    public void ReadStoragePermission(boolean status) {

    }


    public class SearchForShops extends AsyncTask<String, Void, String> {

        private double lat;
        private double latLong;

        public SearchForShops(double lat, double latLong) {
            this.lat = lat;
            this.latLong = latLong;
        }

        @Override
        protected void onPostExecute(String string) {
            super.onPostExecute(string);

            if (shops.size() == 0) {
                if (tryCount < MAX_TRY_COUNT) {
                    getCurrentLocation();
                } else {
                    timeOut.removeCallbacks(runnable);
                    singleDismiss();
                    Toast.makeText(getActivity(), getString(R.string.no_shops_around), Toast.LENGTH_SHORT).show();
                    getActivity().finish();
                }
            } else {
                timeOut.removeCallbacks(runnable);
                singleDismiss();
                setupRecycler();
            }
//            if (shops.size() == 0) {
//                if (tryCount < MAX_TRY_COUNT) {
//                    getCurrentLocation();
//                } else {
////                    timeOut.removeCallbacks(runnable);
//                    singleDismiss();
////                    showToast(getActivity(), getString(R.string.noShopsAroundWithCount)
////                            + " "
////                            + allShops.size()
////                            + " "
////                            + getString(R.string.shops));
//                    finishCurrentActivity();
//                    terminateAllThreads();
//                }
//            } else {
//                timeOut.removeCallbacks(runnable);
//                singleDismiss();
//                setupRecycler();
//            }
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {
            shops = searchByLocationAndType(lat, latLong, currentType);

            return null;
        }
    }

    private void singleDismiss() {
        if (getActivity() != null) {
            if (dialogLoading != null) {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        dialogLoading.dismiss();
                    }
                });
            }
        }
    }


    private void updateRecycler() {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (recyclerView.getAdapter() != null) {
                        recyclerView.getAdapter().notifyDataSetChanged();
                    }
                }
            });
        }
    }

    private void setupRecycler() {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ShopRecyclerAdapter adapter = new ShopRecyclerAdapter(getContext(), shops, ShopsFragment.this);
                    recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                    recyclerView.setAdapter(adapter);
                }
            });
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
            this.currentType = getArguments().getString(SHOPTYPE);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_shops, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
//    public void onButtonPressed(Uri uri) {
//        if (mListener != null) {
//            mListener.onFragmentInteraction(uri);
//        }
//    }

    private boolean isGPSProviderEnable() {
        if (getActivity() != null) {
            LocationManager locationManager = (LocationManager)
                    Objects.requireNonNull(this)
                            .getActivity().getSystemService(LOCATION_SERVICE);
            if (locationManager != null) {
                if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    return true;
                }
            }

            showToast(getActivity(), getContext().getString(R.string.turn_gps_on_msg));
            finishCurrentActivity();
        }

        return false;
    }

    public static void showToast(final Activity activity, final String message) {
        if (activity != null) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(activity, message, Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ShopActionLisntener) {
            mListener = (ShopActionLisntener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void Clicked(int id, String name, int subcanal_id) {

        mListener.onShopClicked(id, name, subcanal_id);
    }

    @Override
    public void onLongClicked(String dist, double lat, double lng) {
        showToast(getActivity(),dist + " KM");
    }


    public void showShopsLoading() {
        if (getActivity() != null) {
            if (!getActivity().isFinishing()) {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (dialogLoading != null) {
                            dialogLoading.show();
                            dialogLoading.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        } else {
                            initializeLoadingDialog();
                            dialogLoading.show();
                            dialogLoading.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        }

                    }
                });
            }
        }
    }


    public void dismissShopsLoading() {
        if (tryCount > MAX_TRY_COUNT) {
            if (getActivity() != null) {
                if (!getActivity().isFinishing()) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (dialogLoading != null)
                                dialogLoading.dismiss();
                        }
                    });

                    finishCurrentActivity();
                }
            }

        } else {
            if (this.shops.size() > 0) {//start delay before shops appeare
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (getActivity() != null) {
                            if (!getActivity().isFinishing()) {
                                getActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (dialogLoading != null)
                                            dialogLoading.dismiss();
                                    }
                                });
                            }
                        }
                    }
                }, 300);

            }
        }


    }

    private void initializeLoadingDialog() {
        if (dialogLoading == null) {
            assert getActivity() != null;
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setCancelable(false);
            LayoutInflater inflater = getLayoutInflater();
            View vieww = inflater.inflate(R.layout.layout_loaction_search, parent, false);
            builder.setView(vieww);
            dialogLoading = builder.create();
        }
    }


    private void getLocation() {

        tryCount++;

//        Location location = new GPSTracker(getContext()).getLocation();
//
//        double lat = location != null ? location.getLatitude() : 0;
//        double latlong = location != null ? location.getLongitude() : 0;

        GPSTracker.getInstance(getContext(), new GPSTracker.GPSListener() {
            @Override
            public void onLocationTracked(double lat, double latLong) {
//                ShopsFragment.this.shops.clear();
//                ShopsFragment.this.shops.addAll(getShops(lat, latLong));

                if (ShopsFragment.this.shops.size() == 0) {

                    try {
                        Thread.sleep(4000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
//                    loadShops = new LoadShops();
//                    loadShops.execute("");
                }
            }

            @Override
            public void onLocationError(String msg) {

            }
        });


    }

    private ArrayList<Shop> getShops(double lat, double latlong) {
        ArrayList<Shop> locatedShops = new ArrayList<>();
        Shop shop = new Shop();
        if (allShops == null) {
            allShops = shop.getAllShops();
        }

        for (int i = 0; i < allShops.size(); i++) {
            Shop shopTemp = allShops.get(i);
            double dis = getDistanceFromLatLonInKm(lat, latlong, shopTemp.getLat(), shopTemp.getLat_long());
            if (dis < 1) {
                locatedShops.add(shopTemp);
            }

        }
        return locatedShops;
    }


    public double getDistanceFromLatLonInKm(double lat1, double lon1, double lat2, double lon2) {

        double earthRadius = 6371; // in miles, change to 6371 for kilometer output

        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lon2 - lon1);

        double sindLat = Math.sin(dLat / 2);
        double sindLng = Math.sin(dLng / 2);

        double a = Math.pow(sindLat, 2) + Math.pow(sindLng, 2)
                * Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2));

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        double dist = earthRadius * c;

        Log.d("distance", String.valueOf(dist));

        double xr = lat2 < 0 && lon2 < 0 ? -1 : 1;
        double result = dist - 0.07362716373246034;
        return result; // output distance,  MinILES
    }


    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface ShopActionLisntener {
        // TODO: Update argument type and name
        void onShopClicked(int id, String name, int subCanalId);
    }


    private void finishCurrentActivity() {
        if (getActivity() != null) {
            getActivity().finish();
            timeOut.removeCallbacks(runnable);
        }
    }

    public static void log(String msg) {

        Log.i(TAG, "log: -> " + msg);

    }

    public class LoadShops extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            showShopsLoading();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dismissShopsLoading();
            updateRecycler();
        }

        @Override
        protected String doInBackground(String... strings) {

            getLocation();

            return null;
        }
    }

}
