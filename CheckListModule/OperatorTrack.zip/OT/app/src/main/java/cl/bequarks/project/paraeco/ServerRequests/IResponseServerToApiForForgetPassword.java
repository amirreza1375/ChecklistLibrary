package cl.bequarks.project.paraeco.ServerRequests;

public interface IResponseServerToApiForForgetPassword {

    void onEmailSent(String message);
    void onWrongEmail(String error);
    void onFail(String error);

}