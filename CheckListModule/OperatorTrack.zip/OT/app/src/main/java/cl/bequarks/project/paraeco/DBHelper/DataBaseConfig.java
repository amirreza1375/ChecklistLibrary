package cl.bequarks.project.paraeco.DBHelper;

import android.content.SharedPreferences;

import cl.bequarks.project.paraeco.Global.G;

import static android.content.Context.MODE_PRIVATE;
import static cl.bequarks.project.paraeco.sharedpreference.Config.sharedPreferencName;

public class DataBaseConfig {

    public static final String databaseName = "parquearaucoaeco";

    //region result DB
    public static String DATABASE_NAME = databaseName+".db";
    public static final int VERSION = 1;//changing this version will make user loose draf,and results
    public static String resultDataBaseVersion = "DB_Result_VERSION";
    public static int getResultDB_VERSION() {
        int version = G.context.getSharedPreferences(sharedPreferencName, MODE_PRIVATE).getInt(resultDataBaseVersion, 1);
        return version;
    }

    public static void setResultDB_VERSION(int version) {
        SharedPreferences.Editor editor = G.context.getSharedPreferences(sharedPreferencName, MODE_PRIVATE).edit();
        editor.putInt(resultDataBaseVersion, version).apply();
    }

    public static boolean isResultVersionChanged(){
        return VERSION != getResultDB_VERSION();
    }
    public static boolean hasRsultVersionError(){
        return VERSION < getResultDB_VERSION();
    }
    //endregion

    //region log DB
    public static String LOG_DATABASE_NAME = databaseName+"log.db";
    public static final int LOG_VERSION = 1;
    public static String loggerDataBaseVersion = "DB_Logger_VERSION";

    public static void setLoggerDBVersion(int version) {
        SharedPreferences.Editor editor = G.context.getSharedPreferences(sharedPreferencName, MODE_PRIVATE).edit();
        editor.putInt(loggerDataBaseVersion, version).apply();
    }

    public static int getLoggerDBVersion() {
        int version = G.context.getSharedPreferences(sharedPreferencName, MODE_PRIVATE).getInt(loggerDataBaseVersion, 1);
        return version;
    }
    public static boolean isLoggerVersionChanged(){
        return LOG_VERSION != getLoggerDBVersion();
    }
    public static boolean hasLoggerVersionError(){
        return LOG_VERSION < getLoggerDBVersion();
    }

    //endregion

    //region event DB
    public static String EVENT_DATABASE_NAME = databaseName+"event.db";
    public static final int EVENT_VERSION = 1;
    public static final String logEventDataBaseVersion = "DB_LOG_EVENT_VERSIOM";

    public static void setLogEventDBVersion(int version){
        SharedPreferences.Editor editor = G.context.getSharedPreferences(sharedPreferencName,MODE_PRIVATE).edit();
        editor.putInt(logEventDataBaseVersion,version).apply();
    }

    public static int getLogEventDBVersion(){
        int version =  G.context.getSharedPreferences(sharedPreferencName,MODE_PRIVATE).getInt(logEventDataBaseVersion,1);
        return version;
    }
    public static boolean isEventVersionChanged(){
        return EVENT_VERSION != getLogEventDBVersion();
    }
    public static boolean hasEventVersionError(){
        return EVENT_VERSION < getLogEventDBVersion();
    }
    //endregion

    //region params DB
    public static String PARAMS_DATABASE_NAME = databaseName+"params.db";
    public static final int PARAMS_VERSION = 1;
    public static String paramsDataBaseVersion = "DB_VERSION";
    public static int getParamsDB_VERSION() {
        int version = G.context.getSharedPreferences(sharedPreferencName, MODE_PRIVATE).getInt(paramsDataBaseVersion, 1);
        return version;
    }

    public static void setParamsDB_VERSION(int version) {
        SharedPreferences.Editor editor = G.context.getSharedPreferences(sharedPreferencName, MODE_PRIVATE).edit();
        editor.putInt(paramsDataBaseVersion, version).apply();
    }
    public static boolean isParamsVersionChanged(){
        return PARAMS_VERSION != getParamsDB_VERSION();
    }
    public static boolean hasParamsVersionError(){
        return PARAMS_VERSION < getParamsDB_VERSION();
    }

    //rendregion

}
