package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model;

public interface IItemInsertListener {
    void onItemInserted();
}
