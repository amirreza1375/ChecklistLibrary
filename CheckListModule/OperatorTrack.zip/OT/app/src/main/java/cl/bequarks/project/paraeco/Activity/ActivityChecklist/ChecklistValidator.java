package cl.bequarks.project.paraeco.Activity.ActivityChecklist;

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActicityNewCheckList.CheckListFragment.CheckListsRecyclerAdapter;

public class ChecklistValidator {

    private static final String TAG = "ChecklistValidator";

    private JSONObject checklist;
    private SQLiteDatabase db;
    private CheckListsRecyclerAdapter.ViewHolder holder;
    private ArrayList<String> ides;
    private ArrayList<String> errors;

    public ChecklistValidator(JSONObject checklist) {

        this.checklist = checklist;

        this.ides = new ArrayList<>();
        this.errors = new ArrayList<>();
    }

    public String isValid() {


//        new Thread(new Runnable() {
//            @Override
//            public void run() {

                boolean checklistHasError = false;

                if (!checklist.has("pages")) {
                    Log.i(TAG, "run: no pages");
                    errors.add("No hay páginas");
                    checklistHasError = true;
                }

                if (!checklist.has("title")) {
                    Log.i(TAG, "run: no title");
                    errors.add("Sin título");
                    checklistHasError = true;
                }

                if (getChecklistPageSize(checklist) <= 0) {
                    Log.i(TAG, "run: pages zero");
                    errors.add("La página es cero");
                    checklistHasError = true;
                }

                if (!hasValidVisiblePages(checklist)) {
                    Log.i(TAG, "run: invalid visible page");
                    checklistHasError = true;
                }
                if (pageElementHasError(checklist)) {
                    Log.i(TAG, "run: page element error");
                    checklistHasError = true;
                }
                if (checklistHasError) {
                    String allErrors = "";
                    for (int i = 0; i < errors.size(); i++) {

                        allErrors = allErrors + errors.get(i) + "\n";

                    }
                    return allErrors;
                } else {
                    return "";
                }
//            }
//        }).start();
    }

    private boolean pageElementHasError(JSONObject checklist) {

        boolean hasError = false;

        try {
            JSONArray pages = checklist.getJSONArray("pages");

            for (int i = 0; i < pages.length(); i++) {

                JSONObject page = pages.getJSONObject(i);

                JSONArray elements = page.getJSONArray("elements");

                for (int j = 0; j < elements.length(); j++) {

                    JSONObject element = elements.getJSONObject(j);

                    if (!element.has("id")) {
                        Log.i(TAG, "pageElementHasError: no id for element");
                        errors.add("Pregunta " + element.getString("name") + " no tengo identificación");
                        hasError = true;
                    }

                    if (element.getString("id").equals("")) {
                        Log.i(TAG, "pageElementHasError: empty id for element");
                        errors.add("Pregunta " + element.getString("name") + " tiene id vacío");
                        hasError = true;
                    }

                    ides.add(element.getString("id"));

                }

            }

        } catch (JSONException e) {
            e.printStackTrace();
            hasError = true;
            errors.add(e.getMessage());
            Log.i(TAG, "pageElementHasError: " + e.getMessage());
        }


        return pageHasDuplicatedIdes(ides);
    }

    private boolean pageHasDuplicatedIdes(ArrayList<String> ides) {
        boolean hasDuplciate = false;
        for (int i = 0; i < ides.size(); i++) {

            for (int j = i + 1; j < ides.size(); j++) {

                if (ides.get(i).equals(ides.get(j))) {
                    Log.i(TAG, "pageHasDuplicatedIdes: duplicated ides " + ides.get(j));
                    errors.add("ID = " + ides.get(j) + " está duplicado");
                    hasDuplciate = true;
                }

            }

        }
        return hasDuplciate;
    }

    private boolean hasValidVisiblePages(JSONObject checklist) {
        boolean Error = true;
        try {
            JSONArray pages = checklist.getJSONArray("pages");
            for (int i = 0; i < pages.length(); i++) {

                JSONObject page = pages.getJSONObject(i);

                if (page.has("visiblePage")) {

                    String visiblePage = page.getString("visiblePage");

                    if (visiblePage.equals("")) {
                        Error = false;
                        continue;
                    }

                    if (visiblePage.equals(":")) {
                        Error = false;
                        continue;
                    }

                    String[] VP = visiblePage.split(":");

                    if (VP.length < 2) {
                        Log.i(TAG, "hasValidVisiblePages: not valid visisble page : " + visiblePage);
                        errors.add("Página no válida visible" + visiblePage);
                        Error = true;
                    }
                } else {
                    Error = false;
                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
            Log.i(TAG, "hasValidVisiblePages: " + e.getMessage());
            return Error = true;
        }
        return !Error;
    }

    private int getChecklistPageSize(JSONObject checklist) {
        try {
            return checklist.getJSONArray("pages").length();
        } catch (JSONException e) {
            e.printStackTrace();
            return 0;
        }
    }

    public interface CheckListValidatorListener {
        void onValidChecklist(long id, CheckListsRecyclerAdapter.ViewHolder holder, SQLiteDatabase db);

        void onNotValidChecklist(long id, CheckListsRecyclerAdapter.ViewHolder holder, ArrayList<String> errors, SQLiteDatabase db);
    }

}
