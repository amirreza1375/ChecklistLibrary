package cl.bequarks.project.paraeco.Notification.Presenter;

public interface INotificationPresenter {

    void showNotification();



}
