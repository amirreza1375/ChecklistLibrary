package cl.bequarks.project.paraeco.Activity.ActivityProfile;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import cl.bequarks.project.paraeco.Activity.ActivityBase;
import cl.bequarks.project.paraeco.Activity.ActivityLogin.ActivityLogin;
import cl.bequarks.project.paraeco.Activity.ActivityLogin.Model.User;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Version;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.VersionPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IVersionView;
import cl.bequarks.project.paraeco.Activity.ActivityProfile.Presenter.ProfilePresenter;
import cl.bequarks.project.paraeco.Activity.ActivityProfile.View.IProfileView;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.Global.NetWorkStatus;
import cl.bequarks.project.paraeco.Global.SwipeDetector;
import cl.bequarks.project.paraeco.Permissions.Model.Permission;
import cl.bequarks.project.paraeco.Permissions.Presenter.PermissionPresenter;
import cl.bequarks.project.paraeco.Permissions.View.IPermissionView;
import cl.bequarks.project.paraeco.R;
import cl.bequarks.project.paraeco.sharedpreference.Config;

import static cl.bequarks.project.paraeco.sharedpreference.Config.recycleBitmap;

/**
 * Created by shahr on 2/16/2019.
 */

public class ActivityProfile extends ActivityBase implements NetWorkStatus.NetworkStatusListener,IPermissionView
                                                                ,IProfileView,View.OnClickListener,IVersionView
{

    //region view
    private ImageView imgProfile;
    private Button btnSave;
    private EditText editTextPass;
    private EditText editTextRepeatPass;
    private String pass;
    private String repeatPass;
    private TextView name;
    private TextView email;
    private ImageView back;


    private ProgressDialog progressDialog;
    private BroadcastReceiver nw;
    private Boolean isConnected = false;

    public Boolean getIsConnected(){
        return isConnected;
    }

    private PermissionPresenter permissionPresenter;
    private Permission permission;
    private ProfilePresenter profilePresenter;
    private User user;
    private int requestCode=100;

    private VersionPresenter versionPresenter;
    private Version versionl;

    //region Define Gesture
    private GestureDetector gestureDetector;
    private SwipeDetector swipeDetector;
    //endregion



    //region helper method
    private String getDevId(){
        return Settings.Secure.getString(G.context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }
    private String getTokken(){
        return G.context.getSharedPreferences(Config.sharedPreferencName, Context.MODE_PRIVATE).getString(Config.tokken, "");
    }
    //endregion

    //region activity cycle
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting_new);
        //region find view
        imgProfile = findViewById(R.id.imgProfile);
        btnSave = findViewById(R.id.save);
        editTextPass = findViewById(R.id.pass);
        editTextRepeatPass = findViewById(R.id.conf_pass);
        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        back = findViewById(R.id.back);
        //endregion

        //region Initialize Gesture
        swipeDetector = new SwipeDetector();
        swipeDetector.setSwipeListener(new SwipeDetector.SwipeListener() {
            @Override
            public void onLeftToRight() {
                finish();
                overridePendingTransition(R.anim.close_scale,R.anim.close_scale);
            }
        });
        gestureDetector = new GestureDetector(swipeDetector);
        //endregion

        btnSave.setOnClickListener(this);
        imgProfile.setOnClickListener(this);
        back.setOnClickListener(this);
        //===============================
        nw = new NetWorkStatus(this);
        //======================================
        permission = new Permission(this);
        permissionPresenter = new PermissionPresenter();
        permissionPresenter.addModel(permission);
        permissionPresenter.attachView(this);
        permissionPresenter.CheckReadStoragePermission();
        //==========================================
        profilePresenter = new ProfilePresenter();
        user = new User(getDevId(),getTokken(),"");
        SharedPreferences sharedPreferences = getSharedPreferences(Config.sharedPreferencName, Context.MODE_PRIVATE);
        user.addSharedPreferences(sharedPreferences);
        profilePresenter.attachView(this);
        profilePresenter.addModel(user);
        //==============================================
        versionl = new Version();
        versionPresenter = new VersionPresenter(this,versionl);
        initializDialog();
    }

    //region Gesture Method
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        // TouchEvent dispatcher.
        if (gestureDetector != null) {
            if (gestureDetector.onTouchEvent(ev))
                // If the gestureDetector handles the event, a swipe has been
                // executed and no more needs to be done.
                return true;
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return gestureDetector.onTouchEvent(event);
    }
    //endregion

    @Override
    protected void onResume() {
        super.onResume();
        profilePresenter.setUserData();
        if (nw != null)
            registerReceiver(nw, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));

    }

    @Override
    protected void onPause() {
        super.onPause();
        if (nw != null)
            unregisterReceiver(nw);

    }
    //endregion

    //region check netWork
    @Override
    public void onConnected() {
        isConnected = true;
    }

    @Override
    public void onDisConnected() {
        isConnected = false;
    }
    //endregion

    //region permission
    @Override
    public void ReadStoragePermission(boolean status) {
        if(!status){
            permissionPresenter.getReadStoragePermission();
        }
    }
    @Override
    public void StoragePermission(boolean status) {}
    @Override
    public void LocationPermission(boolean status) {}
    @Override
    public void CameraPermission(boolean status) {}

    @Override
    public void showDialog() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                progressDialog.show();
            }
        });
    }

    @Override
    public void dismissDialog() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                progressDialog.dismiss();
            }
        });
    }

    @Override
    public void setProfilePic(Bitmap bitmap) {
        if(bitmap==null){
            profilePresenter.getProfilePic();
            imgProfile.setImageResource(R.drawable.nouser);
            recycleBitmap(bitmap);
        }else{
            imgProfile.setImageBitmap(bitmap);
            recycleBitmap(bitmap);
        }

    }

    @Override
    public void setName(String name) {
        this.name.setText(name);
    }

    @Override
    public void setEmail(String email) {
        this.email.setText(email);
    }


    @Override
    public void onValidPass() {
        if(isConnected)
            profilePresenter.ChangePassword(pass);
        else {
            Toast.makeText(this,getString(R.string.no_network),Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onInvalidPass(String error) {

        switch (error) {
            case "length":
                editTextPass.setError(getString(R.string.short_pass));
                editTextRepeatPass.setError(null);
                break;
            case "notSame":
                editTextPass.setError(getString(R.string.password_not_match_msg));
                editTextRepeatPass.setError(getString(R.string.password_not_match_msg));
                break;
            default:
                break;
        }
    }

    @Override
    public void onChangePassword(String message) {
        profilePresenter.removeUserInfo();
        versionPresenter.DeleteVersion();
    }

    @Override
    public void onNotChagePassword(String message) {
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onSuccessRemoveUserInfo() {
        sendToLogin();
    }

    @Override
    public void onFailRemoveUserInfo() {
        Toast.makeText(this,"cant remove user info",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void uploadSuccess(String newUrl) {

        profilePresenter.setUserData();

    }

    @Override
    public void uploadFail(String error) {

        Toast.makeText(this,error,Toast.LENGTH_SHORT).show();

    }

    @Override
    public void profilePicDownloaded() {
        profilePresenter.setUserData();
    }

    @Override
    public void showProfileDialog() {

    }

    @Override
    public void dismissProfileDialog() {

    }

    @Override
    public void onClick(View v) {
        if(v==btnSave)
        {
            pass=editTextPass.getText().toString();
            repeatPass = editTextRepeatPass.getText().toString();
            profilePresenter.ValidationPass(pass,repeatPass);
        }
        if(v==imgProfile)
        {
            chooseImage();
        }
        if (v==back)
        {
            finish();
            overridePendingTransition(R.anim.open_scale, R.anim.close_scale);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.open_scale, R.anim.close_scale);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        //send to server
        if (requestCode == this.requestCode && resultCode == RESULT_OK){
            Uri uri = data.getData();
            profilePresenter.uploadImage(uri);
        }

    }

    private void sendToLogin() {
        Toast.makeText(G.context,getString(R.string.pass_changed_msg),Toast.LENGTH_SHORT).show();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(G.context,ActivityLogin.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
                overridePendingTransition(R.anim.open_scale,R.anim.close_scale);
                finish();
            }
        },1000);
    }

    //rendregion
    private void chooseImage(){
        Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, requestCode);
    }

    private void initializDialog(){
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle(getString(R.string.uploading_pic));
        progressDialog.setMessage(getString(R.string.main_prgrss_msg));
        progressDialog.setCancelable(false);
    }

    @Override
    public void onVersionChanged() {

    }

    @Override
    public void ServerVersion(String version) {

    }

    @Override
    public void onDeleteVersion() {

    }

    @Override
    public void onCantDeleteVersion() {

    }
}
