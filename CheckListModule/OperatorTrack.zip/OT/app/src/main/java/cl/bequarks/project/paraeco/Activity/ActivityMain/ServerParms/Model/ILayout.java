package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model;

import java.util.ArrayList;

public interface ILayout {

    int countPos();

    ArrayList<Layout> fetchLayoutByShop(int i);

    String getImg();

    String getImgPath();

    int getOrderId();

    String getName();

    String getPositions();

    String getReplaceMent();

    String getShops();


}
