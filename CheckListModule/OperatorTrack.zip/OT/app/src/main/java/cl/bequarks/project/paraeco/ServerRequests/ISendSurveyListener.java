package cl.bequarks.project.paraeco.ServerRequests;

public interface ISendSurveyListener {

    void onFailed(String error);
    void onSurveySent(double serverId);

}
