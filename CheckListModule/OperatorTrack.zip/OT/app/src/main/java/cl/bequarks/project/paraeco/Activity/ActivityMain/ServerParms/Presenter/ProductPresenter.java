package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter;

import org.json.JSONArray;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Product;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBResultView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IProductView;
import cl.bequarks.project.paraeco.Activity.PresenterBasic;
import cl.bequarks.project.paraeco.sharedpreference.Config;

public class ProductPresenter extends PresenterBasic<IProductView,Product> implements IProductPresenter {

    @Override
    public void getProducts() {
        view.Products(model.getAllItems());
    }

    @Override
    public void getProductById(long id) {
//        view.ProductsById(model.ge);
    }

    @Override
    public void Insert(JSONArray products) {
        model.refreshTable(products, new IDBResultView() {
            @Override
            public void onSuccess() {
                view.ProductsInserted();
            }

            @Override
            public void onItemInserted() {
                view.onItemInserted(Config.Params.PRODUCT);
            }

            @Override
            public void onFail(String error) {
                view.ErrorInsertingProduct(error);
            }
        });
    }
}
