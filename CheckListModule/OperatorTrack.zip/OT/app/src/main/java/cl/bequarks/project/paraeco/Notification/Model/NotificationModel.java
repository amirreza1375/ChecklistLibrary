package cl.bequarks.project.paraeco.Notification.Model;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import cl.bequarks.project.paraeco.Activity.ActivitySplash.ActivitySplash;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.R;

public class NotificationModel implements  INotificationModel{

    public static final String CHANNEDL_ID = "DRAFT";

    @Override
     public void showNotification(NotificationCompat.Builder mBuilder) {
        NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(G.context);
        notificationManagerCompat.notify(CHANNEDL_ID, 0, mBuilder.build());
    }

    @Override
     public void createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEDL_ID, "name", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Channel Description");
            NotificationManager manager = G.context.getSystemService(NotificationManager.class);
            assert manager != null;
            manager.createNotificationChannel(channel);
        }
    }

    @Override
     public NotificationCompat.Builder sendNotification() {
        Intent intent = new Intent(G.context, ActivitySplash.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(G.context, 0, intent, 0);
        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(G.context, CHANNEDL_ID)
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setContentTitle(G.context.getString(R.string.notif_title))
                        .setContentText(G.context.getString(R.string.notif_message))
//                        .setStyle(new NotificationCompat.BigTextStyle().bigText("puede terminar su lista de verificación seleccionando el último elemento de sus borradores"))
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        //set intent
                        .setContentIntent(pendingIntent)
                        .setAutoCancel(true)
                        .setSound(alarmSound);
        return builder;

    }

}
