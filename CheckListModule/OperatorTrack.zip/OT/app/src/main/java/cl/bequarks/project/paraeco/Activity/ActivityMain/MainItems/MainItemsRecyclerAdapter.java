package cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.UserCheckList;
import cl.bequarks.project.paraeco.R;

public class MainItemsRecyclerAdapter extends RecyclerView.Adapter<ResultHolder> implements ResultViewActionListener {

    private static final String TAG = "MainItemsRecyclerAdapte";

    private final Context context;
    private final ArrayList<UserCheckList> items;
    private ResultViewActionListener listener;
    private boolean isSyncUpdate = false;

    public MainItemsRecyclerAdapter(Context context, ArrayList<UserCheckList> itmes,ResultViewActionListener listener){

        this.context = context;
        this.items = itmes;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ResultHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        ResultHolder resultHolder =  new ResultHolder(LayoutInflater.from(context).inflate(R.layout.layout_result_item_new,viewGroup,false), items.get(i),context,listener);
        resultHolder.setIsRecyclable(false);
        return resultHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ResultHolder resultHolder, int i) {
        Log.i(TAG, "onBindViewHolder: "+i);
        resultHolder.setUserCheckList(items.get(i));
        resultHolder.setImageStatus(isSyncUpdate);
        resultHolder.setData();
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    @Override
    public void onItemClicked(boolean isDraft, boolean isSynced, long checklistId, long checkListDataId, String shopId, String shopName, String checkListName) {

    }

    @Override
    public void onItemLongCicked(String Error, long id, int position, ResultHolder holder) {

    }

    public void removeItem(int position) {
        long id = items.get(position).get_ID();
        items.remove(position);
        notifyItemRemoved(position);
        listener.removeItem(id);


    }

    @Override
    public void removeItem(long id) {

    }

    @Override
    public void innnerUpdateStart() {

    }

    @Override
    public void updateRow(int position,long id) {
        listener.updateRow(position,id);
    }

    public void setIsSyncUpdate(boolean b) {
        this.isSyncUpdate = b;
    }

    public void resendItem(long id, UserCheckList userCheckList, int position, ResultHolder holder) {
        for (int i = 0; i < items.size() ; i++){
            if (items.get(i).get_ID() == id){
                items.set(i,userCheckList);
                holder.resend(userCheckList);
            }
        }
    }
}

