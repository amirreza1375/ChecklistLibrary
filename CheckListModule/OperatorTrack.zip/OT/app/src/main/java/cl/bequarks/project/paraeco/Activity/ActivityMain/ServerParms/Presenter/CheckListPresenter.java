package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter;


import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Checklist;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.ICheckListView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBArrayResultView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBResultView;
import cl.bequarks.project.paraeco.Activity.PresenterBasic;
import cl.bequarks.project.paraeco.sharedpreference.Config;


import org.json.JSONArray;

import java.util.ArrayList;

public  class CheckListPresenter extends PresenterBasic<ICheckListView,Checklist> implements IChecklistPresenter {

    public void Insert(final JSONArray checklists) {

        model.refreshTable(checklists, new IDBResultView() {
            @Override
            public void onSuccess() {
                view.CheckListInserted(true);
            }

            @Override
            public void onItemInserted() {
                view.onItemInserted(Config.Params.CHECKLIST);
            }

            @Override
            public void onFail(String error) {
                view.CheckListInserted(false);
            }
        });
    }

    public void getCheckLists() {
        view.CheckLsits(new Checklist().getAllItems());
    }

    @Override
    public void getByTypeAndSubCanal(final String shopId, final int type, final int subCanal) {
        new Thread(new Runnable() {
            @Override
            public void run() {
        model.fetchByTypeAndSubCanal(shopId,type, subCanal, new IDBArrayResultView<Checklist>() {
            @Override
            public void onSuccess(ArrayList<Checklist> results) {
                    view.CheckListByTypeAndSubCanal(results);
            }

            @Override
            public void onFail(String error) {
                view.NoCheckListWithThisType(error);
            }
        });

            }
        }).start();
    }

    public void getCheckListById(long id) {
        view.Checklist(new Checklist().fetchById(id));
    }

    public void getCheckListByType(final int type) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                model.fetchByType(type, new IDBArrayResultView<Checklist>() {
                    @Override
                    public void onSuccess(ArrayList<Checklist> results) {
                        view.TypeCheckList(results);
                    }

                    @Override
                    public void onFail(String error) {
                        view.NoCheckListWithThisType(error);
                    }
                });
            }
        }).start();

    }

}
