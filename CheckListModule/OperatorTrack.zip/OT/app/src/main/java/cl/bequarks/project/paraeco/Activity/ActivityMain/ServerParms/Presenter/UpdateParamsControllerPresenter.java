package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter;

import android.os.AsyncTask;
import android.provider.Settings;
import android.util.Log;

import cl.bequarks.project.paraeco.Activity.PresenterBasic;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.ServerRequests.ApiService;
import cl.bequarks.project.paraeco.ServerRequests.IResponseServerToApiForGetParams;
import cl.bequarks.project.paraeco.sharedpreference.Config;

/**
 * Created by shahr on 2/6/2019.
 */

public class UpdateParamsControllerPresenter extends PresenterBasic<IResponseServerToApiForGetParams,ApiService> {

    private static final String TAG = "UpdateParamsControllerP";

    private int totalNumberOfTables;
    private int numberOfRefreshedTable=0;

    private boolean isConntected;

    public int getNumberOfRefreshedTable() {
        return numberOfRefreshedTable;
    }

    public UpdateParamsControllerPresenter(){
//        if(totalNumberOfTables<0)
//            totalNumberOfTables=0;
//        this.totalNumberOfTables = totalNumberOfTables;
    }

    public void getDBsDataFromServer(boolean isConntected){
        this.isConntected= isConntected;
        numberOfRefreshedTable=0;
        new GetParamsFromServer().execute("");
    }

    public int getTotalNumberOfTables(){
        return this.totalNumberOfTables;
    }
    public void setTotalNumberOfTables(int totalNumberOfTables) {
        this.totalNumberOfTables = totalNumberOfTables;
    }

    public void increamentItemCount(){
        this.totalNumberOfTables++;
    }
    private class GetParamsFromServer extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            try {
                model.getParams(
                        Settings.Secure.getString(G.context.getContentResolver(), "android_id"),
                        G.context.getSharedPreferences(Config.sharedPreferencName, 0).getString(Config.tokken, ""),
                        view);
            }catch (Exception e){
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            view.onSuccessGetParams();
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //TODO:what is it exacly?
//            updatedModelsCount = 0;
//            isUpdateDataInProccess = true;
            if(isConntected)
                view.showDialog();
        }
    }

    public void checkRefreshingTables(boolean status,String nameOfTable){
        numberOfRefreshedTable++;
        view.onItemRefteshed(numberOfRefreshedTable,totalNumberOfTables,nameOfTable);
        Log.i(TAG, "checkRefreshingTables: "+numberOfRefreshedTable+" of "+totalNumberOfTables+" -> "+nameOfTable);
        if(status){
            if(numberOfRefreshedTable==totalNumberOfTables){
                view.allTableRefresh();
                numberOfRefreshedTable = 0;
                totalNumberOfTables = 0;
            }
        }
        else
        {
           view.onError(nameOfTable);
           numberOfRefreshedTable=0;
        }

    }
}
