package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View;


import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Layout;

import java.util.ArrayList;
import java.util.List;

public interface ILayoutView   {
    void LayoutById(Layout layout);

    void LayoutInserted(boolean status);

    void Layouts(List<Layout> list);

    void LayoutsByShop(ArrayList<Layout> arrayList);


    void onItemInserted(String name);
}
