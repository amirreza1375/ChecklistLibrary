package cl.bequarks.project.paraeco.Activity.ActivityTutorial.ChecklistTutorial;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.checklist.BaseViewModel.ElemetActionListener;
import com.example.checklist.CheckBox.CheckBoxGroup;
import com.example.checklist.Commentario.Commentario;
import com.example.checklist.Database.ModuleLogEvent;
import com.example.checklist.ImageFile.ImageFileConcept;
import com.example.checklist.ImageSliderView.ImagesViewer;
import com.example.checklist.MultiTextGenerator.MultiText;
import com.example.checklist.PageGenerator.CheckListPager;
import com.example.checklist.PictureElement.PicturePickerItemModel;
import com.example.checklist.RadioGroupMaker.RadioGroupMaker;
import com.example.checklist.SeekBar.Nouislider;
import com.example.checklist.SignatureView.SignatureElement;
import com.takusemba.spotlight.OnSpotlightEndedListener;
import com.takusemba.spotlight.OnSpotlightStartedListener;
import com.takusemba.spotlight.SimpleTarget;
import com.takusemba.spotlight.Spotlight;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.R;
import cl.bequarks.project.paraeco.sharedpreference.Config;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ChecklistTutorialFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link ChecklistTutorialFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ChecklistTutorialFragment extends Fragment implements CheckListPager.CheckListListener
         , ElemetActionListener {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private LinearLayout parent;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;
    private Button pre, next,btnChooseShop;

    private CheckBoxGroup checkBoxGroup;
    private TextView checkboxTitle;
    private TextView checkboxModel;

    private RadioGroupMaker radioGroupMaker;
    private ImageFileConcept imageFileConcept;
    private Commentario commentario;
    private Nouislider nouislider;
    private MultiText multiText;
    private SignatureElement signatureElement;


    public ChecklistTutorialFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ChecklistTutorialFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ChecklistTutorialFragment newInstance(String param1, String param2) {
        ChecklistTutorialFragment fragment = new ChecklistTutorialFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        parent = view.findViewById(R.id.parent);
        pre = view.findViewById(R.id.btn_back);
        next = view.findViewById(R.id.btn_done);
        btnChooseShop = view.findViewById(R.id.btnChooseShop);
        btnChooseShop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startTutorial();
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextClicked();
            }
        });

        parent.addView(createCheckBoxView());

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                btnChooseShop.performClick();
            }
        },1000);

    }

    private void nextClicked() {
        parent.removeAllViews();
        RadioGroupMaker radioGroupMaker = createRadioButton();
        parent.addView(radioGroupMaker);
        startRadioButtonTutorial(radioGroupMaker);
    }

    private void startRadioButtonTutorial(RadioGroupMaker radioGroupMaker) {
        SimpleTarget first =
                new SimpleTarget.Builder(getActivity()).setPoint(radioGroupMaker)
                        .setRadius(100f)
                        .setTitle("RadioGroup")
                        .setDescription("This is single option question")
                        .build();
        Spotlight.with(getActivity())
                .setDuration(1L)
                .setAnimation(new DecelerateInterpolator(2f))
                .setTargets(first)
                .setOnSpotlightStartedListener(new OnSpotlightStartedListener() {
                    @Override
                    public void onStarted() {
//                        Toast.makeText(ActivityMain.this, "spotlight is started", Toast.LENGTH_SHORT)
//                                .show();
                    }
                })
                .setOnSpotlightEndedListener(new OnSpotlightEndedListener() {
                    @Override
                    public void onEnded() {
                        Toast.makeText(getActivity(), "now click next next to continue", Toast.LENGTH_SHORT).show();
                    }
                })
                .start();
    }

    private RadioGroupMaker createRadioButton() {
//
        try {
            RadioGroupMaker radioGroupMaker = new RadioGroupMaker(getActivity(),new JSONObject(Config.sampleRadioJson)
                    ,false,true,new JSONObject(),0,this);
            return radioGroupMaker;
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }

    private void startTutorial() {
        SimpleTarget first =
                new SimpleTarget.Builder(getActivity()).setPoint(btnChooseShop)
                        .setRadius(100f)
                        .setTitle("Progress")
                        .setDescription("Here you can see which is your progress when you start to do new survey")
                        .build();
        SimpleTarget second =
                new SimpleTarget.Builder(getActivity()).setPoint(checkBoxGroup)
                        .setRadius(600f)
                        .setTitle("Survey")
                        .setDescription("Here appears survey questions and each question has some parts")
                        .build();
        SimpleTarget third =
                new SimpleTarget.Builder(getActivity()).setPoint(checkboxTitle)
                        .setRadius(150f)
                        .setTitle("Title")
                        .setDescription("Here is title of question that what you want to answer")
                        .build();
        SimpleTarget forth =
                new SimpleTarget.Builder(getActivity()).setPoint(checkboxModel)
                        .setRadius(100f)
                        .setTitle("Guide")
                        .setDescription("This is model your selection that only appear in two question types")
                        .build();
        SimpleTarget fifth =
                new SimpleTarget.Builder(getActivity()).setPoint(checkBoxGroup)
                        .setRadius(300f)
                        .setTitle("Answers")
                        .setDescription("And here it is the answers , you can answer checkbox question by pressing on items ,Try it")
                        .build();

        Spotlight.with(getActivity())
                .setDuration(1L)
                .setAnimation(new DecelerateInterpolator(2f))
                .setTargets(first,second,third,forth,fifth)
                .setOnSpotlightStartedListener(new OnSpotlightStartedListener() {
                    @Override
                    public void onStarted() {
//                        Toast.makeText(ActivityMain.this, "spotlight is started", Toast.LENGTH_SHORT)
//                                .show();
                    }
                })
                .setOnSpotlightEndedListener(new OnSpotlightEndedListener() {
                    @Override
                    public void onEnded() {
//                        Toast.makeText(ActivityMain.this, "spotlight is ended", Toast.LENGTH_SHORT).show();
                    }
                })
                .start();
    }

    private View createCheckBoxView() {

        LinearLayout linearLayout = new LinearLayout(getContext());
//        try {
//            CheckListPager pager = new CheckListPager(getContext(), new JSONObject(Config.sampleSurveyJson)
//            ,pre,next,new ArrayList<PicturePickerItemModel>(), CheckListMaker.pageStatus.CHECKLIST
//            ,new JSONArray(),new ArrayList<ImageSliderModel>(),"",this,1,new ArrayList<LayoutModel>(),0
//            ,new ArrayList<ProductModel>(),"1","","");
//            return pager;
//        } catch (JSONException e) {
//            e.printStackTrace();
//            return null;
//        }

//        try {
//            checkBoxGroup = new CheckBoxGroup(getContext(), new JSONObject(Config.sampleCheckBoxJson)
//                    , true, new ArrayList<String>(), 0, this,this);
//            linearLayout.addView(checkBoxGroup);
//            this.checkboxTitle = checkBoxGroup.getTitle();
//            this.checkboxModel = checkBoxGroup.getGuidTxt();
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }

        return linearLayout;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_checklist_tutorial, container, false);
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void SaveAsDraft(JSONArray array, ArrayList<PicturePickerItemModel> pics, boolean isAppClosed, ArrayList<PicturePickerItemModel> signatures,ArrayList<String> errors) {

    }

    @Override
    public void SaveAsFinished(JSONArray array, ArrayList<PicturePickerItemModel> pics, ArrayList<PicturePickerItemModel> signatures,ArrayList<String> errors) {

    }

    @Override
    public void Finished() {

    }

    @Override
    public void onBackClicked() {

    }

    @Override
    public void CheckListHasError(String error) {

    }

    @Override
    public void closeChecklist() {

    }

    @Override
    public void StopFromSaving() {

    }

    @Override
    public void ChecklistErrorMessage(String msg) {

    }

    @Override
    public void instantSaveCall(JSONArray array, ArrayList<PicturePickerItemModel> pics, boolean isAppClosed, ArrayList<PicturePickerItemModel> signatures, int userPagePosition,ArrayList<String> errors) {

    }

    @Override
    public void CheckListMessage(String msg) {

    }

    @Override
    public void ImageSliderError(String err, ImagesViewer.ImageStatus errCode) {

    }

    @Override
    public void onPageChanged(int mode) {
        
    }

    @Override
    public void TimeTrackerStatus(boolean status) {

    }

    @Override
    public void onError(String error) {

    }

    @Override
    public void LogEvent(ArrayList<ModuleLogEvent> moduleLogEvents) {

    }

    @Override
    public void onShowChecklistLoad() {

    }

    @Override
    public void onHideCehcklistLoad() {

    }

    @Override
    public void showSavingLoad() {

    }



    private void startSecondTutorial() {
        SimpleTarget first =
                new SimpleTarget.Builder(getActivity()).setPoint(next)
                        .setRadius(100f)
                        .setTitle("Next button")
                        .setDescription("After you done with questions in page you can go to next page by clicking this (Be aware there can be qusetions below you need to scroll in each page)")
                        .build();

        SimpleTarget second =
                new SimpleTarget.Builder(getActivity()).setPoint(pre)
                        .setRadius(100f)
                        .setTitle("Back button")
                        .setDescription("You can get back to previous page with this button to edit")
                        .build();
        Spotlight.with(getActivity())
                .setDuration(1L)
                .setAnimation(new DecelerateInterpolator(2f))
                .setTargets(first,second)
                .setOnSpotlightStartedListener(new OnSpotlightStartedListener() {
                    @Override
                    public void onStarted() {
//                        Toast.makeText(ActivityMain.this, "spotlight is started", Toast.LENGTH_SHORT)
//                                .show();
                    }
                })
                .setOnSpotlightEndedListener(new OnSpotlightEndedListener() {
                    @Override
                    public void onEnded() {
                        Toast.makeText(getActivity(), "now click next next to continue", Toast.LENGTH_SHORT).show();
                    }
                })
                .start();
    }

    @Override
    public void onAction(String name,String id, String data, int pagePosition) {

    }

    @Override
    public void onConditionaryDataChanged(String s, String s1, boolean b, String s2) {

    }

    @Override
    public void isHiddenView() {

    }


    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onChecklistTutorialFinished();
    }
}
