package cl.bequarks.project.paraeco.UserChecklistAction.Model;

public interface IUserActionModel {

}
