package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter;

import org.json.JSONArray;

public interface IAccessoryPresenter{
    void AccessoryBtShop(int i);

    void Insert(JSONArray jSONArray);

    void getAccessories();

    void getAccessoriesByCondition(int i, int i2, int i3, int i4, int i5);

    void getAccessoryById(long j);


}
