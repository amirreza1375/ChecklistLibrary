package cl.bequarks.project.paraeco.Activity.ActivityDeleted;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.UserCheckList;
import cl.bequarks.project.paraeco.R;

public class DeletedItemsRecyclerAdapter extends RecyclerView.Adapter<DeletedItemsRecyclerAdapter.ViewHolder> {

    private Context context;
    private ArrayList<UserCheckList> items;
    private DeletedItemsActionListener listener;

    public DeletedItemsRecyclerAdapter(Context context, ArrayList<UserCheckList> items, DeletedItemsActionListener listener){

        this.context = context;
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(context).inflate(
                R.layout.layout_deleted_item
                ,viewGroup
                ,false
        ));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int i) {
        if (items.size() > i) {

            final UserCheckList item = items.get(i);

            holder.position = i;

            holder.isPicsSynced = item.isPicsSynced() == 1;

            holder.checkListNameTxt.setText(item.getCheckList_name());
            holder.shopName.setText(item.getShop_name());
            holder.timeTxt.setText(item.getTime());
            holder.dateTxt.setText(item.getDate());

            if (item.isDraft() == 0) {//finished
                if (item.isSynced() == 1 && item.isPicsSynced() == 1) {
                    holder.statusImg.setImageDrawable(context.getDrawable(R.drawable.ic_done_black_24dp));
                    holder.statusImg.setBackground(context.getDrawable(R.drawable.new_back_done));
                } else {
                    holder.statusImg.setImageResource(R.drawable.ic_error_outline_black_24dp);
                    holder.statusImg.setBackground(context.getDrawable(R.drawable.new_btn_back));
                }
            } else {
                holder.statusImg.setImageDrawable(context.getDrawable(R.drawable.ic_code_black_24dp));
                holder.statusImg.setBackground(context.getDrawable(R.drawable.new_login_btn));
            }

            holder.isDraft = item.isDraft() == 1;
            holder.isSynced = item.isSynced() == 1;
            holder.checklistJson = item.getCheckListJson();
            holder.answerJson = item.getAnswerJson();
            holder.checklistId = Long.parseLong(item.getCheckList_id());
            holder.checkListDataId = item.get_ID();
            holder.userCheckList = item;

        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView checkListNameTxt;
        public TextView shopName;
        public TextView dateTxt;
        public TextView timeTxt;
        public ImageView statusImg;

        public boolean isDraft;
        public boolean isSynced;
        public boolean isPicsSynced;
        public String checklistJson;
        public String answerJson;
        public long checklistId;
        public long checkListDataId;
        public String shopId;
        public String checkListName;
        public LinearLayout foreground;

        public int position;

        public UserCheckList userCheckList;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            checkListNameTxt = itemView.findViewById(R.id.check_list_name);
            shopName = itemView.findViewById(R.id.shop_name);
            dateTxt = itemView.findViewById(R.id.date);
            timeTxt = itemView.findViewById(R.id.time_txt);
            statusImg = itemView.findViewById(R.id.imgItem);
            foreground = itemView.findViewById(R.id.foreground);

        }
    }

    public void removeItem(int position) {
//        items.remove(position);
//        notifyItemRemoved(position);
        listener.onItemRemoved(items.get(position).get_ID());


    }

    public interface DeletedItemsActionListener{
        void onItemRemoved(long id);
    }

}
