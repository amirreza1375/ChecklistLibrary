package cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model;

import com.example.checklist.PictureElement.PicturePickerItemModel;

import java.util.ArrayList;

public interface IDBCheckListAndPicturesResultView<M> {

    void onSuccess(M result, ArrayList<PicturePickerItemModel> pics);

    void onFailed(String error);

}
