package cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.model;

public interface IDBSyncResultView<M> {

    void onSuccess(M result);

    void onFail(M result,String error);

}
