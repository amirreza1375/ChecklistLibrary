package cl.bequarks.project.paraeco.ServerRequests;

public interface OnlineListener {
    void isOnline(boolean isOnline);
}
