package cl.bequarks.project.paraeco.ServerRequests.RetrofitInterface;

import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;

/**
 * Created by shahr on 2/20/2019.
 */

public interface Upload {
    @Multipart
    @POST("/Api/uploadPic/")//Ba In Test Konid
    Call<SaveServer> getSavePic(
            @PartMap() Map<String, RequestBody> partMap
            ,@Part MultipartBody.Part file
    );



    @Multipart
    @POST("/api/uploadProfilePic/")//Ba In Test Konid
    Call<SaveServer> sendUserPic(
            @PartMap() Map<String, RequestBody> partMap
            ,@Part MultipartBody.Part file
    );
}
