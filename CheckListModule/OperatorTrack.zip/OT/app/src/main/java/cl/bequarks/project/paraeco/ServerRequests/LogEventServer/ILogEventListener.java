package cl.bequarks.project.paraeco.ServerRequests.LogEventServer;

import org.json.JSONArray;

public interface ILogEventListener {
    void onSent(JSONArray data);
    void onFailedToSend();
}
