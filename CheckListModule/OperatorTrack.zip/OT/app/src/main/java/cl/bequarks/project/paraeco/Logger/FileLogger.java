package cl.bequarks.project.paraeco.Logger;

import android.content.Context;
import android.os.Environment;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;

import static cl.bequarks.project.paraeco.sharedpreference.Config.APP_FOLDER_NAME;

public class FileLogger  {

    public static String LoggerFolderName = "Log.txt";

    public static void writeToFile(Context mcoContext, String sBody){
        File file = createFolder();
        if(!file.exists()){
            file.mkdir();
        }

        try{
            File gpxfile = new File(file, LoggerFolderName);
            FileWriter writer = new FileWriter(gpxfile);
            writer.append(sBody);
            writer.flush();
            writer.close();

            Toast.makeText(mcoContext, gpxfile.getAbsolutePath(), Toast.LENGTH_SHORT).show();

        }catch (Exception e){
            e.printStackTrace();
            Toast.makeText(mcoContext, e.getMessage(), Toast.LENGTH_SHORT).show();

        }
    }


    private static File createFolder() {
        String root = Environment.getExternalStorageDirectory().getAbsolutePath();
        String loggerFolder = root + APP_FOLDER_NAME ;
        return new File(loggerFolder);
    }

}
