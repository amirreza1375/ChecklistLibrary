package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Product;

public interface IProductView {
    void Products(ArrayList<Product> results);

    void noProduct();

    void noProductById();

    void ProductsById(ArrayList<Product> results);

    void ErrorInsertingProduct(String error);

    void ProductsInserted();

    void onItemInserted(String name);
}
