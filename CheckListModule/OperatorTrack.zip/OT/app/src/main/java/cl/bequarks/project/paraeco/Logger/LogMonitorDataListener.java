package cl.bequarks.project.paraeco.Logger;

import org.json.JSONArray;

public interface LogMonitorDataListener {
    void onDataRecieved(JSONArray data);
    void onDataEmpty();
}
