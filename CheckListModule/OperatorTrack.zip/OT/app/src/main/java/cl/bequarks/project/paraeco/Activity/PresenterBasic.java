package cl.bequarks.project.paraeco.Activity;

/**
 * Created by shahr on 1/25/2019.
 */

public class PresenterBasic<V , M> {

    protected V view;
    public void attachView(V view){
        this.view= view;
    }
    public void detachView(){
        this.view=null;
    }
    //
    protected M model;
    public void addModel(M model){
        this.model=model;
    }

}
