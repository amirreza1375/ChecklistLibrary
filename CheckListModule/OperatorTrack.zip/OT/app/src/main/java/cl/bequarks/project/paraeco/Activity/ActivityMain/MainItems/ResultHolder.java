package cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems;

import android.app.Activity;
import android.content.Context;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.checklist.ServerJsonGenerator.ServerJSONCleanUp;
import com.mikhaellopez.circularprogressbar.CircularProgressBar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.ResultPicture;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.UserCheckList;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Checklist;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.Logger.LogMonitor;
import cl.bequarks.project.paraeco.Logger.LogMonitorDataListener;
import cl.bequarks.project.paraeco.R;
import cl.bequarks.project.paraeco.ServerRequests.ApiService;
import cl.bequarks.project.paraeco.ServerRequests.IResponsePicture;
import cl.bequarks.project.paraeco.ServerRequests.ISendSurveyListener;
import cl.bequarks.project.paraeco.ServerRequests.NetWork.Connectivity;
import cl.bequarks.project.paraeco.ServerRequests.OnlineListener;

import static cl.bequarks.project.paraeco.sharedpreference.Config.getDate;
import static cl.bequarks.project.paraeco.sharedpreference.Config.getNetWorkType;
import static cl.bequarks.project.paraeco.sharedpreference.Config.getTime;

public class ResultHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener, ApiService.ApiAuthinticationFailListener {

    private static final String TAG = "ResultHolder";

    private TextView checkListNameTxt;
    private TextView shopName;
    private TextView dateTxt;
    private TextView timeTxt;
    private TextView resultIdTxt;
    private ImageView statusImg;
    public LinearLayout foreground;
    public LinearLayout resultIdHolder;
    private CircularProgressBar progressBar;
    private Context context;
    private ResultViewActionListener listener;
    private UserCheckList userCheckList;
    private TextView speedTxt;
    private Timer timer;
    private  LinearLayout ticketLabel;

    public ResultHolder(@NonNull View itemView, UserCheckList userCheckList, Context context, ResultViewActionListener listener) {
        super(itemView);
        this.userCheckList = userCheckList;
        checkListNameTxt = itemView.findViewById(R.id.check_list_name);
        shopName = itemView.findViewById(R.id.shop_name);
        dateTxt = itemView.findViewById(R.id.date);
        timeTxt = itemView.findViewById(R.id.time_txt);
        statusImg = itemView.findViewById(R.id.imgItem);
        foreground = itemView.findViewById(R.id.foreground);
        progressBar = itemView.findViewById(R.id.progress);
        speedTxt = itemView.findViewById(R.id.speedTxt);
        resultIdTxt = itemView.findViewById(R.id.resultIdTxt);
        resultIdHolder = itemView.findViewById(R.id.resultIdHolder);
        ticketLabel = itemView.findViewById(R.id.ticketLabel);
        this.context = context;
        this.listener = listener;

//        setImageStatus();
//        setData();
        setClickActions();

    }

    private void setClickActions() {
        itemView.setOnClickListener(this);
        statusImg.setOnClickListener(this);
        itemView.setOnLongClickListener(this);
    }

    public void setData() {
        checkListNameTxt.setText(userCheckList.getCheckList_name());
        shopName.setText(userCheckList.getShop_name());
        dateTxt.setText(userCheckList.getDate());
        timeTxt.setText(userCheckList.getTime());
    }

    public void setImageStatus(boolean isSyncUpdate) {
        Log.i(TAG, "setImageStatus: position = " + getAdapterPosition() + " ID = " + userCheckList.get_ID() + " -> isSynced = " + userCheckList.isSynced()
                + " -> isProccessing = " + userCheckList.isProccessing());
        if (userCheckList.getIsTicket() == 1){
            ticketLabel.setVisibility(View.VISIBLE);
        }else {
            ticketLabel.setVisibility(View.GONE);
        }
        if (userCheckList.isDraft() == 1) {
            statusImg.setImageDrawable(context.getDrawable(R.drawable.ic_code_black_24dp));
            statusImg.setBackground(context.getDrawable(R.drawable.new_login_btn));
            resultIdHolder.setVisibility(View.GONE);
        } else {
            if (userCheckList.isSynced() == 1 && userCheckList.isPicsSynced() == 1) {
                statusImg.setImageDrawable(context.getDrawable(R.drawable.ic_done_black_24dp));
                statusImg.setBackground(context.getDrawable(R.drawable.new_back_done));
                resultIdHolder.setVisibility(View.VISIBLE);
                int resId = (int) userCheckList.getServer_id();
                resultIdTxt.setText(resId+"");
            } else {
                resultIdHolder.setVisibility(View.GONE);
                if (userCheckList.isProccessing() == 0) {
                    statusImg.setImageDrawable(context.getDrawable(R.drawable.ic_autorenew_black_24dp));
                    statusImg.setBackground(context.getDrawable(R.drawable.new_btn_back));
                    if (isSyncUpdate)
                        sendSurvey();
                } else {
                    progressBar.setVisibility(View.VISIBLE);
//                speedTxt.setVisibility(View.VISIBLE);
                    statusImg.setVisibility(View.INVISIBLE);
                    sendSurvey();
                }
            }
        }
    }


    @Override
    public void onClick(View view) {
        if (view == itemView) {
            //open checklist
            if (userCheckList.isDraft() == 1 || userCheckList.isPicsSynced() == 1)
                listener.onItemClicked(userCheckList.isDraft() == 1, userCheckList.isSynced() == 1, Long.valueOf(userCheckList.getCheckList_id())
                        , userCheckList.get_ID(), userCheckList.getShop_id(), userCheckList.getShop_name(), userCheckList.getCheckList_name());
        }
        if (view == statusImg || view == progressBar) {
            //open sync
            if (isNetworkConnected()) {
                if (userCheckList.isDraft() == 0) {
                    if (userCheckList.isPicsSynced() == 0) {
                        sendSurvey();
                    }
                }
            }
        }
    }

    public String getLinkRate() {
        WifiManager wm = (WifiManager) G.context.getSystemService(Context.WIFI_SERVICE);
        WifiInfo wi = wm.getConnectionInfo();
        return String.format("%d Mbps", wi.getLinkSpeed());
    }

    private void networkSpeedLog() {
        ConnectivityManager cm = (ConnectivityManager) G.context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        //should check null because in airplane mode it will be null
        NetworkCapabilities nc = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
        }

        int downSpeed = nc.getLinkDownstreamBandwidthKbps();
        int upSpeed = nc.getLinkUpstreamBandwidthKbps();
        final int speed = upSpeed / 8;
        Activity activity = (Activity) context;
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                speedTxt.setText(speed + "");
            }
        });


        Log.i(TAG, "networkSpeedLog: download speed : " + downSpeed / (8 * 1024));
        Log.i(TAG, "networkSpeedLog: upload speed " + upSpeed / (8 * 1024));
    }

    @Override
    public boolean onLongClick(View view) {
        if (view == itemView) {
            if (userCheckList.isDraft() == 0 && !isPicsInProccess()) {
                int serverId = (int) userCheckList.getServer_id();
                listener.onItemLongCicked("ID = " + serverId, userCheckList.get_ID(), getPosition(), ResultHolder.this);
            }
        }
        return true;
    }

    private int getResultPicturesCountWithResultId(long id) {
        int count = getItemPicturesByCheckListDataId(id).size();
        return count;
    }

    //region sync process

    private void sendSurvey() {


        if (isNetworkConnected()) {

            progressBar.setIndeterminateMode(true);

            isOnline(new OnlineListener() {
                @Override
                public void isOnline(boolean isOnline) {
                    if (isOnline) {

                        final int resultProgress = getResultProgress(userCheckList.get_ID());

                        if (userCheckList.isSynced() == 0) {

                            if (userCheckList.isProccessing() == 0) {
                                userCheckList.setProccessing(1);
                                userCheckList.update(userCheckList);
                                startSync();


                                LogMonitor logMonitor = new LogMonitor().fetchByCheckListDBID(userCheckList.get_ID());

                                if (logMonitor.getId() <= 0) {

                                    logMonitor = new LogMonitor(0, userCheckList.get_ID(), "0", getDate(), getTime()
                                            , getQuestionCount(userCheckList.getCheckList_id())
                                            , 0
                                            , getResultPicturesCountWithResultId(userCheckList.get_ID())
                                            , 0, "", getNetWorkType(), 0, "0"
                                            , userCheckList.getShop_id()
                                            , userCheckList.getCheckList_id(), userCheckList.getShop_name()
                                            , userCheckList.getUserEmail(), userCheckList.getCheckList_name(), 0);
                                }

                                final long startTime = System.currentTimeMillis();
                                logMonitor.setIsSynced(0);
                                logMonitor.setNET(getNetWorkType());

                                final LogMonitor finalLogMonitor = logMonitor;
                                new ApiService(ResultHolder.this).sendSurvey(userCheckList.getShop_id()
                                        , userCheckList.getCheckList_id()
                                        , userCheckList.getStart_time()
                                        , userCheckList.getEnd_time()
                                        , userCheckList.getAnswerJson()
                                        , getItemPicturesByCheckListDataIdStr(userCheckList.get_ID())
                                        , new ISendSurveyListener() {
                                            @Override
                                            public void onFailed(String error) {
                                                long endTime = System.currentTimeMillis();
                                                double remain = (endTime - startTime) / 1000;
                                                Log.i(TAG, "result failed to send ");
                                                finalLogMonitor.setUploadTime(remain + "");
                                                finalLogMonitor.setStatus(finalLogMonitor.getStatus() + " \n " + error + " " + getTime());
                                                finalLogMonitor.Insert();
                                                itemNotSynced(progressBar, statusImg, userCheckList, getPosition(), error);
                                            }

                                            @Override
                                            public void onSurveySent(double serverId) {
                                                long endTime = System.currentTimeMillis();
                                                Log.i(TAG, "onSurveySent: resutl sent");
                                                userCheckList.setSynced(1);
                                                userCheckList.setProccessing(0);
                                                userCheckList.setServer_id(serverId);
                                                userCheckList.update(userCheckList);
                                                progressBar.setIndeterminateMode(false);
                                                progressBar.setProgress(resultProgress);
                                                double remain = (endTime - startTime) / 1000;
                                                finalLogMonitor.setAnswerCount(new ServerJSONCleanUp(userCheckList.getAnswerJson()).cleanUpJSON().length());
                                                finalLogMonitor.setUploadTime(remain + "");
                                                finalLogMonitor.setStatus(finalLogMonitor.getStatus() + " \n " + "Result Sent" + " " + getTime());
                                                finalLogMonitor.setResultID(serverId + "");
                                                finalLogMonitor.Insert();
                                                Log.i(TAG, "progress : " + resultProgress + " % ");
//                                sendSignatures(userCheckList, serverId, itemImage, position);
                                                sendPictures(serverId + "", resultProgress);
                                            }
                                        });
                            } else {
                                Log.i(TAG, "sendSurvey: items is proccessing");
//                    itemInProccessStartTimeOut(userCheckList, progressBar, itemImage, holder, position);
                            }
                        } else {//checklist synced so send pictures now
                            progressBar.setIndeterminateMode(false);
                            progressBar.setProgress(resultProgress);
                            sendPictures(userCheckList.getServer_id() + "", resultProgress);
                        }

                    } else {
                        Toast.makeText(context, G.context.getString(R.string.no_internet), Toast.LENGTH_SHORT).show();
                        itemNotSynced(progressBar, statusImg, userCheckList, getPosition(), context.getString(R.string.noConnectio));
                    }
                }
            });


        } else {
            itemNotSynced(progressBar, statusImg, userCheckList, getPosition(), context.getString(R.string.no_network));
        }
    }

    private int getQuestionCount(String checkList_id) {
        try {
            long checklistId = Long.parseLong(checkList_id);
            Checklist checklist = new Checklist().getByCheckListId(checklistId);
            JSONObject chceklistJson = checklist.getJOSN();
            JSONArray pages = chceklistJson.getJSONArray("pages");
            int questoinCount = 0;

            for (int i = 0; i < pages.length(); i++) {

                JSONObject page = pages.getJSONObject(i);

                JSONArray elements = page.getJSONArray("elements");

                questoinCount += elements.length();

            }

            return questoinCount;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }

    }

    private void startTimeer() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                networkSpeedLog();
            }
        }, 10, 10);
    }

    private int getResultProgress(long id) {
        int imageCount = getItemPicturesByCheckListDataId(id).size();
        return 100 / (imageCount + 1);
    }

    private void sendPictures(String serverId, float preProgressValue) {

        startSync();

        if (!isPicsInProccess() && userCheckList.isPicsSynced() == 0) {

            final LogMonitor logMonitor = new LogMonitor().fetchByCheckListDBID(userCheckList.get_ID());
            logMonitor.setNET(getNetWorkType());

            progressBar.setIndeterminateMode(false);

            logMonitor.setIsSynced(0);

            Log.i(TAG, "sendPictures: pictures proccess began");

            final float[] preProgress = {preProgressValue};
            int picCount = getItemPicturesByCheckListDataId(userCheckList.get_ID()).size();
            final float EP = (100 - preProgress[0]) / picCount;

            final long startTime = System.currentTimeMillis();

            logMonitor.setNET(getNetWorkType());

            new ApiService(this).sendPictures(getItemPicturesByCheckListDataId(userCheckList.get_ID())
                    , serverId
                    , userCheckList.get_ID()
                    , new IResponsePicture() {
                        @Override
                        public void NoPictures() {
                            long endTime = System.currentTimeMillis();
                            double remain = (endTime - startTime) / 1000;
                            double preUploadTime = Double.parseDouble(logMonitor.getUploadTime());
                            logMonitor.setUploadTime((remain + preUploadTime) + "");
                            Log.i(TAG, "NoPictures: ");
                            logMonitor.setStatus(logMonitor.getStatus() + " \n No image" + " " + getTime());
                            logMonitor.Insert();
                            itemSynced();
                        }

                        @Override
                        public void PicturesSynced() {
                            long endTime = System.currentTimeMillis();
                            double remain = (endTime - startTime) / 1000;
                            double preUploadTime = Double.parseDouble(logMonitor.getUploadTime());
                            double allTime = preUploadTime + remain;
                            logMonitor.setNET(getNetWorkType());
                            logMonitor.setUploadTime(allTime + "");
                            Log.i(TAG, "PicturesSynced: " + getTime());
                            logMonitor.setStatus(logMonitor.getStatus() + " \n Images synced" + " " + getTime());
                            logMonitor.Insert();
                            itemSynced();
                        }

                        @Override
                        public void FailedToSync(String error) {
                            long endTime = System.currentTimeMillis();
                            double remain = (endTime - startTime) / 1000;
                            double preUploadTime = Double.parseDouble(logMonitor.getUploadTime());
                            logMonitor.setUploadTime((remain + preUploadTime) + "");
                            Log.i(TAG, "FailedToSync: ");
                            logMonitor.setStatus(logMonitor.getStatus() + " \n " + error + " " + getTime());
                            logMonitor.Insert();
                            itemPicturesNotSynced(progressBar, statusImg, userCheckList, error);
                        }

                        @Override
                        public void onPictureSynced(int toatal, int synced) {
                            logMonitor.setUploadedPictures(synced - 1);
                            logMonitor.Insert();
//                            progressBar.setProgress(((100-preProgress[0]) * synced) / toatal);
                            progressBar.setIndeterminateMode(false);
                            preProgress[0] = progressBar.getProgress();
//                            Log.i(TAG, "progress : " + ((100 - preProgress[0]) * synced) / toatal + " % ");

                        }

                        @Override
                        public void message(String msg) {

                        }

                        @Override
                        public void imageUploadProgress(int progress) {
                            progressBar.setProgress(getPictureUploadProgress(preProgress[0], progress, EP));
                        }
                    });
        } else {
            Log.i(TAG, "sendPictures: pictures in proccess");
        }

    }

    private int getPictureUploadProgress(float preProgress, float progress, float EP) {
        int x = ((int) EP * (int) progress) / 100;
        int prgrss = ((int) preProgress) + x;
//        Log.i(TAG, "getPictureUploadProgress: " + prgrss);
        return prgrss;
    }


    //endregion

    private void startSync() {
        Activity activity = (Activity) context;
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Log.i(TAG, "changed image : " + userCheckList.get_ID());
                progressBar.setVisibility(View.VISIBLE);
//                speedTxt.setVisibility(View.VISIBLE);
                statusImg.setVisibility(View.INVISIBLE);
            }
        });

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
//                RotateAnimation syncAnimation = new RotateAnimation(ROTATE_FROM, ROTATE_TO,
//                        Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
//                syncAnimation.setDuration(1000 * 5);
//                syncAnimation.setRepeatCount(Animation.INFINITE);
//                syncAnimation.setRepeatMode(Animation.INFINITE);
//
//                itemImage.startAnimation(syncAnimation);

                userCheckList.setProccessing(1);
                userCheckList.update(userCheckList);
            }
        }, 1);

    }

    // ICMP
    private void isOnline(final OnlineListener callBack) {
        NetworkInfo info = Connectivity.getNetworkInfo(G.context);
        boolean isFast = Connectivity.isConnectionFast(info.getType(),info.getSubtype());
        callBack.isOnline(isFast);
    }
//        new Handler(Looper.getMainLooper()).post(new Runnable() {
//            @Override
//            public void run() {
//
//                NetworkInfo info = Connectivity.getNetworkInfo(G.context);
//                if (Connectivity.isConnectionFast(info.getType(), info.getSubtype()))
//                    callBack.isOnline(true);
//
//                Runtime runtime = Runtime.getRuntime();
//                try {
//                    Process ipProcess = runtime.exec("/system/bin/ping -c 1 8.8.8.8");
//                    int exitValue = ipProcess.waitFor();
//                    callBack.isOnline(exitValue == 0);
//                } catch (IOException e) {
//                    e.printStackTrace();
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//
//                callBack.isOnline(true);
//            }
//        });
//
//    }

    private void itemNotSynced(final CircularProgressBar progressBar, final ImageView img, UserCheckList userCheckList, int position, String error) {
//        if (timer != null)
//            timer.cancel();

        new LogMonitor().getAllInJSONArray(new LogMonitorDataListener() {
            @Override
            public void onDataRecieved(JSONArray data) {
                Log.i(TAG, "onDataRecieved: " + data);
                new ApiService(ResultHolder.this).sendLogMonitor(data);
            }

            @Override
            public void onDataEmpty() {

            }
        });
        Activity activity = (Activity) context;
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                progressBar.setVisibility(View.INVISIBLE);
//                speedTxt.setVisibility(View.INVISIBLE);
                img.setVisibility(View.VISIBLE);
                img.clearAnimation();
                statusImg.setImageDrawable(context.getDrawable(R.drawable.ic_autorenew_black_24dp));
                statusImg.setBackground(context.getDrawable(R.drawable.new_btn_back));
            }
        });

        MediaPlayer mediaPlayer = MediaPlayer.create(G.context, R.raw.error);
        mediaPlayer.setVolume(0.08f, 0.08f);
        mediaPlayer.start();

        if (isHostNotFound(error))
            Toast.makeText(activity, G.context.getString(R.string.noConnectio), Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(activity, error, Toast.LENGTH_SHORT).show();

        if (userCheckList != null) {
            userCheckList.setProccessing(0);
            userCheckList.setSynced(0);
            userCheckList.setPicsSynced(0);
            userCheckList.update(userCheckList);
        }
    }

    private boolean isHostNotFound(String err) {
        if (err != null) {
            if (err.length() != 0) {
                String[] errorArray = err.split(":");
                if (errorArray.length > 0) {
                    String errTrimLowerCase = errorArray[0].toLowerCase();
                    String defErr = "java.net.UnknownHostException".toLowerCase();
                    if (defErr.equals(errTrimLowerCase)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }


    private void itemPicturesNotSynced(final CircularProgressBar progressBar, final ImageView itemImage, UserCheckList userCheckList, final String error) {
        new LogMonitor().getAllInJSONArray(new LogMonitorDataListener() {
            @Override
            public void onDataRecieved(JSONArray data) {
                Log.i(TAG, "onDataRecieved: " + data);
                new ApiService(ResultHolder.this).sendLogMonitor(data);
            }

            @Override
            public void onDataEmpty() {

            }
        });
//        if (timer != null)
//            timer.cancel();
        final Activity activity = (Activity) context;
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                progressBar.setVisibility(View.INVISIBLE);
//                speedTxt.setVisibility(View.INVISIBLE);
                itemImage.setVisibility(View.VISIBLE);
                itemImage.clearAnimation();
                statusImg.setImageDrawable(context.getDrawable(R.drawable.ic_autorenew_black_24dp));
                statusImg.setBackground(context.getDrawable(R.drawable.new_btn_back));
                if (isHostNotFound(error))
                    Toast.makeText(activity, G.context.getString(R.string.noConnectio), Toast.LENGTH_SHORT).show();
            }
        });
        MediaPlayer mediaPlayer = MediaPlayer.create(G.context, R.raw.error);
        mediaPlayer.setVolume(0.08f, 0.08f);
        mediaPlayer.start();

        if (userCheckList != null) {
            userCheckList.setProccessing(0);
            userCheckList.setPicsSynced(0);
            userCheckList.update(userCheckList);
        }
    }

    private void itemSynced() {
        new LogMonitor().getAllInJSONArray(new LogMonitorDataListener() {
            @Override
            public void onDataRecieved(JSONArray data) {
                Log.i(TAG, "onDataRecieved: " + data);
                new ApiService(ResultHolder.this).sendLogMonitor(data);
            }

            @Override
            public void onDataEmpty() {

            }
        });
        final Activity activity = (Activity) context;
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                statusImg.clearAnimation();
                statusImg.setImageDrawable(context.getDrawable(R.drawable.ic_done_black_24dp));
                statusImg.setBackground(context.getDrawable(R.drawable.new_back_done));
                resultIdHolder.setVisibility(View.VISIBLE);
                int resId = (int) userCheckList.getServer_id();
                resultIdTxt.setText(resId+"");
            }
        });

        new Thread(new Runnable() {
            @Override
            public void run() {
//
                MediaPlayer mediaPlayer = MediaPlayer.create(G.context, R.raw.tik);
                mediaPlayer.setVolume(0.08f, 0.08f);
                mediaPlayer.start();
            }
        }).start();

        if (userCheckList != null) {
            userCheckList.setProccessing(0);
            userCheckList.setSynced(1);
            userCheckList.setPicsSynced(1);
            userCheckList.update(userCheckList);
        }


        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                progressBar.setVisibility(View.INVISIBLE);
                statusImg.setVisibility(View.VISIBLE);
                statusImg.setImageDrawable(context.getDrawable(R.drawable.ic_done_black_24dp));
                statusImg.setBackground(context.getDrawable(R.drawable.new_back_done));
                statusImg.clearAnimation();
            }
        });
        listener.updateRow(getPosition(), userCheckList.get_ID());

    }

    private boolean isPicsInProccess() {
        ArrayList<ResultPicture> pictures = getItemPicturesByCheckListDataId(userCheckList.get_ID());

        for (ResultPicture picture : pictures) {
            if (picture.isProccessing() == 1 && picture.isSynced() == 0) {
//                setTimeOutForPicture(picture, progressBar, serverId, itemImage, userCheckList, position, holder);
                return true;
            }
        }
        return false;

    }

    private JSONArray converPictureModelsToJSONArray(ArrayList<ResultPicture> resultPictures) {

        JSONArray pics = new JSONArray();

        for (ResultPicture resultPicture : resultPictures) {

            JSONObject pic = new JSONObject();

            try {
                pic.put("type", "file");
                pic.put("id", resultPicture.getQuestion_id());
                pic.put("name", resultPicture.getName());
                pic.put("imagetype", resultPicture.getImage_type());

                pics.put(pic);

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

        return pics;

    }

    private ArrayList<ResultPicture> getItemPicturesByCheckListDataId(Long id) {

        ArrayList<ResultPicture> temp = new ArrayList<>();

        List<ResultPicture> resultPictures = new ResultPicture().getAllItems();

        for (ResultPicture resultPicture : resultPictures) {

            if (resultPicture.getCheckListDataBaseId() == id) {
                temp.add(resultPicture);
            }

        }

        return temp;
    }


    private String getItemPicturesByCheckListDataIdStr(Long id) {
        return converPictureModelsToJSONArray(getItemPicturesByCheckListDataId(id)).toString();
    }

    private boolean isNetworkConnected() {
        boolean isConnected = false;
        ConnectivityManager conMgr = (ConnectivityManager) G.context.getSystemService(Context.CONNECTIVITY_SERVICE);


        if (conMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED
                || conMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
            isConnected = true;

        } else if (conMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.DISCONNECTED
                || conMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.DISCONNECTED) {
            isConnected = false;

        }
        return isConnected;
    }


    @Override
    public void onAtuhinticationFailed() {

    }

    public void setUserCheckList(UserCheckList userCheckList) {
        this.userCheckList = userCheckList;
    }

    public void resend(UserCheckList userCheckList) {
        this.userCheckList = userCheckList;
        sendSurvey();
    }
}
