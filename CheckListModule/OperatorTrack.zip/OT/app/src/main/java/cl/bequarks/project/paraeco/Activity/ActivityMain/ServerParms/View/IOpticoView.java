package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View;



import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Optico;

import java.util.List;

public interface IOpticoView   {
    void OpticoById(Optico optico);

    void OpticoIserted(boolean status);

    void Opticos(List<Optico> list);

    void OpticosByCondition(List<Optico> list);

    void OpticosByShop(List<Optico> list);

    void onItemInserted(String name);
}
