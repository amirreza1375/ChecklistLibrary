package cl.bequarks.project.paraeco.sharedpreference;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import com.microsoft.appcenter.analytics.Analytics;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import cl.bequarks.project.paraeco.EvenLogger.LogEvent;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.R;
import cl.bequarks.project.paraeco.ServerRequests.NetWork.Connectivity;

import static android.content.Context.MODE_PRIVATE;

public class Config {

    private static final String TAG = "Config";

    //database


    public static boolean isMultipleAppEnabled = false;
    public static final String APP_FOLDER_NAME = "HR - PA AECO";
    public static final String APP_NAME = "Human Resources \n Parque Arauco AECO";
    public static final String APP_FOLDER_OPTICO = "Optico";
    public static final String APP_FOLDER_ACCESSORY = "Accessory";
    public static final String APP_FOLDER_LAYOUT = "Layout";
    public static final String APP_FOLDER_PRICTURES = "Pictures";
    public static final String APP_FOLDER_PROFILE = "Profile";
    public static final String APP_FOLDER_SIGNATURES = "Signatures";

    public static final String SIGNATURE_DIRECTORY = Environment.getExternalStorageDirectory()
            + File.separator
            + APP_FOLDER_NAME
            + File.separator
            + APP_FOLDER_SIGNATURES;

    public static String USER_AGGENT = "USERAGGENT";

    public static final String sharedPreferencName = "shared";
    public static String UserLog = "UserLog";
    public static String email = "userEmail";
    //    public static String userId = "userId";
    public static String pic = "UserPic";
    public static String tokken = "tokken";
    public static String name = "name";
    public static String userId = "userid";
    public static String dataBAseInfoAdded = "database";
    public static String updatingData = "updatingdata";
    public static String version = "version";
    public static String pictures = "pictures";
    public static String data_base_handle = "database_first_time";
    public static String isFirstTime = "isFirstTime";
    public static String OneAPP = "OneAPP";
    public static String loged_out_user = "";
    public static String img_path = "image";
    public static String color_primary = "color_primary";
    public static String color_accent = "color_accent";
    public static String permission_status = "PERMISSIONS";
    public static String saveByNotifId = "savedByNotifId";
    public static String conf_devMode = "devMode";
    public static String appVersion = "appVersion";


    public static String sampleSurveyJson = "{\"title\":\"Sample Survey\",\"pages\":[{\"name\":\"p\\u00e1gina1\",\"elements\":[{\"type\":\"checkbox\",\"name\":\"pregunta1\",\"id\":\"Qll93R1\",\"title\":\"CheckBox\",\"choices\":[{\"value\":\"1\",\"text\":\"Page 2\"},{\"value\":\"2\",\"text\":\"Page 3\"},{\"value\":\"3\",\"text\":\"Page 4\"}]},{\"type\":\"file\",\"name\":\"pregunta2\",\"id\":\"QuoqQlN\",\"title\":\"FOTO\",\"showPreview\":true,\"imageHeight\":250,\"imageWidth\":414,\"waitForUpload\":true,\"maxSize\":0,\"Documentos\":true,\"imagetype\":\"1\",\"imagetypeName\":\"Documentos\"}]},{\"name\":\"p\\u00e1gina2\",\"elements\":[{\"type\":\"radiogroup\",\"name\":\"pregunta3\",\"id\":\"QxD13ho\",\"title\":\"RadioButton\",\"choices\":[{\"value\":\"1\",\"text\":\"Visible\"},{\"value\":\"2\",\"text\":\"InVisible\"}]},{\"type\":\"comment\",\"name\":\"pregunta4\",\"visibleIf\":\"{pregunta3} contains \\\"1\\\"\",\"id\":\"QuGXYHL\",\"title\":\"Comment\",\"maxLength\":9999}],\"visibleIf\":\"{pregunta1} contains \\\"1\\\"\"},{\"name\":\"p\\u00e1gina3\",\"elements\":[{\"type\":\"multipletext\",\"name\":\"pregunta5\",\"id\":\"QWuySPP\",\"title\":\"MultipleText\",\"items\":[{\"name\":\"text1\",\"title\":\"Text1\"},{\"name\":\"text2\",\"title\":\"Text2\"},{\"name\":\"text3\",\"title\":\"Text3\"}]}],\"visibleIf\":\"{pregunta1} contains \\\"1\\\"\"},{\"name\":\"p\\u00e1gina4\",\"elements\":[{\"type\":\"nouislider\",\"name\":\"pregunta7\",\"id\":\"QIOZytE\",\"title\":\"Control Deslizante\"},{\"type\":\"imagepicker\",\"name\":\"pregunta6\",\"id\":\"Qx6o1eV\",\"title\":\"Opcion Unica Imagen\",\"choices\":[{\"value\":\"1\",\"text\":\"Texto\"}]},{\"type\":\"signaturepad\",\"name\":\"pregunta8\",\"id\":\"QWiVTBC\",\"title\":\"Frima\"}],\"visibleIf\":\"{pregunta1} contains \\\"3\\\"\"}]}";
    public static String sampleCheckBoxJson = "{\n" +
            "          \"type\": \"checkbox\",\n" +
            "          \"name\": \"pregunta1\",\n" +
            "          \"id\": \"Qll93R1\",\n" +
            "          \"title\": \"CheckBox\",\n" +
            "          \"choices\": [\n" +
            "            {\n" +
            "              \"value\": \"1\",\n" +
            "              \"text\": \"Page 2\"\n" +
            "            },\n" +
            "            {\n" +
            "              \"value\": \"2\",\n" +
            "              \"text\": \"Page 3\"\n" +
            "            },\n" +
            "            {\n" +
            "              \"value\": \"3\",\n" +
            "              \"text\": \"Page 4\"\n" +
            "            }\n" +
            "          ]\n" +
            "        }";
    public static String sampleRadioJson = "{\n" +
            "          \"type\": \"radiogroup\",\n" +
            "          \"name\": \"pregunta3\",\n" +
            "          \"id\": \"QxD13ho\",\n" +
            "          \"title\": \"RadioButton\",\n" +
            "          \"choices\": [\n" +
            "            {\n" +
            "              \"value\": \"1\",\n" +
            "              \"text\": \"Visible\"\n" +
            "            },\n" +
            "            {\n" +
            "              \"value\": \"2\",\n" +
            "              \"text\": \"InVisible\"\n" +
            "            }\n" +
            "          ]\n" +
            "        }";
    public static String sampleCameraJson = "{\n" +
            "          \"type\": \"file\",\n" +
            "          \"name\": \"pregunta2\",\n" +
            "          \"id\": \"QuoqQlN\",\n" +
            "          \"title\": \"FOTO\",\n" +
            "          \"showPreview\": true,\n" +
            "          \"imageHeight\": 250,\n" +
            "          \"imageWidth\": 414,\n" +
            "          \"waitForUpload\": true,\n" +
            "          \"maxSize\": 0,\n" +
            "          \"Documentos\": true,\n" +
            "          \"Cuantos-Type 1\":3,\n" +
            "          \"Cuantos-Type 2\":4,\n" +
            "          \"Cuantos-Type 3\":5,\n" +
            "          \"imagetype\": \"1,2,3\",\n" +
            "          \"imagetypeName\": \"Type 1,Type 2,Type3\"\n" +
            "        }";

    //this method returns the last app version that sent to server
    public static String getAppVersion(Context context) {
        String version = context.getSharedPreferences(Config.sharedPreferencName, MODE_PRIVATE)
                .getString(appVersion, "");
        return version;
    }



    //this method changes the app version that sent to server
    public static void setAppVersion(Context context) {
        String app_version = "";
        try {
            app_version = context.getPackageManager().getPackageInfo(G.context.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        SharedPreferences.Editor editor = context.getSharedPreferences(Config.sharedPreferencName, MODE_PRIVATE).edit();
        editor.putString(appVersion, app_version).apply();
    }

    //this method checks if the app version is changed or not
    public static boolean isVersionChanged(Context context) {

//        String oldVersion = getAppVersion(context);
//        if (oldVersion.equals(""))
//            return true;
//
//        String currentVersion = "";
//        try {
//            currentVersion = context.getPackageManager().getPackageInfo(G.context.getPackageName(), 0).versionName;
//        } catch (PackageManager.NameNotFoundException e) {
//            e.printStackTrace();
//        }
//
//        if (oldVersion.equals(currentVersion))
//            return false;
        return true;

    }




    public static String getDate() {
        Date today = Calendar.getInstance().getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

        String date = dateFormat.format(today).replace("/", "-");
        return date;
    }

    public static String getTime() {
        Date now = new Date();
        SimpleDateFormat sdfDatee = new SimpleDateFormat("HH:mm");//dd/MM/yyyy
        String time = sdfDatee.format(now);
        return time;
    }

    public static String getUser(Context context) {
        String user = context.getSharedPreferences(Config.sharedPreferencName, MODE_PRIVATE)
                .getString(Config.email, "");
        return user;
    }

    public static String getUserId(Context context) {
        String user = context.getSharedPreferences(Config.sharedPreferencName, MODE_PRIVATE)
                .getString(Config.userId, "");
        return user;
    }

    public static void appCenterErrorLog(String error){
        HashMap<String , String> params = new HashMap<>();
        params.put("Date",getDate());
        params.put("Time",getTime());
        params.put("Version app",getAppVersion(G.context));
        params.put("Version server",G.context.getSharedPreferences(Config.sharedPreferencName,MODE_PRIVATE).getString(Config.version,"No version"));
        params.put("Eerror",error);
        Analytics.trackEvent(getUser(G.context)+"-"+getDate()+"-"+getTime(),params);
    }

    public static void appCenterLog(String name , HashMap<String,String> params){
        params.put("Date",getDate());
        params.put("Time",getTime());
        params.put("Version app",getAppVersion(G.context));
        params.put("Version server",G.context.getSharedPreferences(Config.sharedPreferencName,MODE_PRIVATE).getString(Config.version,"No version"));
        Analytics.trackEvent(name+getAppVersion(G.context),params);
    }


    public static String getServer(Context context) {
        String server = context.getString(R.string.disneyServer);
        return server;
    }

    public static String getSupportNumber(Context context) {
        String support = context.getString(R.string.support_link);
        return support;
    }

    public static int getDevMode(Context context) {
        int devMode = context.getSharedPreferences(sharedPreferencName, MODE_PRIVATE)
                .getInt(conf_devMode, 0);
        return devMode;
    }

    public static String getNetWorkType() {

        if (!Connectivity.isConnected(G.context))
            return "Not connected";
        NetworkInfo info = Connectivity.getNetworkInfo(G.context);
        return Connectivity.getNetWorkNameAndSpeed(info.getType(),info.getSubtype());

    }

    public static void removeFolderEntries(String folder) {
        File dir = new File(Environment.getExternalStorageDirectory() + "/"
                + APP_FOLDER_NAME + "/" + folder);
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                new File(dir, children[i]).delete();
            }
        }
    }


    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static String getTokken(){
        return G.context.getSharedPreferences(sharedPreferencName,MODE_PRIVATE).getString(tokken,"No token");
    }

    public static boolean isMockLocationOn(Context context){
        return !Settings.Secure.getString(context.getContentResolver(),
                Settings.Secure.ALLOW_MOCK_LOCATION).equals("0");
    }



    public static void sendDataLog(String newVersion
    ,String serverData,String checklistJson,String eventName,String answerJson,String syncData){

        if (newVersion.equals(""))
            newVersion = getServerVersion(G.context);

        LogEvent logEvent = new LogEvent(getAppVersion(G.context)
        ,getTokken()
        ,getUserId(G.context) +" -"+ getUser(G.context)
        ,getNetWorkType()
        ,getDate()
        ,getTime()
        ,getphoneModel()
        ,getServerVersion(G.context)
        ,newVersion
        ,serverData
        ,checklistJson
        ,eventName
        ,answerJson
        ,syncData
        ,0);
        logEvent.insert(logEvent);
    }

    public static void sendDataLog(String serverData,String eventName){

        LogEvent logEvent = new LogEvent(getAppVersion(G.context)
                ,getTokken()
                ,getUserId(G.context) +" -"+ getUser(G.context)
                ,getNetWorkType()
                ,getDate()
                ,getTime()
                ,getphoneModel()
                ,getServerVersion(G.context)
                ,""
                ,serverData
                ,""
                ,eventName
                ,""
                ,""
                ,0);
        logEvent.insert(logEvent);
    }


    public static void sendEventLog(String eventName){

//
        LogEvent logEvent = new LogEvent(getAppVersion(G.context)
                ,getTokken()
                ,getUserId(G.context) +" -"+ getUser(G.context)
                ,getNetWorkType()
                ,getDate()
                ,getTime()
                ,getphoneModel()
                ,getServerVersion(G.context)
                ,""
                ,""
                ,""
                ,eventName
                ,""
                ,""
                ,0);
        logEvent.insert(logEvent);
    }

    public static String getphoneModel() {
        return Build.MODEL;
    }

    public static String getServerVersion(Context context) {
        return G.context.getSharedPreferences(sharedPreferencName,MODE_PRIVATE).getString(version,"No version");
    }

    public static class Params{
        public static final String SHOP = "shop";
        public static final String CHECKLIST = "checklist";
        public static final String CATEGORY = "category";
        public static final String OPTICO = "optico";
        public static final String ACCESSORY = "accessory";
        public static final String LAYOUT = "layout";
        public static final String PRODUCT = "product";

    }

    public static void recycleBitmap(Bitmap bitmap){
        if (bitmap != null){
            if (bitmap.isRecycled()){
                bitmap.recycle();
            }
        }
    }
}
