package cl.bequarks.project.paraeco.Activity.ActivityForgetPassword.Presenter;

import cl.bequarks.project.paraeco.Activity.ActivityForgetPassword.Model.ForgetPassword;
import cl.bequarks.project.paraeco.Activity.ActivityForgetPassword.View.IForgetPasswordView;
import cl.bequarks.project.paraeco.Activity.ActivityLogin.Model.User;
import cl.bequarks.project.paraeco.Activity.PresenterBasic;
import cl.bequarks.project.paraeco.ServerRequests.IResponseApiToModel2;


public class ForgetPasswordPresenter extends PresenterBasic<IForgetPasswordView,ForgetPassword>
        implements IForgetPasswordPresenter {

    @Override
    public void checkValidation(String email) {

        if(User.isValidEmailId(email)){
            view.OnValidEmail();
        }else{
            view.OnInvalidEmail();
        }
    }

    @Override
    public void sendForgetPasswordEmail(String email, String devid) {

        ForgetPassword forgetPassword = new ForgetPassword(email,devid);
        forgetPassword.sendForgetPasswordRequest(new IResponseApiToModel2<String>() {
            @Override
            public void onFail(String error) {
                view.OnRequestFailed(error);
            }

            @Override
            public  void onSuccess(String answer){
                view.OnRequestSuccess(answer.toString());
            }

            @Override
            public void onEmptyList(String message) {}
        });
    }

}
