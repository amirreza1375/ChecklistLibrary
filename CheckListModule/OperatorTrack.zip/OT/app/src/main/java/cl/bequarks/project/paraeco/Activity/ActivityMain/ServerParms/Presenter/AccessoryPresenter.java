package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Accessory;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IAccessoryView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBResultView;
import cl.bequarks.project.paraeco.Activity.PresenterBasic;
import cl.bequarks.project.paraeco.sharedpreference.Config;

import org.json.JSONArray;

public class AccessoryPresenter extends PresenterBasic<IAccessoryView,Accessory>
        implements IAccessoryPresenter {


    public void Insert(final JSONArray accessories) {
        model.refreshTable(accessories, new IDBResultView() {
            @Override
            public void onSuccess() {
                view.accessoryIserted(true);
            }

            @Override
            public void onItemInserted() {
                view.onItemInserted(Config.Params.ACCESSORY);
            }

            @Override
            public void onFail(String error) {
                view.accessoryIserted(false);
            }
        });
    }

    public void getAccessories() {
        view.accessories(new Accessory().getAllItems());
    }

    public void getAccessoryById(long id) {
        view.accessoriesById(new Accessory().fetchById(id));
    }

    public void AccessoryBtShop(int shop_id) {
        view.accessoriesByShop(new Accessory().fetchByShop(shop_id));
    }

    public void getAccessoriesByCondition(int shop_id, int ID, int subcanal, int Posiction, int Elemento) {
        view.accessoriesByCondition(new Accessory().fetchByShopResultId(shop_id, ID, subcanal, Posiction, Elemento));
    }


}
