package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter;


import android.os.Handler;

import org.json.JSONArray;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Shop;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBArrayResultView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBResultView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IShopView;
import cl.bequarks.project.paraeco.Activity.PresenterBasic;
import cl.bequarks.project.paraeco.sharedpreference.Config;

public class ShopPresenter extends PresenterBasic<IShopView, Shop> implements IShopPresenter {
    private static final String TAG = "ShopPresenter";
    Handler thread;
    private int maxNumberTryToGetGps = 5;
    private int numberTryToGetGps = 0;

    @Override
    public void Insert(final JSONArray shops) {
        new Thread(new Runnable() {
            @Override
            public void run() {


                model.refreshTable(shops, new IDBResultView() {
                    @Override
                    public void onSuccess() {
                        view.ShopInserted(true);
                    }

                    @Override
                    public void onItemInserted() {
                        view.onItemInserted(Config.Params.SHOP);
                    }

                    @Override
                    public void onFail(String error) {
                        view.ShopInserted(false);
                    }
                });
            }
        }).start();
    }

    @Override
    public void getShopById(final long id) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                view.ShopById(new Shop().fetchById(id));
            }
        }).start();
    }

    @Override
    public void getShopsByLocation(final double lat, final double latLong) {

        final Shop shop = new Shop();

        new Thread(new Runnable() {
            @Override
            public void run() {
                ArrayList<Shop> shops = shop.fetchByLocation(lat, latLong);
                view.LocatedShops(shops);
            }
        }).start();

//        this.IShopView.LocatedShops(new Shop().fetchByLocation( lat, latLong));
    }

    @Override
    public void getShops() {
        new Thread(new Runnable() {
            @Override
            public void run() {

                view.AllShops(new Shop().getAllShops());
            }
        }).start();
    }

    @Override
    public void getShopsByLocationSubCanal(final double lat, final double latLong, final int subCanal, final int canal) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                view.LocatedShopsubCanalShops(new Shop().fetchByLocationSubCanal(lat, latLong, subCanal, canal));
            }
        }).start();
    }

    @Override
    public void getShopsByCurrentLocation() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                model.fetchByCurrentLocation(new IDBArrayResultView<Shop>() {
                    @Override
                    public void onSuccess(ArrayList<Shop> results) {
                        view.ShopsByCurrentLocation(results);
                    }

                    @Override
                    public void onFail(String error) {
                        view.NoShopsAround(error);
                    }
                });
            }
        }).start();
    }

//    @Override
//    public void onSuccess(ArrayList<Shop> results) {
//        view.ShopsByCurrentLocation(results);
//    }
//
//    @Override
//    public void onFail(String error) {
//        numberTryToGetGps++;
//        if (numberTryToGetGps < maxNumberTryToGetGps) {
//            //Handler handler = new Handler(thread.getLooper());
//
//            try {
//                Thread.sleep(1000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//
//            new LoadShops().execute("");
//
//        } else {
//            numberTryToGetGps = 0;
//            view.NoShopsAround(error);
//        }
//
//    }


}
