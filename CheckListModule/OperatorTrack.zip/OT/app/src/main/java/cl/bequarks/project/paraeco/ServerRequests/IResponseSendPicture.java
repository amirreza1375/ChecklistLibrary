package cl.bequarks.project.paraeco.ServerRequests;

public interface IResponseSendPicture {

    void NetWorkError();

    void ServerError(int index , String error, int size);

    void ServerFailed(int index , String error, int size);

    void Sent(int size , int index);

    void ImageNotExist();

    void UploadProgress(int progress);

}
