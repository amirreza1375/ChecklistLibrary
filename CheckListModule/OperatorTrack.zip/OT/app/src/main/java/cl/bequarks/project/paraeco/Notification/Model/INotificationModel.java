package cl.bequarks.project.paraeco.Notification.Model;


import androidx.core.app.NotificationCompat;

public interface INotificationModel {

    void showNotification(NotificationCompat.Builder mBuilder);

    void createNotificationChannel();

    NotificationCompat.Builder sendNotification();

}
