package cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.View;

import com.example.checklist.PictureElement.PicturePickerItemModel;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.UserCheckList;

public interface IUserChecklistView {
    void CheckListDataInserted(long id);

    void CheckListDataNotInserted(String err);

    void CheckListItemsByUserAndDate(ArrayList<UserCheckList> userCheckLists);

    void CheckListDataItemsEmpty();

    void CheckListById(UserCheckList userCheckList);

    void CheckListNotFound();

    void CheckListSynced();

    void CheckListNotSynced();

    void CheckListDataAndPictures(UserCheckList userCheckList, ArrayList<PicturePickerItemModel> pics);

    void NoCheckLisAndPictures();

    void NoDeletedItem();

    void onDeletedItemsRecieved(ArrayList<UserCheckList> results);

    void allDeletedsRemoved();
}
