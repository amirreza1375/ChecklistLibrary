package cl.bequarks.project.paraeco.UserActionTracker.Model;

import android.database.sqlite.SQLiteDatabase;

import org.json.JSONArray;
import org.json.JSONObject;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBResultView;

public class ActionModel implements IActionModel {

    public SQLiteDatabase dropAndCreateTable() {
        return null;
    }

    public long insert(SQLiteDatabase db) {
        return 0;
    }

    public ActionModel getByJson(JSONObject json) {
        return null;
    }

    public void refreshTable(JSONArray json, IDBResultView callback) {

    }
}
