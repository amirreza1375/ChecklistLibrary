package cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Presenter;

import android.os.Handler;

import com.example.checklist.PictureElement.PicturePickerItemModel;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.UserCheckList;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.IDBCheckListAndPicturesResultView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.IDBInsertResult;
import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.View.IUserChecklistView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBArrayResultView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBResultView;
import cl.bequarks.project.paraeco.Activity.PresenterBasic;

public class UserChecklistPresenter extends PresenterBasic<IUserChecklistView, UserCheckList> implements ICheckLsitDataPresenter {

    @Override
    public void insert(final UserCheckList userCheckList) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                userCheckList.insert(userCheckList, new IDBInsertResult() {
                    @Override
                    public void onSuccess(long id) {
                        view.CheckListDataInserted(id);
                    }

                    @Override
                    public void onFail(String error) {
                        view.CheckListDataNotInserted(error);
                    }
                });
            }
        }).start();

    }

    public void update(final UserCheckList userCheckList) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                userCheckList.updateItem(userCheckList, new IDBInsertResult() {
                    @Override
                    public void onSuccess(long id) {
                        view.CheckListDataInserted(id);
                    }

                    @Override
                    public void onFail(String error) {
                        view.CheckListDataNotInserted(error);
                    }
                });

            }
        }).start();
    }

    @Override
    public void getCheckListItemsByUserAndDate(final String user, final String date) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
//                new Thread(new Runnable() {
//                    @Override
//                    public void run() {

                        model.fetchByUserAndDate(user, date, new IDBArrayResultView<UserCheckList>() {
                            @Override
                            public void onSuccess(ArrayList<UserCheckList> results) {
                                view.CheckListItemsByUserAndDate(results);
                            }

                            @Override
                            public void onFail(String error) {
                                view.CheckListDataItemsEmpty();
                            }
                        });

//                    }
//                }).start();
            }
        },300);

    }

    @Override
    public void getCheckListDataById(final long id) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                UserCheckList userCheckList = model.fetchById(id);

                if (userCheckList != null) {
                    view.CheckListById(userCheckList);
                } else {
                    view.CheckListNotFound();
                }

            }
        }).start();

    }

    @Override
    public void changeCheckListSync(long id) {
//        model.updateCheckListSync(id, new IDBResultView() {
//            @Override
//            public void onSuccess() {
//                view.CheckListSynced();
//            }
//
//            @Override
//            public void onItemInserted() {
//
//            }
//
//            @Override
//            public void onFail(String error) {
//                view.CheckListNotSynced();
//            }
//        });
    }

    @Override
    public void getCheckListAndPictures(final long id) {

                model.fetchCheckListAndPicturesById(id, new IDBCheckListAndPicturesResultView<UserCheckList>() {
                    @Override
                    public void onSuccess(UserCheckList result, ArrayList<PicturePickerItemModel> pics) {
                        view.CheckListDataAndPictures(result, pics);
                    }

                    @Override
                    public void onFailed(String error) {
                        view.NoCheckLisAndPictures();
                    }
                });


    }

    @Override
    public void getDeletedItems(final String user) {

        model.fetchDeletedItems(user, new IDBArrayResultView<UserCheckList>() {
            @Override
            public void onSuccess(ArrayList<UserCheckList> results) {
                view.onDeletedItemsRecieved(results);
            }

            @Override
            public void onFail(String error) {
                view.NoDeletedItem();
            }
        });

    }

    @Override
    public void removeAllDeletedItems() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                model.removeAllDeleteds(new IDBResultView() {
                    @Override
                    public void onSuccess() {
                        view.allDeletedsRemoved();
                    }

                    @Override
                    public void onItemInserted() {

                    }

                    @Override
                    public void onFail(String error) {

                    }
                });
            }
        }).start();
    }
}
