package cl.bequarks.project.paraeco.Activity.ActivityForgetPassword.Model;

import cl.bequarks.project.paraeco.ServerRequests.IResponseApiToModel2;

public interface IForgetPassword {
    void sendForgetPasswordRequest(IResponseApiToModel2<String> callback);}
