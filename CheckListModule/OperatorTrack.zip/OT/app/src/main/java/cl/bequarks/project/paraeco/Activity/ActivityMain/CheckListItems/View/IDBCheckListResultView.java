package cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.View;

public interface IDBCheckListResultView<M> {
    void onSuccess(M result);
    void onFail(String error);
}
