package cl.bequarks.project.paraeco.Activity.ActicityNewCheckList.CheckListFragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Category;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Checklist;
import cl.bequarks.project.paraeco.R;

/**
 * this adapter used in {@link }
 * for showing checklists
 */

public class CheckListsRecyclerAdapter extends RecyclerView.Adapter<CheckListsRecyclerAdapter.ViewHolder> {
    private Context context;
    private List<Checklist> list;
    private CheckListActionListener listListener;
    private ViewGroup viewGroup;
    AlertDialog alertDialog;

    public CheckListsRecyclerAdapter(Context context, List<Checklist> list, CheckListActionListener listListener) {
        this.context = context;

        this.list = list;
        this.listListener = listListener;
        Activity activity = (Activity) context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        this.viewGroup = parent;
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.layout_item_check_lists, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Category category = new Category();
//        List<Category> categoriesDBS = Category.listAll(Category.class);
        List<Category> categoriesDBS = category.getAllItems();

        String cats[] = list.get(position).getCategory().split(",");
        ArrayList<Integer> cat = new ArrayList<>();
        for (int i = 0; i < cats.length; i++) {
            cat.add(Integer.valueOf(cats[i]));
        }
        String catTxt = "";
        for (int i = 0; i < categoriesDBS.size(); i++) {
            for (int j = 0; j < cat.size(); j++) {
                if (categoriesDBS.get(i).getValue() == cat.get(j)) {
                    catTxt = catTxt + categoriesDBS.get(i).getName();
//                    holder.list_categoty.setText(categoriesDBS.get(i).getName());
                }
            }
        }


        holder.list_title.setText(list.get(position).getTitle());
        holder.checkListDataBaseId = list.get(position).get_ID();
        holder.json = list.get(position).getJOSN().toString().equals("") ? "{}" : list.get(position).getJOSN().toString();
        holder.checkListServerId = list.get(position).getCheckId();

        if (list.get(position).getHasError() == 1) {
            holder.errorImg.setVisibility(View.VISIBLE);
        }

    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        public long checkListDataBaseId;
        public TextView list_title;
        public String json;
        long checkListServerId;
        public ImageView errorImg;

        public ViewHolder(View itemView) {
            super(itemView);

            list_title = itemView.findViewById(R.id.list_title);
            errorImg = itemView.findViewById(R.id.errorImg);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (list.get(getPosition()).getHasError() == 0) {
                        listListener.onClicked(checkListDataBaseId, json, list_title.getText().toString(), checkListServerId);
                    } else {
                        showErrorsAlert(list.get(getPosition()));
                    }
                }
            });

        }
    }

    private void showErrorsAlert(Checklist checklist) {
        String errors = checklist.getErrors();
        if (errors != null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setCancelable(false);
            View view = LayoutInflater.from(context).inflate(R.layout.layout_checklist_errors, viewGroup, false);
            TextView txtErrors = view.findViewById(R.id.txtErrors);
            Button cancelbtn = view.findViewById(R.id.cancelBtn);
            cancelbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    alertDialog.dismiss();
                }
            });
            txtErrors.setText(errors);
            builder.setView(view);
            alertDialog = builder.create();
            alertDialog.show();
        }
    }

    public interface CheckListActionListener {
        void onClicked(long checkListDataBaseId, String json, String name, long checkListServerId);

    }

}
