package cl.bequarks.project.paraeco.ServerRequests;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.concurrent.TimeUnit;

import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.ServerRequests.RetrofitInterface.Upload;
import cl.bequarks.project.paraeco.sharedpreference.Config;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by shahr on 2/20/2019.
 */

public class M_Retrofit {
    static HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor();
    static OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.MINUTES)
            .readTimeout(5, TimeUnit.MINUTES)
            .addInterceptor(httpLoggingInterceptor).build();
    static Gson gson = new GsonBuilder()
            .setLenient()
            .create();
    public static Upload newInstanceUpload() {
        return new Retrofit.Builder().addConverterFactory(GsonConverterFactory.create(gson))
                .baseUrl(Config.getServer(G.context))
                .client(client).build().create(Upload.class);
    }
}
