package cl.bequarks.project.paraeco.Activity.ActicityNewCheckList.ShopsFragment;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Shop;
import cl.bequarks.project.paraeco.Global.GPSTracker;
import cl.bequarks.project.paraeco.R;

/**
 * used in {@link }
 */

public class ShopRecyclerAdapter extends  RecyclerView.Adapter<ShopRecyclerAdapter.ViewHolder>{

    private Context context;
    private ArrayList<Shop> list;
    private ShopClickListener onViewClickedListener;

    public ShopRecyclerAdapter(Context context, ArrayList<Shop> list, ShopClickListener onViewClickedListener){
        this.context = context;

        this.list = list;
        this.onViewClickedListener = onViewClickedListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.layout_item_shop_new,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.retail.setText(list.get(position).getRetailName());
        holder.shop_name.setText(list.get(position).getShopName());
        holder.id = list.get(position).getShopId();
        String adress = list.get(position).getAdress();
        holder.shop_adress.setText(adress);
        holder.subcanal_id = list.get(position).getSubCanalId();
        holder.shop = list.get(position);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public int id;
        private long databaseID ;
        public TextView shop_name;
        public ImageView img;
        public TextView shop_adress;
        public  TextView retail;
        private int subcanal_id;
        private Shop shop;
        public ViewHolder(final View itemView) {
            super(itemView);

            shop_name = itemView.findViewById(R.id.shop_name);
            retail = itemView.findViewById(R.id.retail);
            img = itemView.findViewById(R.id.imgProfile);
            shop_adress = itemView.findViewById(R.id.shop_adress);

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {

                    GPSTracker.getInstance(context, new GPSTracker.GPSListener() {
                        @Override
                        public void onLocationTracked(double lat, double latLong) {
                            double dist = getDistanceFromLatLonInKm(lat,latLong,shop.getLat(),shop.getLat_long());
                            int distInt = (int) dist;
                                    onViewClickedListener.onLongClicked(String.valueOf(distInt),lat,latLong);
                        }

                        @Override
                        public void onLocationError(String msg) {

                        }
                    }).getCurrentLocation();

                    return true;
                }
            });

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    itemView.setEnabled(false);
//                    new android.os.Handler().postDelayed(new Runnable() {
//                        @Override
//                        public void run() {
//                            itemView.setEnabled(true);
//                        }
//                    },500);
                    String shop = retail.getText().toString()+" "+shop_name.getText().toString();
                    onViewClickedListener.Clicked(id,shop,subcanal_id);
                }
            });
        }
    }
    public interface ShopClickListener{
        void Clicked(int id, String name, int subcanal_id);

        void onLongClicked(String dist,double lat,double lng);
    }

    public double getDistanceFromLatLonInKm(double lat1, double lon1, double lat2, double lon2) {

        double earthRadius = 6371; // in miles, change to 6371 for kilometer output

        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lon2 - lon1);

        double sindLat = Math.sin(dLat / 2);
        double sindLng = Math.sin(dLng / 2);

        double a = Math.pow(sindLat, 2) + Math.pow(sindLng, 2)
                * Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2));

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        double dist = earthRadius * c;

        Log.d("distance", String.valueOf(dist));

        double xr = lat2 < 0 && lon2 < 0 ? -1 : 1;
        double result = dist - 0.07362716373246034;
        return result; // output distance,  MinILES
    }

}
