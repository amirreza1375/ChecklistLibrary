package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBArrayResultView;

import java.util.ArrayList;

public interface IShop {

    ArrayList<Shop> fetchByLocation(double d, double d2);

    void fetchByCurrentLocation(IDBArrayResultView<Shop> callBack);

    ArrayList<Shop> fetchByLocationSubCanal(double d, double d2, int i, int i2);

    String getAdress();
    void setAddress(String address);

    int getCanalId();

    String getCity();

    String getCountry();

    String getImg();

    double getLat();
    void setLat(double lat);

    String getLogo();

    double getLong();
    void setLong(double lat_long);

    int getRetailId();


    String getRetailName();
    void setRetailName(String retailName);

    int getShopId();
    void setShopId(int shopId);

    String getShopName();
    void setShopName(String shopName);

    String getState();

    int getSubCanalId();

    String getType();

    int getUserId();

    String getZone();



}
