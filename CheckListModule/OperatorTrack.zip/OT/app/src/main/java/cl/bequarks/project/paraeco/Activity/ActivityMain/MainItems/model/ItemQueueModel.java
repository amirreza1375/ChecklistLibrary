package cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.model;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.ResultPicture;

public class ItemQueueModel {


    private long id;
//    private String authKey;
//    private String devId;
//    private String email;
    private String shopId;
    private String cehckListId;
    private String startTime;
    private String endTime;
    private String answer;
    private String pictures;
    private ArrayList<ResultPicture> itemPictures;
//    private MainItemsRecyclerAdapter.ViewHolder holder;
//
//    public ItemQueueModel(long id, String shopId, String cehckListId, String startTime, String endTime, String answer, String pictures
//    , ArrayList<ResultPicture> itemPictures, MainItemsRecyclerAdapter.ViewHolder holder) {
//        this.id = id;
////        this.authKey = authKey;
////        this.devId = devId;
////        this.email = email;
//        this.shopId = shopId;
//        this.cehckListId = cehckListId;
//        this.startTime = startTime;
//        this.endTime = endTime;
//        this.answer = answer;
//        this.pictures = pictures;
//        this.itemPictures = itemPictures;
//        this.holder = holder;
//    }


//    public String getAuthKey() {
//        return authKey;
//    }
//
//    public void setAuthKey(String authKey) {
//        this.authKey = authKey;
//    }
//
//    public String getDevId() {
//        return devId;
//    }
//
//    public void setDevId(String devId) {
//        this.devId = devId;
//    }
//
//    public String getEmail() {
//        return email;
//    }
//
//    public void setEmail(String email) {
//        this.email = email;
//    }

    public String getShopId() {
        return shopId;
    }

    public void setShopId(String shopId) {
        this.shopId = shopId;
    }

    public String getCehckListId() {
        return cehckListId;
    }

    public void setCehckListId(String cehckListId) {
        this.cehckListId = cehckListId;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getPictures() {
        return pictures;
    }

    public void setPictures(String pictures) {
        this.pictures = pictures;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public ArrayList<ResultPicture> getItemPictures() {
        return itemPictures;
    }

    public void setItemPictures(ArrayList<ResultPicture> itemPictures) {
        this.itemPictures = itemPictures;
    }


//    public MainItemsRecyclerAdapter.ViewHolder getHolder() {
//        return holder;
//    }
//
//    public void setHolder(MainItemsRecyclerAdapter.ViewHolder holder) {
//        this.holder = holder;
//    }
}
