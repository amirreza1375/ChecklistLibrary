package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import cl.bequarks.project.paraeco.Activity.ActicityNewCheckList.CheckListFragment.CheckListsRecyclerAdapter;
import cl.bequarks.project.paraeco.Activity.ActivityChecklist.ChecklistValidator;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBArrayResultView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBResultView;

import cl.bequarks.project.paraeco.DBHelper.FeedReaderContract;
import cl.bequarks.project.paraeco.DBHelper.TableDbHelper;
import cl.bequarks.project.paraeco.Global.G;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Checklist extends DBModelBaseTemp<Checklist> implements IChecklist, ChecklistValidator.CheckListValidatorListener {


    public static String conf_type = "type";
    public static String config_category = "category";
    public static String config_id = "id";
    public static String config_json = "json";
    public static String config_title = "title";
    private static String conf_shops = "shop";

    //region Filed of DB
    private long _ID;
    private String category;
    private long check_id;
    private String json;
    private String title;
    private int type;
    private String shops;
    private int hasError;
    private String errors;

    //endregion

    //region Constructor
    public Checklist(long check_id, String title, String category, String json, int type, String shops, int hasError, String errors) {
        this.check_id = check_id;
        this.title = title;
        this.category = category;
        this.json = json;
        this.type = type;
        this.shops = shops;
        this.hasError = hasError;
        this.errors = errors;
    }

    public Checklist() {

    }

    @Override
    public SQLiteDatabase dropAndCreateTable() {
        TableDbHelper dbHelper = TableDbHelper.getInstanceChecklist(G.context);
//
        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL(FeedReaderContract.CheckListTable.SQL_DELETE_ENTRIES);
        db.execSQL(FeedReaderContract.CheckListTable.SQL_CREATE_ENTRIES);

        return db;
    }
    //endregion

    //region ICheckList
    @Override
    public long getCheckId() {
        return this.check_id;
    }

    @Override
    public String getTitle() {
        return this.title;
    }

    @Override
    public String getCategory() {
        return this.category;
    }

    @Override
    public JSONObject getJOSN() {
        try {
            return new JSONObject(this.json);
        } catch (JSONException e) {
            e.printStackTrace();
            return new JSONObject();
        }
    }

    @Override
    public int getType() {
        return this.type;
    }

    @Override
    public void fetchByType(int type, IDBArrayResultView<Checklist> callBack) {
        List<Checklist> checklistDBS = getAllChecklists();
        ArrayList<Checklist> checklists = new ArrayList();
        for (Checklist checklistDB : checklistDBS) {
            if (checklistDB.getType() == type) {
                checklists.add(checklistDB);
            }
        }
        if (checklists.size() == 0) {
            callBack.onFail("no check list with type = " + type);
        } else {
            callBack.onSuccess(checklists);
        }

    }
    //endregion

    //region method of base model
    @Override
    public long insert(Checklist checklist, SQLiteDatabase db, IDBResultView callBack) {
        long newRowId = 0;
        newRowId = db.insert(FeedReaderContract.CheckListTable.TABLE_NAME, null, getValues(checklist));

        return newRowId;
    }

    private ContentValues getValues(Checklist checklist) {
        ContentValues values = new ContentValues();
        values.put(FeedReaderContract.CheckListTable.serverId, checklist.getCheckId());
        values.put(FeedReaderContract.CheckListTable.category, checklist.getCategory());
        values.put(FeedReaderContract.CheckListTable.title, checklist.getTitle());
        values.put(FeedReaderContract.CheckListTable.shops, checklist.getShops());
        values.put(FeedReaderContract.CheckListTable.type, checklist.getType());
        values.put(FeedReaderContract.CheckListTable.hasError, checklist.getHasError());
        values.put(FeedReaderContract.CheckListTable.json, checklist.getJson());
        values.put(FeedReaderContract.CheckListTable.errors, checklist.getErrors());
        return values;
    }

    @Override
    public Checklist getByJson(JSONObject json) {
        try {
            Checklist checklist =  new Checklist(
                    json.getLong(Checklist.config_id),
                    json.getString(Checklist.config_title),
                    json.getString(Checklist.config_category),
                    json.getString(Checklist.config_json).equals("") ? "{}" : json.getString(Checklist.config_json),
                    json.getInt(Checklist.conf_type),
                    json.has(Checklist.conf_shops) ? json.getString(Checklist.conf_shops) : "",
                    0,
                    ""
            );
            String errors = new ChecklistValidator(checklist.getJOSN()).isValid();
            checklist.setHasError(errors.equals("") ? 0:1);
            checklist.setErrors(errors);
            return checklist;
        } catch (JSONException e) {
            e.printStackTrace();
            Checklist checklist = new Checklist();
            checklist.errorMessage = e.getMessage();
            return checklist;
        }
    }

    @Override
    public void refreshTable(final JSONArray json, final IDBResultView callback) {
        Thread insertThread = new Thread(new Runnable() {
            @Override
            public void run() {
                SQLiteDatabase db = dropAndCreateTable();

                Log.i(MODEL_TAG, "Checklist -> Insert start");
                if (json != null) {
//                db.beginTransaction();
                    for (int i = 0; i < json.length(); i++) {
                        try {
                            Checklist checklist = getByJson(json.getJSONObject(i));

                            if (checklist.getErrorMessage() == null) {
                                checklist.insert(checklist, db, callback);
                                callback.onItemInserted();
                            } else {
                                callback.onFail(checklist.getErrorMessage());
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            callback.onFail("checklist have some error");
                        }
                    }
                }
//                db.endTransaction();
//                db.close();
                Log.i(MODEL_TAG, "Checklist -> Insert finished");
//                db.endTransaction();
                callback.onSuccess();

            }
        });
        insertThread.start();

    }

    @Override
    public SQLiteDatabase getDataBaseConnection() {
        TableDbHelper dbHelper = TableDbHelper.getInstanceChecklist(G.context);
        return dbHelper.getWritableDatabase();
    }

    public Checklist getByCheckListId(long checklistId) {
        TableDbHelper dbHelper = TableDbHelper.getInstanceChecklist(G.context);

        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.CheckListTable.TABLE_NAME
                + " where " + FeedReaderContract.CheckListTable.serverId + "='" + checklistId + "'", null);
        cursor.moveToNext();
//        db.close();
        return getItemByCursor(cursor);
    }

    @Override
    public Checklist fetchById(long id) {
        TableDbHelper dbHelper = TableDbHelper.getInstanceChecklist(G.context);

        if (dbHelper.isTableExists(FeedReaderContract.CheckListTable.TABLE_NAME, true)) {
            // Gets the data repository in write mode
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.CheckListTable.TABLE_NAME
                    + " where " + FeedReaderContract.CheckListTable._ID + "='" + id + "'", null);
            cursor.moveToNext();
            return getItemByCursor(cursor);

        } else {
            return new Checklist();
        }
    }

    @Override
    public Checklist getItemByCursor(Cursor cursor) {
        if (cursor != null) {
            try {
                long ID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.CheckListTable._ID));
                int serverId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.CheckListTable.serverId));
                String category = cursor.getString(cursor.getColumnIndex(FeedReaderContract.CheckListTable.category));
                String title = cursor.getString(cursor.getColumnIndex(FeedReaderContract.CheckListTable.title));
                String shops = cursor.getString(cursor.getColumnIndex(FeedReaderContract.CheckListTable.shops));
                int type = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.CheckListTable.type));
                int hasError = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.CheckListTable.hasError));
                String json = cursor.getString(cursor.getColumnIndex(FeedReaderContract.CheckListTable.json));
                String errors = cursor.getString(cursor.getColumnIndex(FeedReaderContract.CheckListTable.errors));
                Checklist checklist = new Checklist(serverId, title, category, json, type, shops, hasError, errors);
                checklist.set_ID(ID);
                return checklist;
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                cursor.close();
            }
        }
        return new Checklist();
    }

    public Checklist getItemForCursor(Cursor cursor) {
        if (cursor != null) {
            long ID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.CheckListTable._ID));
            int serverId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.CheckListTable.serverId));
            String category = cursor.getString(cursor.getColumnIndex(FeedReaderContract.CheckListTable.category));
            String title = cursor.getString(cursor.getColumnIndex(FeedReaderContract.CheckListTable.title));
            String shops = cursor.getString(cursor.getColumnIndex(FeedReaderContract.CheckListTable.shops));
            int hasError = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.CheckListTable.hasError));
            int type = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.CheckListTable.type));
            String json = cursor.getString(cursor.getColumnIndex(FeedReaderContract.CheckListTable.json));
            String errors = cursor.getString(cursor.getColumnIndex(FeedReaderContract.CheckListTable.errors));
            Checklist checklist = new Checklist(serverId, title, category, json, type, shops, hasError, errors);
            checklist.set_ID(ID);
            return checklist;
        }
        return new Checklist();
    }

    public void update(Checklist checklist) {
        TableDbHelper dbHelper = TableDbHelper.getInstanceChecklist(G.context);
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = getValues(checklist);

        int res = db.update(FeedReaderContract.CheckListTable.TABLE_NAME, values
                , FeedReaderContract.CheckListTable._ID + "=" + checklist.get_ID(), null);

//        db.close();
    }

    @Override
    public boolean updateImgPath(SQLiteDatabase db, String URL, long id, IDBResultView callBack) {
        return false;
    }

    @Override
    public ArrayList<Checklist> getAllItems() {
        TableDbHelper dbHelper = TableDbHelper.getInstanceChecklist(G.context);
//
        // Gets the data repository in write mode
        if (dbHelper.isTableExists(FeedReaderContract.CheckListTable.TABLE_NAME, true)) {
            final SQLiteDatabase db = dbHelper.getWritableDatabase();

            Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.CheckListTable.TABLE_NAME, null);
            return getItemsByCursor(cursor, db);
        } else {
            return new ArrayList<>();
        }
    }

    @Override
    public ArrayList<Checklist> getItemsByCursor(Cursor cursor, SQLiteDatabase db) {
        try {
            ArrayList<Checklist> checklists = new ArrayList<>();
            if (cursor.moveToFirst()) {
                while (!cursor.isAfterLast()) {

                    checklists.add(getItemForCursor(cursor));

                    cursor.moveToNext();
                }
            }
            cursor.close();
//            db.close();
            return checklists;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
//            db.close();
            cursor.close();
        }
//        db.close();
        return new ArrayList<>();
    }

    @Override
    public String getImgURLById(long id) {
        return "";
    }

    @Override
    public ContentValues getValuse(Checklist item) {
        return null;
    }

//    @Override
//    public void downloadImages(IDBResultView callBack) {
//
//    }

    @Override
    public void fetchByTypeAndSubCanal(String shopId, final int type, final int subCanal, final IDBArrayResultView<Checklist> callBack) {

        List<Checklist> checklists = getAllChecklists();
        ArrayList<Checklist> tempCheckList = new ArrayList<>();
        for (int i = 0; i < checklists.size(); i++) {
            //check type
            String shops[] = {};
            String shopsStr = checklists.get(i).getShops();
            if (shopsStr == null)
                shopsStr = "";

            if (!shopsStr.equals("")) {
                shops = shopsStr.split(",");
            }
            String cat = checklists.get(i).getCategory();
            int checkListType = checklists.get(i).getType();
            if (isOkToAddChecklist(shopId, shops, checkListType, type, subCanal, cat))

                tempCheckList.add(checklists.get(i));

        }

        if (tempCheckList.size() == 0) {
            callBack.onFail("no checklist with this type and subcanal");
        } else {
            callBack.onSuccess(tempCheckList);
        }

    }

    private List<Checklist> getAllChecklists() {
        TableDbHelper dbHelper = TableDbHelper.getInstanceChecklist(G.context);
//
        // Gets the data repository in write mode
        if (dbHelper.isTableExists(FeedReaderContract.CheckListTable.TABLE_NAME, true)) {
            final SQLiteDatabase db = dbHelper.getWritableDatabase();

            Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.CheckListTable.TABLE_NAME, null);
            return getChecklistsFromCursor(cursor, db);
        } else {
            return new ArrayList<>();
        }
    }

    private List<Checklist> getChecklistsFromCursor(Cursor cursor, SQLiteDatabase db) {
        ArrayList<Checklist> checklists = new ArrayList<>();
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                long ID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.CheckListTable._ID));
                int checkId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.CheckListTable.serverId));
                String title = cursor.getString(cursor.getColumnIndex(FeedReaderContract.CheckListTable.title));
                String category = cursor.getString(cursor.getColumnIndex(FeedReaderContract.CheckListTable.category));
                String json = cursor.getString(cursor.getColumnIndex(FeedReaderContract.CheckListTable.json));
                int hasError = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.CheckListTable.hasError));
                int type = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.CheckListTable.type));
                String shops = cursor.getString(cursor.getColumnIndex(FeedReaderContract.CheckListTable.shops));
                String errors = cursor.getString(cursor.getColumnIndex(FeedReaderContract.CheckListTable.errors));

                Checklist checklist = new Checklist(checkId, title, category, json, type, shops, hasError, errors);
                checklist.set_ID(ID);
                checklists.add(checklist);

                cursor.moveToNext();
            }
        }

//        db.close();
        return checklists;
    }
    //endregion

    private boolean isOkToAddChecklist(String shopId, String[] shops, int checklistType, int currentType, int subCalan, String cat) {
        if (currentType != checklistType)
            return false;

        if (shops == null)
            return true;

        if (shops.length == 0)
            return true;

        if (isCatOk(subCalan, cat)) {

            if (isShopAssigned(shops, shopId)) {

                return true;

            }
        }
        return false;

    }

    private boolean isShopAssigned(String[] shops, String shopId) {

        if (shops == null)
            return true;

        if (shops.length == 0)
            return true;

        for (int i = 0; i < shops.length; i++) {

            if (shops[i].equals(shopId))
                return true;

        }

        return false;

    }

    private boolean isCatOk(int subCanal, String cat) {
        if (subCanal == -1)//this is track and don't check
            return true;

        //this is movistar and check subcanal with category

        String[] cats = cat.split(",");

        for (String s : cats) {

            if (s.equals(subCanal + ""))//subcanal matched with one of categories
                return true;

        }
        return false;

    }

    public void setType(int type) {
        this.type = type;
    }

    public void setSubCanal(String subCanal) {
        this.category = subCanal;
    }

    public String getShops() {
        return shops;
    }

    public void setShops(String shops) {
        this.shops = shops;
    }

    public long get_ID() {
        return _ID;
    }

    public void set_ID(long _ID) {
        this._ID = _ID;
    }

    public String getJson() {
        return this.json;
    }

    public int getHasError() {
        return hasError;
    }

    public void setHasError(int hasError) {
        this.hasError = hasError;
    }

    public String getErrors() {
        return errors;
    }

    public void setErrors(String errors) {
        this.errors = errors;
    }

    @Override
    public void onValidChecklist(long id, CheckListsRecyclerAdapter.ViewHolder holder, SQLiteDatabase db) {
        Checklist checklist = fetchById(id);
        checklist.setErrors("");
        checklist.setHasError(0);
        checklist.update(checklist);
        ContentValues values = getValues(checklist);
        if (db.isOpen()) {
            int res = db.update(FeedReaderContract.CheckListTable.TABLE_NAME, values
                    , FeedReaderContract.CheckListTable._ID + "=" + checklist.get_ID(), null);
        }
    }

    @Override
    public void onNotValidChecklist(long id, CheckListsRecyclerAdapter.ViewHolder holder, ArrayList<String> errors, SQLiteDatabase db) {
        Checklist checklist = fetchById(id);
        String allErrors = "";
        for (int i = 0; i < errors.size(); i++) {

            allErrors = allErrors + errors.get(i) + "\n";

        }
        checklist.setErrors(allErrors);
        checklist.setHasError(1);
        ContentValues values = getValues(checklist);
        if (db.isOpen()) {
            int res = db.update(FeedReaderContract.CheckListTable.TABLE_NAME, values
                    , FeedReaderContract.CheckListTable._ID + "=" + checklist.get_ID(), null);
        }

    }
}

