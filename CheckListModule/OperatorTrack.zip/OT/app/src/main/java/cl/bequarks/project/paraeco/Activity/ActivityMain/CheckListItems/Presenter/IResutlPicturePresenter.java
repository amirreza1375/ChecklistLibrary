package cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Presenter;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.ResultPicture;

interface IResutlPicturePresenter {

    void getPicturesByCheckListId(long checkListId);
    void insert(ResultPicture resultPicture, int count);
}
