package cl.bequarks.project.paraeco.Activity.ActivityMain.MainItems.model;

public class PictureItemModel {

    private long id;
    private String serverId;
    private String picNumber;
    private String type;
    private String questionId;

}
