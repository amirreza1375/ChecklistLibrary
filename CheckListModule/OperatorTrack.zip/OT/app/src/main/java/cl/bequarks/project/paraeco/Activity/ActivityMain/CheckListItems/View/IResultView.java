package cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.View;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.ResultPicture;

public interface IResultView {

    void PicturesByCheckListId(ArrayList<ResultPicture> pictures);

    void EmptyPicturesWithCheckListId(String message);

    void PictureInsertet(int count);

    void PictureNotInserted();
}
