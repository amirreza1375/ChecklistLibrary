package cl.bequarks.project.paraeco.Activity.ActivityTutorial.CameraTutorial;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.checklist.BaseViewModel.ElemetActionListener;
import com.example.checklist.PictureElement.PictureElementMaker;
import com.example.checklist.PictureElement.PicturePickerItemModel;
import com.example.checklist.PictureElement.PicturesRecyclerView;
import com.takusemba.spotlight.OnSpotlightEndedListener;
import com.takusemba.spotlight.OnSpotlightStartedListener;
import com.takusemba.spotlight.SimpleTarget;
import com.takusemba.spotlight.Spotlight;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.R;
import cl.bequarks.project.paraeco.sharedpreference.Config;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link CameraFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link CameraFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CameraFragment extends Fragment implements PictureElementMaker.TakePictureItemClickListener, ElemetActionListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private PicturesRecyclerView.ViewHolder holder;
    private PicturePickerItemModel model;

    private OnFragmentInteractionListener mListener;

    private LinearLayout parent;
    private ImageButton backBtn;
    private RelativeLayout cameraView;

    public CameraFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CameraFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static CameraFragment newInstance(String param1, String param2) {
        CameraFragment fragment = new CameraFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        parent = view.findViewById(R.id.parent);
        backBtn = view.findViewById(R.id.back);
        cameraView = view.findViewById(R.id.cameraView);
        final View cameraView = createCameraView();

        parent.addView(cameraView);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startCameraTutorial(cameraView);
            }
        });

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                backBtn.performClick();
            }
        },1000);

    }

    private void startCameraTutorial(View view) {

        SimpleTarget first =
                new SimpleTarget.Builder(getActivity()).setPoint(view)
                        .setRadius(500f)
                        .setTitle("Image Items")
                        .setDescription("Here appears image items with different type and count from web configuration")
                        .build();
        SimpleTarget second =
                new SimpleTarget.Builder(getActivity()).setPoint(parent.findViewById(R.id.done))
                        .setRadius(150f)
                        .setTitle("Save Button")
                        .setDescription("With this button you can save all images you took")
                        .build();
        SimpleTarget third =
                new SimpleTarget.Builder(getActivity()).setPoint(backBtn)
                        .setRadius(100f)
                        .setTitle("Back Button")
                        .setDescription("If you press this button you images won't be saved")
                        .build();
        Spotlight.with(getActivity())
                .setDuration(1L)
                .setAnimation(new DecelerateInterpolator(2f))
                .setTargets(first,second,third)
                .setOnSpotlightStartedListener(new OnSpotlightStartedListener() {
                    @Override
                    public void onStarted() {
//                        Toast.makeText(ActivityMain.this, "spotlight is started", Toast.LENGTH_SHORT)
//                                .show();
                    }
                })
                .setOnSpotlightEndedListener(new OnSpotlightEndedListener() {
                    @Override
                    public void onEnded() {
                        Toast.makeText(getActivity(), "Press one of items to take picture", Toast.LENGTH_SHORT).show();
                    }
                })
                .start();

    }

    private View createCameraView() {
        PictureElementMaker elementMaker = null;
        try {
            elementMaker = new PictureElementMaker(getContext(), new JSONObject(Config.sampleCameraJson)
                    , true, true, new JSONArray(), 0, this,this);
            elementMaker.setMlistener(this);
            return elementMaker;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return new LinearLayout(getContext());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_camera, container, false);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onPictureItemClicked(PicturesRecyclerView.ViewHolder holder, PicturePickerItemModel model) {
        this.holder = holder;
        this.model = model;
        View cameraShooterView = createCameraShooterView();
        startCameraShooterTutorial(cameraShooterView);
    }

    private void startCameraShooterTutorial(View cameraShooterView) {

    }

    private View createCameraShooterView() {
        parent.setVisibility(View.GONE);
        cameraView.setVisibility(View.VISIBLE);
        return cameraView;
    }

    @Override
    public void onModelsAdded(ArrayList<PicturePickerItemModel> models) {

    }

    @Override
    public void onNoImageAppeared(String msg) {

    }

    @Override
    public void onAction(String name,String id, String data, int pagePosition) {

    }

    @Override
    public void onConditionaryDataChanged(String s, String s1, boolean b, String s2) {

    }

    @Override
    public void isHiddenView() {

    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onCameraTutorialFinished();
    }
}
