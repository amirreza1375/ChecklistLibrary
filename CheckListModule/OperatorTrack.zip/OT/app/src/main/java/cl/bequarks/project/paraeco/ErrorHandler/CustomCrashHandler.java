package cl.bequarks.project.paraeco.ErrorHandler;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import cl.bequarks.project.paraeco.Activity.ActivityError.ActivityError;
import cl.bequarks.project.paraeco.Global.G;

import static cl.bequarks.project.paraeco.Activity.ActivityError.ActivityError.ERROR;

public class CustomCrashHandler implements Thread.UncaughtExceptionHandler {

    private static final String TAG = "CustomCrashHandler";
    private Activity activity;

    public CustomCrashHandler(Activity activity){

        this.activity = activity;
    }

    @Override
    public void uncaughtException(Thread t, Throwable e) {
        Log.i(TAG, "uncaughtException: "+e.getMessage());

        Intent intent = new Intent(activity
        ,ActivityError.class);
        intent.putExtra(ERROR,e.getMessage());
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_CLEAR_TASK
                | Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);

        PendingIntent pendingIntent = PendingIntent.getActivity(G.getInstance().getBaseContext(), 0, intent, PendingIntent.FLAG_ONE_SHOT);


        AlarmManager mgr = (AlarmManager) G.getInstance().getBaseContext().getSystemService(Context.ALARM_SERVICE);
        mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 1, pendingIntent);

    }
}
