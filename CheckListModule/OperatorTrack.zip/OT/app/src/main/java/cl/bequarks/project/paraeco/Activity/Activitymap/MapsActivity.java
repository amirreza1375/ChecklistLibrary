package cl.bequarks.project.paraeco.Activity.Activitymap;

import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Shop;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.ShopPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IShopView;
import cl.bequarks.project.paraeco.Global.GPSTracker;
import cl.bequarks.project.paraeco.Permissions.Model.Permission;
import cl.bequarks.project.paraeco.Permissions.Presenter.PermissionPresenter;
import cl.bequarks.project.paraeco.Permissions.View.IPermissionView;
import cl.bequarks.project.paraeco.R;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback
        , IShopView, View.OnClickListener, GoogleMap.OnMarkerClickListener
        , GoogleMap.OnCameraChangeListener, View.OnTouchListener
        , IPermissionView {

    private static final String TAG = "MapsActivity";

    private GoogleMap mMap;
    private ImageButton currentLocationBtn;

    private ShopPresenter presenter;

    private Marker userMarker;

    protected int mDpi = 0;

    private Polyline currentPolyline;

    private ArrayList<Marker> shopMarkers;
    private HashMap<Integer, Shop> shopByMarkerIndex;

    private Permission permission ;
    private PermissionPresenter permissionPresenter;

    private AlertDialog alertDialogMap;
    private TextView distanceText;
    private Button btnGoMap;
    private RelativeLayout parent;
    private TextView countryTxt;
    private TextView cityTxt;
    private TextView retailNameTxt;
    private TextView zoneTxt;
    private TextView shopNameTxt;
    private TextView adressTxt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        mDpi = getResources().getDisplayMetrics().densityDpi;

        shopMarkers = new ArrayList<>();
        shopByMarkerIndex = new HashMap<>();

        presenter = new ShopPresenter();
        presenter.addModel(new Shop());
        presenter.attachView(this);

        permission = new Permission(this);
        permissionPresenter = new PermissionPresenter();
        permissionPresenter.addModel(permission);
        permissionPresenter.attachView(this);

        permissionPresenter.CheckLocationPermission();

        currentLocationBtn = findViewById(R.id.currentLocation);
        parent = findViewById(R.id.parent);

        initializeMapDialog();

        currentLocationBtn.setOnClickListener(this);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    public Bitmap resizeBitmap(String drawableName, int width, int height) {
        Bitmap imageBitmap = BitmapFactory.decodeResource(getResources(), getResources().getIdentifier(drawableName, "drawable", getPackageName()));
        return Bitmap.createScaledBitmap(imageBitmap, width, height, false);
    }

    private MarkerOptions getShopMarker(double lat, double ltlng, String shopName) {
        LatLng sydney = new LatLng(lat, ltlng);
        MarkerOptions markerOptions = new MarkerOptions().icon(BitmapDescriptorFactory.fromBitmap(resizeBitmap("barbershop", 100, 100))).position(sydney).title(shopName);
        return markerOptions;
    }

    private MarkerOptions getUserLocationMarker(double lat, double ltlng) {
        LatLng sydney = new LatLng(lat, ltlng);
        MarkerOptions markerOptions = new MarkerOptions().icon(BitmapDescriptorFactory.fromBitmap(resizeBitmap("user", 100, 100))).position(sydney).title("Your location");
        return markerOptions;
    }

    protected Bitmap adjustImage(Bitmap image) {
        int dpi = image.getDensity();
        if (dpi == mDpi)
            return image;
        else {
            int width = (image.getWidth() * mDpi + dpi / 2) / dpi;
            int height = (image.getHeight() * mDpi + dpi / 2) / dpi;
            Bitmap adjustedImage = Bitmap.createScaledBitmap(image, width, height, true);
            adjustedImage.setDensity(mDpi);
            return adjustedImage;
        }
    }

    private void removeShops() {
        for (int i = 0; i < shopMarkers.size(); i++) {

            shopMarkers.get(i).remove();
            shopMarkers.remove(i);
            shopByMarkerIndex.remove(i);
            i--;

        }
    }

    private void showShopsOnMap(final List<Shop> list) {

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < list.size(); i++) {

                    shopMarkers.add(mMap.addMarker(getShopMarker(
                            list.get(i).getLat()
                            , list.get(i).getLong()
                            , list.get(i).getShopName()
                    )));
                    shopByMarkerIndex.put(i, list.get(i));

                }
            }
        });

    }

    private void showUserCurrentLocation() {
        GPSTracker.getInstance(MapsActivity.this, new GPSTracker.GPSListener() {
            @Override
            public void onLocationTracked(double lat, double latLong) {
                LatLng officeSantiago = new LatLng(lat, latLong);
                if (userMarker != null)
                    userMarker.remove();
                userMarker = mMap.addMarker(getUserLocationMarker(lat, latLong));
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(officeSantiago, 15.0f));
            }

            @Override
            public void onLocationError(String msg) {

            }
        }).getCurrentLocation();
    }

    private void showAllShopsAround() {
//        new GPSTracker(MapsActivity.this, new GPSTracker.GPSListener() {
//            @Override
//            public void onLocationTracked(double lat, double latLong) {
//                presenter.getShopsByLocation(lat, latLong);
//            }
//        });
    }

    private void showAllShopsAround(double lat, double latLong) {

        presenter.getShopsByLocation(lat, latLong);

    }

    private String getUrl(LatLng origin, LatLng dest, String directionMode) {
        // Origin of route
        String str_origin = "origin=" + origin.latitude + "," + origin.longitude;
        // Destination of route
        String str_dest = "destination=" + dest.latitude + "," + dest.longitude;
        // Mode
        String mode = "mode=" + directionMode;
        // Building the parameters to the web service
        String parameters = str_origin + "&" + str_dest + "&" + mode;
        // Output format
        String output = "json";
        // Building the url to the web service
        String url = "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters + "&key=" + getString(R.string.google_maps_key);
        return url;
    }

    private void initializeMapDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View view1 = inflater.inflate(R.layout.layout_shop_info, parent, false);
        distanceText = view1.findViewById(R.id.disnatanceText);
        builder.setView(view1);
        btnGoMap = view1.findViewById(R.id.btn);
        countryTxt = view1.findViewById(R.id.country);
        cityTxt = view1.findViewById(R.id.city);
        retailNameTxt = view1.findViewById(R.id.retailName);
        shopNameTxt = view1.findViewById(R.id.shopName);
        adressTxt = view1.findViewById(R.id.adress);
        zoneTxt = view1.findViewById(R.id.zone);
        btnGoMap.setOnClickListener(this);
        Button btnCancel = view1.findViewById(R.id.cancel);
        alertDialogMap = builder.create();
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialogMap.dismiss();
            }
        });
        Log.i(TAG, "initializeMapDialog: ");


    }

    private void setDistanceTextAndInfo(final Shop shop) {

        countryTxt.setText(shop.getCountry());
        cityTxt.setText(shop.getCity());
        retailNameTxt.setText(shop.getRetailName());
        zoneTxt.setText(shop.getZone());
        shopNameTxt.setText(shop.getShopName());
        adressTxt.setText(shop.getAdress());

        GPSTracker.getInstance(this, new GPSTracker.GPSListener() {
            @Override
            public void onLocationTracked(double currentLat, double currentLong) {

                distanceText.setText(getdistanceString(getDistanceFromLatLonInKm(currentLat, currentLong, shop.getLat(), shop.getLat_long())));

            }

            @Override
            public void onLocationError(String msg) {

            }
        }).getCurrentLocation();
    }

    private String getdistanceString(double distanceFromLatLonInKm) {
        if (distanceFromLatLonInKm < 0)
            distanceFromLatLonInKm *= -1;
        String seperator = "  ";
        String kilometer = "";
        String meter = "";
        String distParts[] = String.valueOf(distanceFromLatLonInKm).split("\\.");
        String kmStr = distParts[0];
        String mtStr = distParts[1];
        if (mtStr.length() > 3)
            mtStr = mtStr.substring(0, 3);
        int km = Integer.parseInt(kmStr);
        double mtDouble = Double.parseDouble(mtStr);
        long mt = (long) mtDouble;
        if (km > 100) {//if distance is more than 100 km show you are far from shop
            return getString(R.string.wayFarFromShop);
        }

        if (km < 1) {
            if (mt < 100) {
                return getString(R.string.youAreInTheShop);
            }
        }
        boolean FLAG_IS_KM_AVILABLE = false;
        if (km >= 1) {//if dist km is below 1 don't show
            kilometer = getString(R.string.preDistanceMsg)
                    + seperator
                    + km
                    + seperator
                    + getString(R.string.postDistanceMsg)
                    + seperator;
            FLAG_IS_KM_AVILABLE = true;
        } else {
            kilometer = getString(R.string.preDistanceMsg)
                    + seperator;
        }

        if (mt >= 100) {//if dist meter is below 100 don't show
            meter = mt + seperator + getString(R.string.meterMsg)
                    + seperator;
            if (FLAG_IS_KM_AVILABLE)
                kilometer += getString(R.string.and) + seperator;
        }

        return kilometer + meter;

    }

    public double getDistanceFromLatLonInKm(double currentLat, double currentLong, double lat2, double lon2) {

        double earthRadius = 6371; // in miles, change to 6371 for kilometer output

        double dLat = Math.toRadians(lat2 - currentLat);
        double dLng = Math.toRadians(lon2 - currentLong);

        double sindLat = Math.sin(dLat / 2);
        double sindLng = Math.sin(dLng / 2);

        double a = Math.pow(sindLat, 2) + Math.pow(sindLng, 2)
                * Math.cos(Math.toRadians(currentLat)) * Math.cos(Math.toRadians(lat2));

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        double dist = earthRadius * c;

        Log.d("distance", String.valueOf(dist));

        double xr = lat2 < 0 && lon2 < 0 ? -1 : 1;
        double result = dist - 0.07362716373246034;
        return result; // output distance,  MinILES
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 102)
        {
            if (grantResults[0] == RESULT_OK)
            {
                finish();
            }else
            {
                showUserCurrentLocation();
            }
        }

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

//        Toast.makeText(this, "Map is ready", Toast.LENGTH_SHORT).show();
        
        mMap = googleMap;
        mMap.setOnCameraChangeListener(this);
        mMap.setOnMarkerClickListener(this);

        showUserCurrentLocation();
        showAllShopsAround();

    }


    @Override
    public void AllShops(List<Shop> list) {

    }


    @Override
    public void LocatedShops(List<Shop> list) {
        Log.i(TAG, "LocatedShops: " + list.size());
        showShopsOnMap(list);
    }

    @Override
    public void LocatedShopsubCanalShops(List<Shop> list) {
    }

    @Override
    public void ShopById(Shop shop) {

    }

    @Override
    public void ShopInserted(boolean status) {

    }

    @Override
    public void ShopsByCurrentLocation(ArrayList<Shop> shops) {
    }

    @Override
    public void NoShopsAround(String error) {

    }

    @Override
    public void onItemInserted(String name) {

    }

    @Override
    public void onClick(View v) {

        if (v == currentLocationBtn) {
            showUserCurrentLocation();
        }
        if (v == btnGoMap) {

            alertDialogMap.dismiss();

        }
    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        if (marker.equals(userMarker)) {
            showUserCurrentLocation();
            return true;
        }
        for (int i = 0; i < shopMarkers.size(); i++) {
            if (marker.equals(shopMarkers.get(i))) {
                Shop shop = shopByMarkerIndex.get(i);
                if (shop != null) {
                    setDistanceTextAndInfo(shop);
                    alertDialogMap.show();
                }
            }
        }

        return true;
    }

    private String getAddress(double latitude, double longitude) {
        StringBuilder result = new StringBuilder();
        try {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
            if (addresses.size() > 0) {
                Address address = addresses.get(0);
                result.append(address.getLocality()).append("\n");
                result.append(address.getCountryName());
            }
        } catch (IOException e) {
            Log.e("tag", e.getMessage());
        }

        return result.toString();
    }

    @Override
    public void onCameraChange(CameraPosition cameraPosition) {
        removeShops();
        LatLng cameraLocation = cameraPosition.target;
        getAddress(cameraLocation.latitude,cameraLocation.longitude);
        float zoom = cameraPosition.zoom;
        Log.i(TAG, "onCameraChange: lat = " + cameraLocation.latitude + " long = " + cameraLocation.longitude);
        if (zoom >= 12.0f) {
            showAllShopsAround(cameraLocation.latitude, cameraLocation.longitude);
        } else {
            removeShops();
        }
    }


    @Override
    public boolean onTouch(View v, MotionEvent event) {
//        int action = event.getAction();
//        if (action == MotionEvent.ACTION_UP) {
//            currentLocationBtn.setTextColor(getResources().getColor(com.example.checklist.R.color.colorPrimary));
//            currentLocationBtn.setBackground(getResources().getDrawable(R.drawable.custom_btn_release));
//            showUserCurrentLocation();
//        } else {
//            currentLocationBtn.setTextColor(Color.WHITE);
//            currentLocationBtn.setBackground(getResources().getDrawable(R.drawable.custom_btn_pressed));
//        }

        return true;
    }

    @Override
    public void StoragePermission(boolean status) {

    }

    @Override
    public void LocationPermission(boolean status) {
        if (!status)
        {
            permissionPresenter.getLocationPermission();
        }
    }

    @Override
    public void CameraPermission(boolean status) {

    }

    @Override
    public void ReadStoragePermission(boolean status) {

    }
}
