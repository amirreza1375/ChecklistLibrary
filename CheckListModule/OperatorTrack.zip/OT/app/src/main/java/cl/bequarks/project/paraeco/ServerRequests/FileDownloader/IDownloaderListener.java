package cl.bequarks.project.paraeco.ServerRequests.FileDownloader;

public interface IDownloaderListener {

    void onProccessChanged(int progress);

    void onDownloadError(String error);

    void onDownloadFinished(String filePath);

    void onDownloadStarted();

}
