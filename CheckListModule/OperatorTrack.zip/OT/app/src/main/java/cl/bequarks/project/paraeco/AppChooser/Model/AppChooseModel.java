package cl.bequarks.project.paraeco.AppChooser.Model;

import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.R;

public class AppChooseModel implements IAppChooseModel {

    private ArrayList<String> appNames;
    private HashMap<Integer,String> appServerByName;

    private AlertDialog appChooserDialog;

    private IChooseStatusListener listener;

    @Override
    public void askUserApp(ViewGroup root , IChooseStatusListener listener) {

        AlertDialog.Builder builder = initDialog(root);
        appChooserDialog = builder.create();
        appChooserDialog.show();
        this.listener = listener;
    }

    @Override
    public void setAppInfo(int position) {
        listener.onAppChoosen();
        appChooserDialog.dismiss();
        Toast.makeText(G.context, appServerByName.get(position), Toast.LENGTH_SHORT).show();
    }

    @Override
    public AlertDialog.Builder initDialog(ViewGroup root) {
        AlertDialog.Builder builder = new AlertDialog.Builder(G.context);

        try {
            builder.setCancelable(false);
            View view = LayoutInflater.from(G.context)
                    .inflate(R.layout.layout_choose_app, root, false);

            Spinner appsSpinner = view.findViewById(R.id.appsSpinner);
            Button chooseApp = view.findViewById(R.id.chooseApp);

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(G.context, android.R.layout.simple_list_item_1, getAppNames());

            appsSpinner.setAdapter(adapter);

            final int[] choosenIndex = {0};

            appsSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    choosenIndex[0] = position;
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            chooseApp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    setAppInfo(choosenIndex[0]);
                }
            });
        }catch (Exception e){
            e.printStackTrace();
        }

        return builder;
    }

    @Override
    public ArrayList<String> getAppNames() {
        appNames = new ArrayList<>();
        appServerByName = new HashMap<>();
        appNames.add("Disney");
        appNames.add("Movistar");
        appNames.add("Sparta");
        appNames.add("Mimagen");
        appServerByName.put(0,"http://track.bequarks.cl");
        appServerByName.put(1,"http://movistar.bequarks.cl");
        appServerByName.put(2,"http://sparta.bequarks.cl");
        appServerByName.put(3,"http://mimagen.bequarks.cl");
        return appNames;
    }

}
