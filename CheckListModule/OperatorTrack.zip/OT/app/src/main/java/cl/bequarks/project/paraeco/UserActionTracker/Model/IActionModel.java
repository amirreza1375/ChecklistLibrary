package cl.bequarks.project.paraeco.UserActionTracker.Model;

public interface IActionModel {
}
