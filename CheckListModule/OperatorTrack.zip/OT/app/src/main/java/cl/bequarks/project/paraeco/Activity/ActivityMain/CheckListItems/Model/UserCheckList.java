package cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.checklist.PictureElement.PicturePickerItemModel;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.View.IDBCheckListResultView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBArrayResultView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBResultView;
import cl.bequarks.project.paraeco.DBHelper.FeedReaderContract;
import cl.bequarks.project.paraeco.DBHelper.RunTimeTableDBHelper;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.sharedpreference.Config;

import static cl.bequarks.project.paraeco.sharedpreference.Config.getUser;
import static cl.bequarks.project.paraeco.sharedpreference.Config.getUserId;

public class UserCheckList implements ICheckListData {

    private static final String TAG = "UserCheckList";

    //region values
    private long _ID;//1
    private String checkListJson;//2
    private String answerJson;//3
    private int isSynced;//4
    private int isDraft;//5
    private String time;//6
    private String date;//7
    private String shop_name;//8
    private String checkList_name;//9
    private String shop_id;//10
    private String checkList_id;//11
    private String start_time;//12
    private String end_time;//13
    private double server_id;//14
    private int isProccessing;//15
    private String userEmail;//16
    private int isPicsSynced;//17
    private String serverLink;//18
    private String errors;//19
    private int pagePosition;//20
    private int deleted;//21
    private int isTicket = 0;//22
    //endregion

    //region constructors
    public UserCheckList() {

    }


    public UserCheckList(String checkListJson, String answerJson, int isSynced, int isDraft, String time, String date, String shop_name, String checkList_name, String shop_id, String checkList_id, String start_time, String end_time, double server_id, int isProccessing, String userEmail, int isPicsSynced, String serverLink, String errors, int pagePosition, int deleted) {
        this.checkListJson = checkListJson;
        this.answerJson = answerJson;
        this.isSynced = isSynced;
        this.isDraft = isDraft;
        this.time = time;
        this.date = date;
        this.shop_name = shop_name;
        this.checkList_name = checkList_name;
        this.shop_id = shop_id;
        this.checkList_id = checkList_id;
        this.start_time = start_time;
        this.end_time = end_time;
        this.server_id = server_id;
        this.isProccessing = isProccessing;
        this.userEmail = userEmail;
        this.isPicsSynced = isPicsSynced;
        this.serverLink = serverLink;
        this.errors = errors;
        this.pagePosition = pagePosition;
        this.deleted = deleted;
    }
    //endregion

    //region useful methods

    /**
     * insert by the model class given and callBack give the result
     *
     * @param checklist
     * @param callBack
     * @return
     */
    public long insert(UserCheckList checklist, IDBInsertResult callBack) {


        createTable();

        ContentValues values = getValuesFromItem(checklist);
        SQLiteDatabase db = getUserCheckListTableDB();
        long newRowId = db.insert(FeedReaderContract.UserChecklistTable.TABLE_NAME, null, values);

        if (newRowId == -1)
            callBack.onFail("");
        else
            callBack.onSuccess(newRowId);

        db.close();
        return newRowId;
    }


    /**
     * Create {@link cl.bequarks.project.paraeco.DBHelper.FeedReaderContract.UserChecklistTable} table
     * and {@link cl.bequarks.project.paraeco.DBHelper.FeedReaderContract.PictureTable}
     * if not exist and method {@link RunTimeTableDBHelper} -> (isTableExists) calls this
     * if returns false
     */
    private void createTable() {
        RunTimeTableDBHelper dbHelper = getDBHelperInstance();

        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        if (!dbHelper.isTableExists(FeedReaderContract.UserChecklistTable.TABLE_NAME, true)) {
            db.execSQL(FeedReaderContract.UserChecklistTable.SQL_CREATE_ENTRIES);
            db.execSQL(FeedReaderContract.PictureTable.SQL_CREATE_ENTRIES);
        }
        db.close();

    }


    /**
     * @param id
     * @return
     */
    public UserCheckList fetchById(long id) {
        RunTimeTableDBHelper dbHelper = getDBHelperInstance();

        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.UserChecklistTable.TABLE_NAME
                + " where " + FeedReaderContract.UserChecklistTable._ID + "='" + id + "'", null);
        cursor.moveToNext();
        db.close();
        return getItemByCursor(cursor);
    }

    /**
     * @return {@link SQLiteDatabase}
     */
    public SQLiteDatabase getUserCheckListTableDB() {

        RunTimeTableDBHelper dbHelper = getDBHelperInstance();

        // Gets the data repository in write mode
        return dbHelper.getWritableDatabase();
    }

    /**
     * gets data from cursor and creates {@link UserCheckList}
     *
     * @param cursor
     * @return UserCehckList
     */
    public UserCheckList getItemByCursor(Cursor cursor) {
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                try {
                    long ID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable._ID));
                    String checklistJson = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.checkListJson));
                    String answerJson = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.answerJson));
                    String time = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.time));
                    String date = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.date));
                    String shopName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.shop_name));
                    String checklistName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.checkList_name));
                    String shopId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.shop_id));
                    String checklistId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.checkList_id));
                    String startTime = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.start_time));
                    String endTime = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.end_time));
                    int serverId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.server_id));
                    String userEmail = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.userEmail));
                    String serverLink = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.serverLink));
                    String errors = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.errors));
                    int pagePosition = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.pagePosition));
                    int isPicsSynced = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.isPicsSynced));
                    int isDeleted = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.isDeleted));
                    int isSynced = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.isSynced));
                    int isDraft = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.isDraft));
                    int isProccessing = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.isProccessing));
                    int isTicket = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.isTicket));

                    UserCheckList checklist = new UserCheckList(checklistJson, answerJson, isSynced, isDraft, time, date, shopName
                            , checklistName, shopId, checklistId, startTime, endTime, serverId, isProccessing, userEmail, isPicsSynced
                            , serverLink, errors, pagePosition, isDeleted);
                    checklist.setIsTicket(isTicket);
                    checklist.set_ID(ID);
                    cursor.close();
                    return checklist;
                }catch (Exception e){
                    e.printStackTrace();
                }finally {
                    cursor.close();
                }
            }
        }
        return new UserCheckList();
    }

    /**
     * Same as uper method just to user in cursor parse to close cursor
     * @param cursor
     * @return
     */

    public UserCheckList getItemsForCursor(Cursor cursor){
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                long ID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable._ID));
                String checklistJson = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.checkListJson));
                String answerJson = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.answerJson));
                String time = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.time));
                String date = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.date));
                String shopName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.shop_name));
                String checklistName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.checkList_name));
                String shopId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.shop_id));
                String checklistId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.checkList_id));
                String startTime = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.start_time));
                String endTime = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.end_time));
                int serverId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.server_id));
                String userEmail = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.userEmail));
                String serverLink = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.serverLink));
                String errors = cursor.getString(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.errors));
                int pagePosition = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.pagePosition));
                int isPicsSynced = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.isPicsSynced));
                int isDeleted = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.isDeleted));
                int isSynced = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.isSynced));
                int isDraft = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.isDraft));
                int isProccessing = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.isProccessing));
                int isTicket = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.UserChecklistTable.isTicket));


                UserCheckList checklist = new UserCheckList(checklistJson, answerJson, isSynced, isDraft, time, date, shopName
                        , checklistName, shopId, checklistId, startTime, endTime, serverId, isProccessing, userEmail, isPicsSynced
                        , serverLink, errors, pagePosition, isDeleted);
                checklist.setIsTicket(isTicket);
                checklist.set_ID(ID);
                return checklist;
            }
        }
        return new UserCheckList();
    }

    /**
     * Runs a SELECT ALL query and return all rows in {@link ArrayList<UserCheckList>}
     *
     * @return
     */
    public ArrayList<UserCheckList> getAllItems() {
        RunTimeTableDBHelper dbHelper = getDBHelperInstance();
//
        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.UserChecklistTable.TABLE_NAME, null);



        return getItemsByCursor(cursor);
    }

    /**
     * Take cursor from select all or multiple row select and return {@link ArrayList<UserCheckList>}
     *
     * @param cursor
     * @return
     */
    public ArrayList<UserCheckList> getItemsByCursor(Cursor cursor) {

        try {
            ArrayList<UserCheckList> userCheckLists = new ArrayList<>();
            if (cursor.moveToFirst()) {
                while (!cursor.isAfterLast()) {

                    userCheckLists.add(getItemsForCursor(cursor));

                    cursor.moveToNext();
                }
            }

            cursor.close();

            return userCheckLists;
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            cursor.close();
        }
        return new ArrayList<>();
    }

    /**
     * converts items to {@link ContentValues}
     * so with that can insert or update row
     *
     * @param checklist
     * @return
     */
    public ContentValues getValuesFromItem(UserCheckList checklist) {
        ContentValues values = new ContentValues();
        values.put(FeedReaderContract.UserChecklistTable.checkListJson, checklist.getCheckListJson());//1
        values.put(FeedReaderContract.UserChecklistTable.answerJson, checklist.getAnswerJson());//2
        values.put(FeedReaderContract.UserChecklistTable.time, checklist.getTime());//3
        values.put(FeedReaderContract.UserChecklistTable.date, checklist.getDate());//4
        values.put(FeedReaderContract.UserChecklistTable.shop_name, checklist.getShop_name());//5
        values.put(FeedReaderContract.UserChecklistTable.checkList_name, checklist.getCheckList_name());//6
        values.put(FeedReaderContract.UserChecklistTable.shop_id, checklist.getShop_id());//7
        values.put(FeedReaderContract.UserChecklistTable.checkList_id, checklist.getCheckList_id());//8
        values.put(FeedReaderContract.UserChecklistTable.start_time, checklist.getStart_time());//9
        values.put(FeedReaderContract.UserChecklistTable.end_time, checklist.getEnd_time());//10
        values.put(FeedReaderContract.UserChecklistTable.server_id, checklist.getServer_id());//11
        values.put(FeedReaderContract.UserChecklistTable.userEmail, checklist.getUserEmail());//12
        values.put(FeedReaderContract.UserChecklistTable.serverLink, checklist.getServerLink());//13
        values.put(FeedReaderContract.UserChecklistTable.errors, checklist.getErrors());//14
        values.put(FeedReaderContract.UserChecklistTable.pagePosition, checklist.getPagePosition());//15
        values.put(FeedReaderContract.UserChecklistTable.isPicsSynced, checklist.isPicsSynced());//16
        values.put(FeedReaderContract.UserChecklistTable.isDeleted, checklist.isDeleted());//17
        values.put(FeedReaderContract.UserChecklistTable.isSynced, checklist.isSynced());//18
        values.put(FeedReaderContract.UserChecklistTable.isDraft, checklist.isDraft());//19
        values.put(FeedReaderContract.UserChecklistTable.isProccessing, checklist.isProccessing());//20
        values.put(FeedReaderContract.UserChecklistTable.isTicket, checklist.getIsTicket());//21
        return values;
    }


    /**
     * update row with new data (When is draft and user changes draft data or make it sync)
     *
     * @param userCheckList
     */
    public void update(UserCheckList userCheckList) {
        RunTimeTableDBHelper dbHelper = getDBHelperInstance();


        ContentValues values = getValuesFromItem(userCheckList);
        final SQLiteDatabase db = dbHelper.getWritableDatabase();
        int res = db.update(FeedReaderContract.UserChecklistTable.TABLE_NAME, values, FeedReaderContract.UserChecklistTable._ID + "=" + userCheckList.get_ID(), null);


        db.close();

        Log.i(TAG, "update: " + res);

    }

    public void updateItem(UserCheckList userCheckList,IDBInsertResult callBack){
        RunTimeTableDBHelper dbHelper = getDBHelperInstance();


        ContentValues values = getValuesFromItem(userCheckList);
        final SQLiteDatabase db = dbHelper.getWritableDatabase();
        int res = db.update(FeedReaderContract.UserChecklistTable.TABLE_NAME, values, FeedReaderContract.UserChecklistTable._ID + "=" + userCheckList.get_ID(), null);

        callBack.onSuccess(res);
        db.close();

        Log.i(TAG, "update: " + res);
    }

    private RunTimeTableDBHelper getDBHelperInstance(){
        return new RunTimeTableDBHelper(G.context);
    }

    /**
     * Runs SELECT Query with USER,DATE,SERVER and NOTDELETED conditions
     * and callBack gives the reuslt
     *
     * @param user
     * @param date
     * @param checkListDataIDBArrayResultView
     */
    @Override
    public void fetchByUserAndDate(String user, String date, IDBArrayResultView<UserCheckList> checkListDataIDBArrayResultView) {
        RunTimeTableDBHelper dbHelper = getDBHelperInstance();
//
        // Gets the data repository in write mode


        if (dbHelper.isTableExists(FeedReaderContract.UserChecklistTable.TABLE_NAME, true)) {

            String SQL = "SELECT *  FROM " + FeedReaderContract.UserChecklistTable.TABLE_NAME
                    + " WHERE " + FeedReaderContract.UserChecklistTable.serverLink + "='" + Config.getServer(G.context)
                    + "' AND " + FeedReaderContract.UserChecklistTable.date + "='" + date
                    + "' AND " + FeedReaderContract.UserChecklistTable.isDeleted + "='" + 0
                    + "' AND (" + FeedReaderContract.UserChecklistTable.userEmail + "='" + getUserId(G.context)
                    + "' OR " + FeedReaderContract.UserChecklistTable.userEmail + "='" + user+"')";
            final SQLiteDatabase db = dbHelper.getWritableDatabase();
            Cursor cursor = db.rawQuery(SQL, null);
            ArrayList<UserCheckList> userCheckLists = getItemsByCursor(cursor);
            cursor.close();
            if (userCheckLists.size() == 0) {
                checkListDataIDBArrayResultView.onFail("No checklist");
            } else {
                checkListDataIDBArrayResultView.onSuccess(userCheckLists);
            }
        }else {
            createTable();
        }
    }

    /**
     * just calls FETCHBYID method and converts result to {@link UserCheckList}
     *
     * @param id
     * @param idbCheckListResultView
     */
    @Override
    public void fetchCheckListById(long id, IDBCheckListResultView<UserCheckList> idbCheckListResultView) {
        UserCheckList userCheckListDB = fetchById(id);
        if (userCheckListDB == null) {
            idbCheckListResultView.onFail("");
        } else {
            UserCheckList userCheckList = new UserCheckList(userCheckListDB.getCheckListJson(), userCheckListDB.getAnswerJson()
                    , userCheckListDB.isSynced(), userCheckListDB.isDraft(), userCheckListDB.getTime(), userCheckListDB.getDate()
                    , userCheckListDB.getShop_name(), userCheckListDB.getCheckList_name(), userCheckListDB.getShop_id()
                    , userCheckListDB.getCheckList_id(), userCheckListDB.getStart_time(), userCheckListDB.getEnd_time()
                    , userCheckListDB.getServer_id(), userCheckListDB.isProccessing(), userCheckListDB.getUserEmail()
                    , userCheckListDB.isPicsSynced(), cl.bequarks.project.paraeco.sharedpreference.Config.getServer(G.context), ""
                    , userCheckListDB.getPagePosition()
                    , userCheckListDB.isDeleted());

            idbCheckListResultView.onSuccess(userCheckList);
        }
    }

    /**
     * Fetchs {@link UserCheckList} by id and gets all {@link ResultPicture}
     * with related id
     *
     * @param id
     * @param idbCheckListAndPicturesResultView
     */
    @Override
    public void fetchCheckListAndPicturesById(long id, final IDBCheckListAndPicturesResultView<UserCheckList> idbCheckListAndPicturesResultView) {

        final UserCheckList userCheckList = fetchById(id);

        new ResultPicture().fetchByCheckListId(id, new IDBArrayResultView<ResultPicture>() {
            @Override
            public void onSuccess(ArrayList<ResultPicture> results) {
                idbCheckListAndPicturesResultView.onSuccess(userCheckList, new ResultPicture().convertPickerArrayToPictureArray(results));
            }

            @Override
            public void onFail(String error) {
                idbCheckListAndPicturesResultView.onSuccess(userCheckList, new ArrayList<PicturePickerItemModel>());
            }
        });
    }

    /**
     * Runs query with SELECT USER and DELETED conditions
     *
     * @param user
     * @param callBack
     */
    @Override
    public void fetchDeletedItems(String user, IDBArrayResultView<UserCheckList> callBack) {
        RunTimeTableDBHelper dbHelper = getDBHelperInstance();



        if (dbHelper.isTableExists(FeedReaderContract.UserChecklistTable.TABLE_NAME, true)) {

            String SQL = "SELECT *  FROM " + FeedReaderContract.UserChecklistTable.TABLE_NAME
                    + " WHERE " + FeedReaderContract.UserChecklistTable.serverLink + "='" + Config.getServer(G.context)
                    + "' AND " + FeedReaderContract.UserChecklistTable.isDeleted + "='" + 1
                    + "' AND (" + FeedReaderContract.UserChecklistTable.userEmail + "='" + getUserId(G.context)
                    + "' OR " + FeedReaderContract.UserChecklistTable.userEmail + "='" + user+"')";
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            Cursor cursor = db.rawQuery(SQL, null);

            ArrayList<UserCheckList> userCheckLists = getItemsByCursor(cursor);
            cursor.close();
            db.close();
            if (userCheckLists.size() == 0)
                callBack.onFail("No deleted checkList");
            else
                callBack.onSuccess(userCheckLists);

        } else {
            createTable();
        }

    }

    /**
     * Remove all rows with DELETED condition
     *
     * @param resultView
     */
    @Override
    public void removeAllDeleteds(IDBResultView resultView) {
        RunTimeTableDBHelper dbHelper = getDBHelperInstance();



        if (dbHelper.isTableExists(FeedReaderContract.UserChecklistTable.TABLE_NAME, true)) {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            db.delete(FeedReaderContract.UserChecklistTable.TABLE_NAME
                    , FeedReaderContract.UserChecklistTable.isDeleted + "=" + 1, null);

            resultView.onSuccess();
            db.close();
        } else {
            createTable();
        }

    }

    @Override
    public ArrayList<UserCheckList> fetchNotDeletedItems() {
        RunTimeTableDBHelper dbHelper = getDBHelperInstance();



        if (dbHelper.isTableExists(FeedReaderContract.UserChecklistTable.TABLE_NAME, true)) {

            String SQL = "SELECT *  FROM " + FeedReaderContract.UserChecklistTable.TABLE_NAME
                    + " WHERE " + FeedReaderContract.UserChecklistTable.serverLink + "='" + Config.getServer(G.context)
                    + "' AND " + FeedReaderContract.UserChecklistTable.isDeleted + "='" + 0
                    + "' AND (" + FeedReaderContract.UserChecklistTable.userEmail + "='" + getUserId(G.context)
                    + "' OR " + FeedReaderContract.UserChecklistTable.userEmail + "='" + getUser(G.context)+"')";
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            Cursor cursor = db.rawQuery(SQL, null);

            ArrayList<UserCheckList> userCheckLists = getItemsByCursor(cursor);
            cursor.close();
            db.close();
            return userCheckLists;

        } else {
            createTable();
        }


        return new ArrayList<>();

    }

    @Override
    public long getLastRowId() {

        RunTimeTableDBHelper dbHelper = getDBHelperInstance();



        if (dbHelper.isTableExists(FeedReaderContract.UserChecklistTable.TABLE_NAME, true)) {

            String SQL = "SELECT * FROM UserChecklistTable WHERE _id = (SELECT MAX(_id) FROM UserChecklistTable)";
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            Cursor cursor = db.rawQuery(SQL, null);

            UserCheckList userCheckLists = getItemByCursor(cursor);
            db.close();
            return 0;

        } else {
            createTable();
        }

        return 0;
    }

    public ArrayList<UserCheckList> getNotSyncedInProcess() {

        RunTimeTableDBHelper dbHelper = getDBHelperInstance();



        if (dbHelper.isTableExists(FeedReaderContract.UserChecklistTable.TABLE_NAME, true)) {

            String SQL = "SELECT * FROM " + FeedReaderContract.UserChecklistTable.TABLE_NAME
                    + " where " + FeedReaderContract.UserChecklistTable.isSynced + "='" + 0
                    + "' AND " + FeedReaderContract.UserChecklistTable.isProccessing + "='" + 1+"'";
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            Cursor cursor = db.rawQuery(SQL, null);
            ArrayList<UserCheckList> userCheckLists = getItemsByCursor(cursor);
            db.close();
            return userCheckLists;


        } else {
            createTable();
        }


        return new ArrayList<>();

    }

    @Override
    public boolean deleteUserData(UserCheckList userCheckList) {

        RunTimeTableDBHelper dbHelper = getDBHelperInstance();

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        boolean res =  db.delete(FeedReaderContract.UserChecklistTable.TABLE_NAME
                , FeedReaderContract.UserChecklistTable._ID + "=" + userCheckList.get_ID()
                , null) > 0;
        db.close();

        return res;

    }

    /**
     *******         TICKETS          ********
     *  */

    //endregion

    //region getter setter
    public String getCheckListJson() {
        return checkListJson;
    }

    public void setCheckListJson(String checkListJson) {
        this.checkListJson = checkListJson;
    }

    public String getAnswerJson() {
        return answerJson;
    }

    public void setAnswerJson(String answerJson) {
        this.answerJson = answerJson;
    }

    public int isSynced() {
        return isSynced;
    }

    public void setSynced(int synced) {
        isSynced = synced;
    }

    public int isDraft() {
        return isDraft;
    }

    public void setDraft(int draft) {
        isDraft = draft;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getShop_name() {
        return shop_name;
    }

    public void setShop_name(String shop_name) {
        this.shop_name = shop_name;
    }

    public String getCheckList_name() {
        return checkList_name;
    }

    public void setCheckList_name(String checkList_name) {
        this.checkList_name = checkList_name;
    }

    public String getShop_id() {
        return shop_id;
    }

    public void setShop_id(String shop_id) {
        this.shop_id = shop_id;
    }

    public String getCheckList_id() {
        return checkList_id;
    }

    public void setCheckList_id(String checkList_id) {
        this.checkList_id = checkList_id;
    }

    public String getStart_time() {
        return start_time;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public String getEnd_time() {
        return end_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    public double getServer_id() {
        return server_id;
    }

    public void setServer_id(double server_id) {
        this.server_id = server_id;
    }

    public int isProccessing() {
        return isProccessing;
    }

    public void setProccessing(int proccessing) {
        isProccessing = proccessing;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public int isPicsSynced() {
        return isPicsSynced;
    }

    public void setPicsSynced(int picsSynced) {
        isPicsSynced = picsSynced;
    }

    public String getServerLink() {
        return serverLink;
    }

    public void setServerLink(String serverLink) {
        this.serverLink = serverLink;
    }

    public String getErrors() {
        return errors;
    }

    public void setErrors(String errors) {
        this.errors = errors;
    }

    public int isDeleted() {
        return deleted;
    }

    public void setDeleted(int deleted) {
        this.deleted = deleted;
    }

    public int getPagePosition() {
        return pagePosition;
    }

    public void setPagePosition(int pagePosition) {
        this.pagePosition = pagePosition;
    }

    public long get_ID() {
        return _ID;
    }

    public void set_ID(long _ID) {
        this._ID = _ID;
    }

    public int getIsTicket() {
        return isTicket;
    }

    public void setIsTicket(int isTicket) {
        this.isTicket = isTicket;
    }


    //endregion
}