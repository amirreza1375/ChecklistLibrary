package cl.bequarks.project.paraeco.Notification.Presenter;

import cl.bequarks.project.paraeco.Notification.Model.NotificationModel;
import cl.bequarks.project.paraeco.Notification.View.INotificationView;

public class NotificationPresenter implements INotificationPresenter {

    private NotificationModel model;
    private INotificationView view;

    public NotificationPresenter(NotificationModel model, INotificationView view){
        this.model = model;
        this.view = view;

        model.createNotificationChannel();

    }

    @Override
    public void showNotification() {
        model.showNotification(model.sendNotification());
    }
}
