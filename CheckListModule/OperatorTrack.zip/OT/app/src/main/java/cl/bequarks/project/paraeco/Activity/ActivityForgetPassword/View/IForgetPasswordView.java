package cl.bequarks.project.paraeco.Activity.ActivityForgetPassword.View;

public interface IForgetPasswordView {
    void OnValidEmail();
    void OnInvalidEmail();
    void OnRequestSuccess(String answer);
    void OnRequestFailed(String error);

}