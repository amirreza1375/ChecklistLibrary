package cl.bequarks.project.paraeco.ServerRequests;

/**
 * Created by shahr on 2/20/2019.
 */

public interface IResponseServerToApiForUploadImageProfile {
    void onUpload(String message);
    void onNetworkError(String message);
}
