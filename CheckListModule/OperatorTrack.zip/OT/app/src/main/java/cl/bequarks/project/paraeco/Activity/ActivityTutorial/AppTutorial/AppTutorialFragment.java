package cl.bequarks.project.paraeco.Activity.ActivityTutorial.AppTutorial;

import android.content.Context;
import android.graphics.PointF;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.github.clans.fab.FloatingActionMenu;
import com.takusemba.spotlight.OnSpotlightEndedListener;
import com.takusemba.spotlight.OnSpotlightStartedListener;
import com.takusemba.spotlight.OnTargetStateChangedListener;
import com.takusemba.spotlight.SimpleTarget;
import com.takusemba.spotlight.Spotlight;

import cl.bequarks.project.paraeco.R;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link AppTutorialFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link AppTutorialFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AppTutorialFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private LinearLayout emptyBox;
    private Button calendar_btn;
    private FloatingActionMenu menu;
    private LinearLayout network_status;
    private LinearLayout searchLinear;

    private OnFragmentInteractionListener mListener;



    public AppTutorialFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AppTutorialFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AppTutorialFragment newInstance(String param1, String param2) {
        AppTutorialFragment fragment = new AppTutorialFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        network_status = view.findViewById(R.id.network_status);
        emptyBox = view.findViewById(R.id.emptybox);
        calendar_btn = view.findViewById(R.id.calendar_btn);
        menu = view.findViewById(R.id.menu);
        searchLinear = view.findViewById(R.id.search_linear);

        network_status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startTutorial();
            }
        });

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                network_status.performClick();
            }
        },1000);

    }

    public void startTutorial() {

        SimpleTarget first =
                new SimpleTarget.Builder(getActivity()).setPoint(calendar_btn)
                        .setRadius(200f)
                        .setTitle("Calendar")
                        .setDescription("You can filter results with date with this button")
                        .build();
        SimpleTarget second =
                new SimpleTarget.Builder(getActivity()).setPoint(emptyBox)
                        .setRadius(500f)
                        .setTitle("Result section")
                        .setDescription("Here you can see your results as sent or draft")
                        .build();
        SimpleTarget third =
                new SimpleTarget.Builder(getActivity()).setPoint(network_status)
                        .setRadius(200f)
                        .setTitle("Network status")
                        .setDescription("Here you can see if you are connected to any network or not (for sync or update data you need to be connected)")
                        .build();
        SimpleTarget forth =
                new SimpleTarget.Builder(getActivity()).setPoint(searchLinear)
                        .setRadius(200f)
                        .setTitle("Search")
                        .setDescription("Here you can search in results by checklist name or shop name")
                        .build();

        int[] twoLocation = new int[2];
        menu.getLocationInWindow(twoLocation);
        PointF point =
                new PointF(twoLocation[0] + menu.getWidth() / 2f, twoLocation[1] + menu.getHeight() / 2f);
        SimpleTarget fifth = new SimpleTarget.Builder(getActivity()).setPoint(point)
                .setRadius(300f)
                .setTitle("FAB")
                .setDescription("You can choose which type of survey you want to submit")
                .setOnSpotlightStartedListener(new OnTargetStateChangedListener<SimpleTarget>() {
                    @Override
                    public void onStarted(SimpleTarget target) {

                    }

                    @Override
                    public void onEnded(SimpleTarget target) {
                        menu.open(true);
                    }
                })
                .build();

        SimpleTarget sixth = new SimpleTarget.Builder(getActivity()).setPoint(point)
                .setRadius(150f)
                .setTitle("Types")
                .setDescription("By pressing one of types you can load shop then survey to submit")
                .setOnSpotlightStartedListener(new OnTargetStateChangedListener<SimpleTarget>() {
                    @Override
                    public void onStarted(SimpleTarget target) {

                    }

                    @Override
                    public void onEnded(SimpleTarget target) {
                        mListener.onAppTutorialFinished();
                    }
                })
                .build();

//            SimpleTarget seventh =
//                    new SimpleTarget.Builder(this).setPoint(findViewById(R.id.imgInventory))
//                            .setRadius(200f)
//                            .setTitle(getString(R.string.check_list))
//                            .setDescription("You can see your result in this section")
//                            .build();
//            SimpleTarget eighth =
//                    new SimpleTarget.Builder(this).setPoint(findViewById(R.id.imgUpdate))
//                            .setRadius(200f)
//                            .setTitle(getString(R.string.update))
//                            .setDescription("You can update your data with web changes (App  automaticly updates if any change happens in web)")
//                            .build();
//            SimpleTarget ninth =
//                    new SimpleTarget.Builder(this).setPoint(findViewById(R.id.imgSettings))
//                            .setRadius(200f)
//                            .setTitle(getString(R.string.setting))
//                            .setDescription("You can change your password or profile picture here")
//                            .build();
//            SimpleTarget tenth =
//                    new SimpleTarget.Builder(this).setPoint(findViewById(R.id.imgShops))
//                            .setRadius(200f)
//                            .setTitle(getString(R.string.fragment_shop_title))
//                            .setDescription("You can see all shops that assigned to you (You can make sure that you have the shop you want or not here)")
//                            .build();
//            SimpleTarget eleventh =
//                    new SimpleTarget.Builder(this).setPoint(findViewById(R.id.imgAbout))
//                            .setRadius(200f)
//                            .setTitle(getString(R.string.about))
//                            .setDescription("Here we are")
//                            .build();
//            SimpleTarget twelwth =
//                    new SimpleTarget.Builder(this).setPoint(findViewById(R.id.imgTrash))
//                            .setRadius(200f)
//                            .setTitle(getString(R.string.deleted))
//                            .setDescription("When you delete item will appear in this section you can delete items here (When you delete items in here you can not get them back anymore)")
//                        .build();
//        SimpleTarget thirteenth =
//                new SimpleTarget.Builder(this).setPoint(findViewById(R.id.imgExit))
//                        .setRadius(200f)
//                        .setTitle(getString(R.string.log_out))
//                        .setDescription("Log out from your account")
//                        .build();

        Spotlight.with(getActivity())
                .setDuration(1L)
                .setAnimation(new DecelerateInterpolator(2f))
                .setTargets(first,second,third,forth,fifth,sixth)
                .setOnSpotlightStartedListener(new OnSpotlightStartedListener() {
                    @Override
                    public void onStarted() {
//                        Toast.makeText(ActivityMain.this, "spotlight is started", Toast.LENGTH_SHORT)
//                                .show();
                    }
                })
                .setOnSpotlightEndedListener(new OnSpotlightEndedListener() {
                    @Override
                    public void onEnded() {
//                        Toast.makeText(ActivityMain.this, "spotlight is ended", Toast.LENGTH_SHORT).show();
                    }
                })
                .start();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_app_tutorial, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
//    public void onButtonPressed(Uri uri) {
//        if (mListener != null) {
//            mListener.onFragmentInteraction(uri);
//        }
//    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onAppTutorialFinished();
    }
}
