package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBArrayResultView;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBResultView;
import cl.bequarks.project.paraeco.DBHelper.FeedReaderContract;
import cl.bequarks.project.paraeco.DBHelper.TableDbHelper;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.Global.GPSTracker;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Shop extends DBModelBaseTemp<Shop> implements IShop {

    private static final String TAG = "Shop";


    public static String config_adress = "address";
    public static String config_canal_id = "canal_id";
    public static String config_city = "city";
    public static String config_country = "country";
    public static String config_img = "img";
    public static String config_lat = "lat";
    public static String config_lat_long = "long";
    public static String config_logo = "logo";
    public static String config_retail_id = "retail_id";
    public static String config_retail_name = "retail_name";
    public static String config_shop_id = "shop_id";
    public static String config_shop_name = "shop_name";
    public static String config_state = "state";
    public static String config_subcanal_id = "subcanal_id";
    public static String config_type = "type";
    public static String config_user_id = "user_id";
    public static String config_zones = "zones";
    private static String config_surveyType = "type_survey";


    //region Fields of DB
    private int canal_id;
    private String city;
    private String country;
    private String img;
    private Double lat;
    private Double lat_long;
    private String logo;
    private int retail_id;
    private String retail_name;
    private int shop_id;
    private String shop_name;
    private String state;
    private int subcanal_id;
    private String type;
    private int user_id;
    private String zone;
    private String address;
    private String surveyTypes;
    private String fullName;
    //endregion

    //region Constructor
    public Shop(int shop_id, int retail_id, String shop_name, Double lat,
                Double lat_long, String img, String address, String state,
                String zone, int canal_id, int subcanal_id, String city,
                String country, int user_id, String type, String retail_name,
                String logo, String surveyTypes, String fullName
    ) {
        this.shop_id = shop_id;
        this.retail_id = retail_id;
        this.shop_name = shop_name;
        this.lat = lat;
        this.lat_long = lat_long;
        this.img = img;
        this.address = address;
        this.state = state;
        this.zone = zone;
        this.canal_id = canal_id;
        this.subcanal_id = subcanal_id;
        this.city = city;
        this.country = country;
        this.user_id = user_id;
        this.type = type;
        this.retail_name = retail_name;
        this.logo = logo;
        this.surveyTypes = surveyTypes;
        this.fullName = fullName;
    }

    public Shop() {
    }

    @Override
    public SQLiteDatabase dropAndCreateTable() {
        TableDbHelper dbHelper = TableDbHelper.getInstanceShop(G.context);
//
        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL(FeedReaderContract.ShopTable.SQL_DELETE_ENTRIES);
        db.execSQL(FeedReaderContract.ShopTable.SQL_CREATE_ENTRIES);
        return db;
    }
    //endregion

    //region IShop
    @Override
    public int getShopId() {
        return this.shop_id;
    }

    @Override
    public void setShopId(int shopId) {
        this.shop_id = shopId;
    }

    @Override
    public int getRetailId() {
        return this.retail_id;
    }

    @Override
    public String getShopName() {
        return this.shop_name;
    }

    @Override
    public void setShopName(String shopName) {
        this.shop_name = shopName;
    }

    @Override
    public double getLat() {
        return this.lat;
    }

    @Override
    public void setLat(double lat) {
        this.lat = lat;
    }

    @Override
    public double getLong() {
        return this.lat_long;
    }

    @Override
    public void setLong(double lat_long) {
        this.lat_long = lat_long;
    }

    @Override
    public String getImg() {
        return this.img;
    }

    @Override
    public String getAdress() {
        return address;
    }

    @Override
    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String getState() {
        return this.state;
    }

    @Override
    public String getZone() {
        return this.zone;
    }

    @Override
    public int getCanalId() {
        return this.canal_id;
    }

    @Override
    public int getSubCanalId() {
        return this.subcanal_id;
    }

    @Override
    public String getCity() {
        return this.city;
    }

    @Override
    public String getCountry() {
        return this.country;
    }

    @Override
    public int getUserId() {
        return this.user_id;
    }

    @Override
    public String getType() {
        return this.type;
    }

    @Override
    public String getRetailName() {
        return this.retail_name;
    }

    @Override
    public void setRetailName(String retailName) {

    }

    public ArrayList<Shop> getShopsFromCursor(Cursor cursor, SQLiteDatabase db) {
        ArrayList<Shop> shops = new ArrayList<>();
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                int shopId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ShopTable.shop_id));
                String shoName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.shop_name));
                int retailId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ShopTable.retail_id));
                String retailName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.retail_name));
                String country = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.country));
                String state = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.state));
                String city = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.city));
                String adress = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.adress));
                String lat = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.lat));
                String latLng = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.lat_long));
                String img = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.img));
                String logo = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.logo));
                int canalId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ShopTable.canal_id));
                int subCanalId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ShopTable.subcanal_id));
                String type = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.type));
                int userId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ShopTable.user_id));
                String zone = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.zones));
                String surveyType = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.surveyType));
                String fullName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.fullName));
                Shop shop = new Shop(shopId, retailId, shoName, Double.valueOf(lat), Double.valueOf(latLng)
                        , img, adress, state, zone, canalId, subCanalId, city, country, userId, type, retailName, logo, surveyType
                        , fullName);

                shops.add(shop);

                cursor.moveToNext();
            }
        }
//        db.close();
        return shops;
    }

    public ArrayList<Shop> getShopByNameLike(String key) {
        TableDbHelper dbHelper = TableDbHelper.getInstanceShop(G.context);

//
        // Gets the data repository in write mode
        if (dbHelper.isTableExists(FeedReaderContract.ShopTable.TABLE_NAME, true)) {
            final SQLiteDatabase db = dbHelper.getWritableDatabase();

            int version = db.getVersion();

            Log.i(TAG, "getShopByNameLike: " + version);

            String query = "SELECT * FROM " + FeedReaderContract.ShopTable.TABLE_NAME + " where "
                    + FeedReaderContract.ShopTable.fullName + " like '%" + key + "%'";

            Cursor cursor = db.rawQuery(query, null);

            return getShopsFromCursor(cursor, db);
        } else {
            return new ArrayList<>();
        }
    }

    public ArrayList<Shop> getAllShops() {

        TableDbHelper dbHelper = TableDbHelper.getInstanceShop(G.context);
//
        // Gets the data repository in write mode
        if (dbHelper.isTableExists(FeedReaderContract.ShopTable.TABLE_NAME, true)) {
            final SQLiteDatabase db = dbHelper.getWritableDatabase();

            int version = db.getVersion();

            Log.i(TAG, "getShopByNameLike: " + version);


            Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.ShopTable.TABLE_NAME, null);
            return getShopsFromCursor(cursor, db);
        } else {
            return new ArrayList<>();
        }
    }

    @Override
    public String getLogo() {
        return this.logo;
    }

    @Override
    public ArrayList<Shop> fetchByLocation(double lat, double latlong) {

        List<Shop> shopDBS = getAllShops();
        ArrayList<Shop> filteredShops = new ArrayList();
        for (Shop shopDB : shopDBS) {
            double dis = getDistanceFromLatLonInKm(lat, latlong, shopDB.getLat(), shopDB.getLat_long());
            if (dis < 1) {
                filteredShops.add(shopDB);
            }
        }
        return filteredShops;
    }


    @Override
    public void fetchByCurrentLocation(final IDBArrayResultView<Shop> callBack) {


        GPSTracker.getInstance(G.context, new GPSTracker.GPSListener() {
            @Override
            public void onLocationTracked(double lat, double latLong) {

                List<Shop> shopDBS = getAllShops();
                ArrayList<Shop> filteredShops = new ArrayList();
                for (Shop shopDB : shopDBS) {
                    double dis = getDistanceFromLatLonInKm(lat, latLong, shopDB.getLat(), shopDB.getLat_long());
                    if (dis < 1) {
                        filteredShops.add(shopDB);
                    }
                }
                if (filteredShops.size() == 0) {
                    callBack.onFail("no shops");
                } else {
                    callBack.onSuccess(filteredShops);
                }

            }

            @Override
            public void onLocationError(String msg) {

            }
        }).getCurrentLocation();

    }

    @Override
    public ArrayList<Shop> fetchByLocationSubCanal(double lat, double latlong, int canal, int subCanal) {
        return null;
    }

    public Double getLat_long() {
        return this.lat_long;
    }
    //endregion


    private double getDistanceFromLatLonInKm(double lat1, double lon1, double lat2, double lon2) {
        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lon2 - lon1);
        double sindLat = Math.sin(dLat / 2.0d);
        dLat = Math.sin(dLng / 2.0d);
        double a = Math.pow(sindLat, 2.0d) + ((Math.pow(dLat, 2.0d) * Math.cos(Math.toRadians(lat1))) * Math.cos(Math.toRadians(lat2)));
        double d = 1.0d;
        dLat = 6371.0d * (Math.atan2(Math.sqrt(a), Math.sqrt(1.0d - a)) * 2.0d);
        double earthRadius = 6371.0d;
        if (lat2 < 0.0d && lon2 < 0.0d) {
            d = -1.0d;
        }
        double xr = d;
        return dLat - 0.07362716373246034d;
    }

    //region method of DB


    @Override
    public Shop getByJson(JSONObject json) {

        try {

            String retailName = json.has(Shop.config_retail_name) ? json.getString(Shop.config_retail_name) : "No retail name";
            String shopName = json.has(Shop.config_shop_name) ? json.getString(Shop.config_shop_name) : "No retail name";

            Shop shop = new Shop(
                    json.getInt(Shop.config_shop_id),
                    json.has(Shop.config_retail_id) ? json.getInt(Shop.config_retail_id) : 0,
                    shopName,
                    json.has(Shop.config_lat) ? json.getDouble(Shop.config_lat) : 0,
                    json.has(Shop.config_lat_long) ? json.getDouble(Shop.config_lat_long) : 0,
                    json.has(Shop.config_img) ? json.getString(Shop.config_img) : "No image",
                    json.has(Shop.config_adress) ? json.getString(Shop.config_adress) : "No adress",
                    json.has(Shop.config_state) ? json.getString(Shop.config_state) : "No state",
                    json.has(Shop.config_zones) ? json.getString(Shop.config_zones) : "No zone",
                    json.has(Shop.config_canal_id) ? json.getInt(Shop.config_canal_id) : -1,
                    json.has(Shop.config_subcanal_id) ? json.getInt(Shop.config_subcanal_id) : -1,
                    json.has(Shop.config_city) ? json.getString(Shop.config_city) : "No city",
                    json.has(Shop.config_country) ? json.getString(Shop.config_country) : "No country",
                    0,
                    json.has(Shop.config_type) ? json.getString(Shop.config_type) : "No type",
                    retailName,
                    json.has(Shop.config_logo) ? json.getString(Shop.config_logo) : "No logo",
                    json.has(Shop.config_surveyType) ? json.getString(config_surveyType) : "",
                    retailName + " " + shopName
            );
            return shop;
        } catch (JSONException e) {
            Toast.makeText(G.context, e.getMessage() + "", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            Shop shop = new Shop();
            shop.errorMessage = e.getMessage();
            return shop;
        }
    }

    @Override
    public void refreshTable(final JSONArray json, final IDBResultView callback) {
        final SQLiteDatabase db = dropAndCreateTable();
        new Thread(new Runnable() {
            @Override
            public void run() {
                Log.i(MODEL_TAG, "Shop -> Insert start");
//                db.beginTransaction();
                for (int i = 0; i < json.length(); i++) {
                    try {

                        Shop shop = getByJson(json.getJSONObject(i));
                        if (shop.getErrorMessage() == null) {
                            shop.insert(shop, db, callback);
                            callback.onItemInserted();
                        } else {
                            callback.onFail(shop.getErrorMessage());
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        callback.onFail("Shop have some problem");
                    }
                }
                Log.i(MODEL_TAG, "Shop -> Insert finished");
//                db.endTransaction();
//                db.close();
                callback.onSuccess();
            }
        }).start();
    }

    @Override
    public SQLiteDatabase getDataBaseConnection() {
        TableDbHelper dbHelper = TableDbHelper.getInstanceShop(G.context);
        return dbHelper.getWritableDatabase();
    }

    @Override
    public Shop fetchById(long id) {
        TableDbHelper dbHelper = TableDbHelper.getInstanceShop(G.context);

        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.ShopTable.TABLE_NAME
                + " where " + FeedReaderContract.ShopTable._ID + "='" + id + "'", null);
        cursor.moveToNext();
        return getItemByCursor(cursor);
    }

    @Override
    public long insert(Shop shop, SQLiteDatabase db, IDBResultView callBack) {

        ContentValues values = new ContentValues();
        values.put(FeedReaderContract.ShopTable.shop_id, shop.getShopId());
        values.put(FeedReaderContract.ShopTable.shop_name, shop.getShopName());
        values.put(FeedReaderContract.ShopTable.retail_id, shop.getRetailId());
        values.put(FeedReaderContract.ShopTable.retail_name, shop.getRetailName());
        values.put(FeedReaderContract.ShopTable.fullName, shop.getFullName());
        values.put(FeedReaderContract.ShopTable.country, shop.getCountry());
        values.put(FeedReaderContract.ShopTable.state, shop.getState());
        values.put(FeedReaderContract.ShopTable.city, shop.getCity());
        values.put(FeedReaderContract.ShopTable.adress, shop.getAdress());
        values.put(FeedReaderContract.ShopTable.lat, shop.getLat() + "");
        values.put(FeedReaderContract.ShopTable.lat_long, shop.getLat_long() + "");
        values.put(FeedReaderContract.ShopTable.img, shop.getImg());
        values.put(FeedReaderContract.ShopTable.logo, shop.getLogo());
        values.put(FeedReaderContract.ShopTable.canal_id, shop.getCanalId());
        values.put(FeedReaderContract.ShopTable.subcanal_id, shop.getSubCanalId());
        values.put(FeedReaderContract.ShopTable.type, shop.getType());
        values.put(FeedReaderContract.ShopTable.user_id, shop.getUserId());
        values.put(FeedReaderContract.ShopTable.zones, shop.getZone());
        values.put(FeedReaderContract.ShopTable.surveyType, shop.getSurveyTypes());
        long newRowId = 0;

        newRowId = db.insert(FeedReaderContract.ShopTable.TABLE_NAME, null, values);
        return newRowId;
    }


    @Override
    public Shop getItemByCursor(Cursor cursor) {
        if (cursor != null) {
            try {
                int shopId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ShopTable.shop_id));
                String shopName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.shop_name));
                int retailId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ShopTable.retail_id));
                String retaillName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.retail_name));
                String country = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.country));
                String state = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.state));
                String city = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.city));
                String adress = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.adress));
                Double lat = cursor.getDouble(cursor.getColumnIndex(FeedReaderContract.ShopTable.lat));
                Double latLng = cursor.getDouble(cursor.getColumnIndex(FeedReaderContract.ShopTable.lat_long));
                String img = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.img));
                String logo = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.logo));
                int canalId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ShopTable.canal_id));
                int subCanalId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ShopTable.subcanal_id));
                String type = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.type));
                int userId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ShopTable.user_id));
                String zone = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.zones));
                String surveryType = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.surveyType));
                String fullName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.surveyType));


                return new Shop(shopId, retailId, shopName, lat, latLng, img, adress, state, zone, canalId, subCanalId, city, country, userId
                        , type, retaillName, logo, surveryType, fullName);
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                cursor.close();
            }
        }
        return new Shop();
    }

    @Override
    public Shop getItemForCursor(Cursor cursor) {
        if (cursor != null) {

            int shopId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ShopTable.shop_id));
            String shopName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.shop_name));
            int retailId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ShopTable.retail_id));
            String retaillName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.retail_name));
            String country = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.country));
            String state = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.state));
            String city = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.city));
            String adress = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.adress));
            Double lat = cursor.getDouble(cursor.getColumnIndex(FeedReaderContract.ShopTable.lat));
            Double latLng = cursor.getDouble(cursor.getColumnIndex(FeedReaderContract.ShopTable.lat_long));
            String img = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.img));
            String logo = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.logo));
            int canalId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ShopTable.canal_id));
            int subCanalId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ShopTable.subcanal_id));
            String type = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.type));
            int userId = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.ShopTable.user_id));
            String zone = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.zones));
            String surveryType = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.surveyType));
            String fullName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.ShopTable.surveyType));


            return new Shop(shopId, retailId, shopName, lat, latLng, img, adress, state, zone, canalId, subCanalId, city, country, userId
                    , type, retaillName, logo, surveryType, fullName);
        }
        return new Shop();
    }

    @Override
    public boolean updateImgPath(SQLiteDatabase db, String URL, long id, IDBResultView callBack) {
        return false;
    }

    @Override
    public ArrayList<Shop> getAllItems() {
        TableDbHelper dbHelper = TableDbHelper.getInstanceShop(G.context);
//
        // Gets the data repository in write mode
        if (dbHelper.isTableExists(FeedReaderContract.ShopTable.TABLE_NAME, true)) {
            final SQLiteDatabase db = dbHelper.getWritableDatabase();

            Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.ShopTable.TABLE_NAME, null);
//            db.close();
            return getItemsByCursor(cursor, db);
        } else {
            return new ArrayList<>();
        }
    }

    public boolean hasShop() {
        TableDbHelper dbHelper = TableDbHelper.getInstanceShop(G.context);
        if (dbHelper.isTableExists(FeedReaderContract.ShopTable.TABLE_NAME, true)) {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            String count = "SELECT count(*) FROM " + FeedReaderContract.ShopTable.TABLE_NAME;
            Cursor mcursor = db.rawQuery(count, null);
            mcursor.moveToFirst();
            int icount = mcursor.getInt(0);

            if (icount > 0) {
//                db.close();
                return true;
            } else {
//                db.close();
                return false;
            }
        } else {
            return false;
        }

    }

    @Override
    public ArrayList<Shop> getItemsByCursor(Cursor cursor, SQLiteDatabase db) {
        try {
            ArrayList<Shop> shops = new ArrayList<>();
            if (cursor.moveToFirst()) {
                while (!cursor.isAfterLast()) {

                    shops.add(getItemForCursor(cursor));

                    cursor.moveToNext();
                }
            }
            cursor.close();
//            db.close();
            return shops;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
//            db.close();
            cursor.close();
        }
//        db.close();
        return new ArrayList<>();
    }

    @Override
    public String getImgURLById(long id) {
        return null;
    }

    @Override
    public ContentValues getValuse(Shop item) {
        return null;
    }

//    @Override
//    public void downloadImages(IDBResultView callBack) {
//
//    }

    public String getSurveyTypes() {
        return surveyTypes;
    }

    public void setSurveyTypes(String surveyTypes) {
        this.surveyTypes = surveyTypes;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    //endregion
}
