package cl.bequarks.project.paraeco.ServerRequests.sendSurvey;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SurveyResult {

    @SerializedName("result")
    @Expose
    private String result;

    @SerializedName("error")
    @Expose
    private boolean error;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public boolean isError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }
}
