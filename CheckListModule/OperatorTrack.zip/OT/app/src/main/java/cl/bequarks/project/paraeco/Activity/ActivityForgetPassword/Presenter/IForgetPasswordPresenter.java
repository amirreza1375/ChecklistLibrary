package cl.bequarks.project.paraeco.Activity.ActivityForgetPassword.Presenter;

public interface IForgetPasswordPresenter {
    void checkValidation(String email);
    void sendForgetPasswordEmail(String email, String devid);
//    void sendForgetPasswordEmail(ForgetPassword newMoe);
}