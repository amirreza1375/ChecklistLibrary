package cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Presenter;

import cl.bequarks.project.paraeco.Activity.ActivityMain.CheckListItems.Model.UserCheckList;

interface ICheckLsitDataPresenter {

   void insert(UserCheckList userCheckList);
   void getCheckListItemsByUserAndDate(String user,String date);
   void getCheckListDataById(long id);
   void changeCheckListSync(long id);
   void getCheckListAndPictures(long id);
   void getDeletedItems(String user);
   void removeAllDeletedItems();

}
