package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBResultView;
import cl.bequarks.project.paraeco.DBHelper.FeedReaderContract;
import cl.bequarks.project.paraeco.DBHelper.TableDbHelper;
import cl.bequarks.project.paraeco.Global.G;
import cl.bequarks.project.paraeco.Global.SaveImage;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static cl.bequarks.project.paraeco.sharedpreference.Config.APP_FOLDER_ACCESSORY;
import static cl.bequarks.project.paraeco.sharedpreference.Config.removeFolderEntries;

public class Accessory extends DBModelBaseTemp<Accessory> implements IAccessory {


    public static String conf_endtDate = "endDate";
    public static String conf_img = "img";
    public static String conf_accessory_name = "accessory_name";
    public static String conf_result_id = "result_id";
    public static String conf_startDate = "startDate";
    public static String conf_shop_id = "shop_id";

    //region Field of DB
    private long _ID;
    private String endtDate;
    private String img;
    private String img_path;
    private String accessory_name;
    private String result_id;
    private String shop_id;
    private String shop_id_String;
    private String result_id_String;
    private String startDate;


    //endregion

    //region Constructor
    public Accessory(
            String optico_name, String result_id,
            String img, String startDate, String endtDate,
            String img_path, String shop_id
    ) {
        this.accessory_name = optico_name;
        this.result_id = result_id;
        this.img = img;
        this.startDate = startDate;
        this.endtDate = endtDate;
        this.img_path = img_path;
        this.shop_id = shop_id;
    }

    public Accessory() {

    }

    @Override
    public SQLiteDatabase dropAndCreateTable() {
        TableDbHelper dbHelper = TableDbHelper.getInstanceAccessory(G.context);
//
        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL(FeedReaderContract.AccessoryTalbe.SQL_DELETE_ENTRIES);
        db.execSQL(FeedReaderContract.AccessoryTalbe.SQL_CREATE_ENTRIES);


        return db;
    }
    //endregion

    //region method of IAccessory
    @Override
    public String getAccessoryName() {
        return this.accessory_name;
    }

    @Override
    public String getResultId() {
        return this.result_id;
    }

    @Override
    public String getImg() {
        return this.img;
    }

    @Override
    public String getStartDate() {
        return this.startDate;
    }

    @Override
    public String getEndDate() {
        return this.endtDate;
    }

    @Override
    public String getImgPath() {
        return this.img_path;
    }

    @Override
    public String getShopId() {
        return this.shop_id;
    }

    public String getShop_Id_String() {
        return this.shop_id_String;
    }

    public String getResult_id_String() {
        return this.result_id_String;
    }

    public void setImg_path(String path) {
        this.img_path = path;
    }

    @Override
    public ArrayList<Accessory> fetchByShop(int shop_id) {

        List<Accessory> accessorys = getAllItems();
        ArrayList<Accessory> filteredOpticos = new ArrayList<Accessory>();
        for (int i = 0; i < accessorys.size(); i++) {
            boolean EXIST = false;
            ArrayList<Integer> shop = Optico.convert_String_to_ArrayListInteger((accessorys.get(i)).getShop_Id_String());
            for (int j = 0; j < shop.size(); j++) {
                if (shop.get(j) == shop_id) {
                    EXIST = true;
                    break;
                }
            }
            if (EXIST) {
                filteredOpticos.add((accessorys.get(i)));
            }
        }
        return filteredOpticos;
    }

    @Override
    public List<Accessory> fetchByShopResultId(int shop_id, int ID, int subcanal, int Posiction, int Elemento) {
        List<Accessory> accessorys = getAllItems();
        ArrayList<Accessory> filteredOpticos = new ArrayList();
        int i = 0;
        while (i < accessorys.size()) {
            boolean EXIST = false;
            ArrayList<Integer> shops = Optico.convert_String_to_ArrayListInteger(accessorys.get(i).getShop_Id_String());
            for (int j = 0; j < shops.size(); j++) {
                if (shops.get(j) == shop_id && Optico.IsResultOk(ID, subcanal, Posiction, Elemento, Optico.convert_String_to_JSONArray(((Accessory) accessorys.get(i)).getResult_id_String()))) {
                    EXIST = true;
                    break;
                }
            }
            if (EXIST) {
                filteredOpticos.add(accessorys.get(i));
            }
            i++;
        }
        return filteredOpticos;
    }

    //endregion

    //region method of base model

    @Override
    public long insert(Accessory accessory, SQLiteDatabase db, IDBResultView callBack) {

        ContentValues values = new ContentValues();
        values.put(FeedReaderContract.AccessoryTalbe.accessory_name, accessory.getAccessoryName());
        values.put(FeedReaderContract.AccessoryTalbe.shop_id, accessory.getShopId());
        values.put(FeedReaderContract.AccessoryTalbe.result_id, accessory.getResultId());
        values.put(FeedReaderContract.AccessoryTalbe.img, accessory.getImg());
        values.put(FeedReaderContract.AccessoryTalbe.startDate, accessory.getStartDate());
        values.put(FeedReaderContract.AccessoryTalbe.endtDate, accessory.getEndDate());
        values.put(FeedReaderContract.AccessoryTalbe.imgPath, accessory.getImgPath());

        long newRowId = db.insert(FeedReaderContract.AccessoryTalbe.TABLE_NAME, null, values);
        return newRowId;

    }

    @Override
    public Accessory getByJson(JSONObject json) {
        try {
            return new Accessory(
                    json.getString(Accessory.conf_accessory_name),
                    json.getJSONArray(Accessory.conf_result_id).toString(),
                    json.getString(Accessory.conf_img),
                    json.getString(Accessory.conf_startDate),
                    json.getString(Accessory.conf_endtDate),
                    "",
                    json.getString(Optico.conf_shop_id)
            );
        } catch (JSONException e) {
            e.printStackTrace();
            Accessory temp = new Accessory();
            temp.errorMessage = e.getMessage();
            return temp;
        }
    }

    @Override
    public void refreshTable(final JSONArray json, final IDBResultView callback) {
        removeFolderEntries(APP_FOLDER_ACCESSORY);
        final SQLiteDatabase db = dropAndCreateTable();
        new Thread(new Runnable() {
            @Override
            public void run() {
                Log.i(MODEL_TAG, "Accessory -> Insert start");
//                db.beginTransaction();
                for (int i = 0; i < json.length(); i++) {
                    try {

                        Accessory accessory = getByJson(json.getJSONObject(i));
                        if (accessory.getErrorMessage() == null) {
                            updateImgPath(db, accessory.getImg(), insert(accessory, db, callback), callback);

                        } else {
                            callback.onFail(accessory.errorMessage);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        callback.onFail("Accessory have some problem");
                    }
                }
                Log.i(MODEL_TAG, "Accessory -> Insert finished");
//                db.endTransaction();
//                db.close();
                callback.onSuccess();
//                db.close();
            }
        }).start();
    }

    @Override
    public SQLiteDatabase getDataBaseConnection() {
        return TableDbHelper.getInstanceAccessory(G.context).getWritableDatabase();
    }

    @Override
    public Accessory fetchById(long id) {
        TableDbHelper dbHelper = TableDbHelper.getInstanceAccessory(G.context);

        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.AccessoryTalbe.TABLE_NAME
                + " where " + FeedReaderContract.AccessoryTalbe._ID + "='" + id + "'", null);

        cursor.moveToNext();
//        Cursor cursor = db.rawQuery("SELECT * FROM " + FeedReaderContract.AccessoryTalbe.TABLE_NAME
//                +" WHERE "+FeedReaderContract.AccessoryTalbe._ID +"="+id, null);
//        db.close();
        return getItemByCursor(cursor);
    }

    @Override
    public Accessory getItemByCursor(Cursor cursor) {

        if (cursor != null) {
            try {

                long ID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.AccessoryTalbe._ID));
                String name = cursor.getString(cursor.getColumnIndex(FeedReaderContract.AccessoryTalbe.accessory_name));
                String resultID = cursor.getString(cursor.getColumnIndex(FeedReaderContract.AccessoryTalbe.result_id));
                String img = cursor.getString(cursor.getColumnIndex(FeedReaderContract.AccessoryTalbe.img));
                String startDate = cursor.getString(cursor.getColumnIndex(FeedReaderContract.AccessoryTalbe.startDate));
                String endDate = cursor.getString(cursor.getColumnIndex(FeedReaderContract.AccessoryTalbe.endtDate));
                String imgPath = cursor.getString(cursor.getColumnIndex(FeedReaderContract.AccessoryTalbe.imgPath));
                String shopId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.AccessoryTalbe.shop_id));

                Accessory accessory = new Accessory(name, resultID, img, startDate, endDate, imgPath, shopId);
                accessory.set_ID(ID);
                return accessory;
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                cursor.close();
            }
        }
        return new Accessory();
    }

    public Accessory getItemForCursor(Cursor cursor) {

        if (cursor != null) {

            long ID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.AccessoryTalbe._ID));
            String name = cursor.getString(cursor.getColumnIndex(FeedReaderContract.AccessoryTalbe.accessory_name));
            String resultID = cursor.getString(cursor.getColumnIndex(FeedReaderContract.AccessoryTalbe.result_id));
            String img = cursor.getString(cursor.getColumnIndex(FeedReaderContract.AccessoryTalbe.img));
            String startDate = cursor.getString(cursor.getColumnIndex(FeedReaderContract.AccessoryTalbe.startDate));
            String endDate = cursor.getString(cursor.getColumnIndex(FeedReaderContract.AccessoryTalbe.endtDate));
            String imgPath = cursor.getString(cursor.getColumnIndex(FeedReaderContract.AccessoryTalbe.imgPath));
            String shopId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.AccessoryTalbe.shop_id));

            Accessory accessory = new Accessory(name, resultID, img, startDate, endDate, imgPath, shopId);
            accessory.set_ID(ID);
            return accessory;

        }
        return new Accessory();
    }
//    @Override
//    public void downloadImages(IDBResultView callBack){
//        ArrayList<Accessory> accessories = getAllItems();
//        for (int i = 0 ; i < accessories.size() ; i++){
//            updateImgPath(accessories.get(i).getImg(),accessories.get(i).get_ID(),callBack);
//        }
//    }

    @Override
    public boolean updateImgPath(final SQLiteDatabase db, String URL, final long id, final IDBResultView callBack) {
        new SaveImage().saveImage(URL, SaveImage.saveImage.ACCESSORY, new SaveImage.ImageSaverListener() {
            @Override
            public void onImageSaved(String path) {
//                            TableDbHelper dbHelper = new TableDbHelper(G.context, FeedReaderContract.AccessoryTalbe.SQL_DELETE_ENTRIES
//                                    , FeedReaderContract.AccessoryTalbe.SQL_CREATE_ENTRIES);
//
                // Gets the data repository in write mode

                ContentValues values = new ContentValues();
                values.put(FeedReaderContract.AccessoryTalbe.imgPath, path);

                db.update(FeedReaderContract.AccessoryTalbe.TABLE_NAME, values, FeedReaderContract.AccessoryTalbe._ID + "=" + id, null);
//                db.close();
                callBack.onItemInserted();
            }
        });

        return true;
    }

    @Override
    public ArrayList<Accessory> getAllItems() {
        TableDbHelper dbHelper = TableDbHelper.getInstanceAccessory(G.context);
//
        // Gets the data repository in write mode
        if (dbHelper.isTableExists(FeedReaderContract.AccessoryTalbe.TABLE_NAME, true)) {

            final SQLiteDatabase db = dbHelper.getWritableDatabase();

            Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.AccessoryTalbe.TABLE_NAME, null);

            return getItemsByCursor(cursor, db);
        } else {
            return new ArrayList<>();
        }
    }

    public ArrayList<Accessory> getItemsByCursor(Cursor cursor, SQLiteDatabase db) {
        try {
            ArrayList<Accessory> accessories = new ArrayList<>();
            if (cursor.moveToFirst()) {
                while (!cursor.isAfterLast()) {

                    accessories.add(getItemForCursor(cursor));

                    cursor.moveToNext();
                }
            }
            cursor.close();
//            db.close();
            return accessories;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
//            db.close();
            cursor.close();
        }
//        db.close();
        return new ArrayList<>();
    }

    @Override
    public String getImgURLById(long id) {
        Accessory accessory = fetchById(id);
        return accessory.getImg();
    }

    @Override
    public ContentValues getValuse(Accessory item) {
        return null;
    }

    public long get_ID() {
        return _ID;
    }

    public void set_ID(long _ID) {
        this._ID = _ID;
    }

    //endregion


}
