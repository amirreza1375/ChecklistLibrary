package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View;


import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Accessory;

import java.util.List;

public interface IAccessoryView   {
    void accessories(List<Accessory> list);

    void accessoriesByCondition(List<Accessory> list);

    void accessoriesById(Accessory accessory);

    void accessoriesByShop(List<Accessory> list);

    void accessoryIserted(boolean status);


    void onItemInserted(String name);
}
