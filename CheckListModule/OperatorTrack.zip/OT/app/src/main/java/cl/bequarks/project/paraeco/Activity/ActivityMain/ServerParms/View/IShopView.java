package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View;


import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Shop;

import java.util.ArrayList;
import java.util.List;

public interface IShopView   {
    void AllShops(List<Shop> list);

    void LocatedShops(List<Shop> list);

    void LocatedShopsubCanalShops(List<Shop> list);

    void ShopById(Shop shop);

    void ShopInserted(boolean status);

    void ShopsByCurrentLocation(ArrayList<Shop> shops);

    void NoShopsAround(String error);

    void onItemInserted(String name);
}
