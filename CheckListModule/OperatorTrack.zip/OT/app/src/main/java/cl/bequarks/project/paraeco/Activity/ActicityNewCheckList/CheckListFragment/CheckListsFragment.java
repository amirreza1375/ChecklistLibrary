package cl.bequarks.project.paraeco.Activity.ActicityNewCheckList.CheckListFragment;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;
import java.util.List;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model.Checklist;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Presenter.CheckListPresenter;
import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.ICheckListView;
import cl.bequarks.project.paraeco.R;

import static cl.bequarks.project.paraeco.Activity.ActicityNewCheckList.ShopsFragment.ShopsFragment.showToast;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link CheckListsFragment.CheckListActionListener} interface
 * to handle interaction events.
 * Use the {@link CheckListsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CheckListsFragment extends Fragment implements ICheckListView
,CheckListsRecyclerAdapter.CheckListActionListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private int type;
    private int subCanal;
    private String shopId;

    private CheckListActionListener mListener;

    private RecyclerView recyclerView;
    private List<Checklist> checklists;
    private CheckListPresenter checkListPresenter;
    private Checklist checklist;

    public CheckListsFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *

     * @return A new instance of fragment CheckListsFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static CheckListsFragment newInstance(int subCanal,int type,String shopId) {
        CheckListsFragment fragment = new CheckListsFragment();
        Bundle args = new Bundle();
        args.putInt("subCanal",subCanal);
        args.putInt("type",type);
        args.putString("shopId",shopId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.recycler);
        checklists = new ArrayList<>();

        //region presenters
        checkListPresenter = new CheckListPresenter();
        checklist = new Checklist();
        checkListPresenter.addModel(checklist);
        checkListPresenter.attachView(this);
        checkListPresenter.getByTypeAndSubCanal(shopId,type,subCanal);
        //endregion

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
            shopId = getArguments().getString("shopId");
            subCanal = getArguments().getInt("subCanal");
            type = getArguments().getInt("type");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_check_lists, container, false);
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof CheckListActionListener) {
            mListener = (CheckListActionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    private void setupRecycler() {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                CheckListsRecyclerAdapter adapter = new CheckListsRecyclerAdapter(getContext(),checklists,CheckListsFragment.this);
                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                recyclerView.setAdapter(adapter);
            }
        });
    }

    private void updateRecycler() {
        if (getActivity() != null){
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (recyclerView.getAdapter() != null){
                        recyclerView.getAdapter().notifyDataSetChanged();
                    }
                }
            });
        }
    }

    private void showerrorKickOut() {
        showToast(getActivity(),getContext().getString(R.string.no_checklist));
        getActivity().finish();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void CheckLsits(List<Checklist> list) {

    }

    @Override
    public void Checklist(Checklist checklist) {

    }

    @Override
    public void CheckListInserted(boolean status) {

    }

    @Override
    public void TypeCheckList(ArrayList<Checklist> arrayList) {

    }

    @Override
    public void NoCheckListWithThisType(String error) {
        showerrorKickOut();
    }



    @Override
    public void CheckListByTypeAndSubCanal(ArrayList<Checklist> checkLists) {
        //TODO should be in MVP mode
        if (checkLists.size() == 1){
            mListener.onCheckListClicked(checkLists.get(0).getCheckId()
            ,checkLists.get(0).getJOSN().toString()
            ,checkLists.get(0).getTitle()
            ,checkLists.get(0).get_ID());
        }else {
            this.checklists = checkLists;
            setupRecycler();
            updateRecycler();
        }
    }

    @Override
    public void onItemInserted(String name) {

    }

    @Override
    public void onClicked(long checkListDataBaseId, String json, String name, long checkListServerId) {
        mListener.onCheckListClicked(checkListServerId,json,name,checkListDataBaseId);
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface CheckListActionListener {
        // TODO: Update argument type and name
        void onCheckListClicked(long checkListServerId, String json, String name, long dataBaseId);
    }
}
