package cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.Model;

interface IProduct {



}
