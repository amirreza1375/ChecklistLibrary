package cl.bequarks.project.paraeco.Logger;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cl.bequarks.project.paraeco.Activity.ActivityMain.ServerParms.View.IDBArrayResultView;
import cl.bequarks.project.paraeco.DBHelper.FeedReaderContract;
import cl.bequarks.project.paraeco.DBHelper.LoggerTableDBHelper;
import cl.bequarks.project.paraeco.Global.G;

public class LogMonitor {

    private static final String TAG = "LogMonitor";

    //region JSON data keys
    public static final String CHECKLIST_DATABASE_ID = "checklistDataBaseId";
    public static final String RESULT_ID = "resultID";
    public static final String DATE = "date";
    public static final String TIME = "time";
    public static final String ANSWER_COUNT = "answerCount";
    public static final String PICTURES_COUNT = "pictureCount";
    public static final String UPLOADED_PICTURES_COUNT = "uploadedPictureCount";
    public static final String STATUS = "status";
    public static final String N_E_T = "NET";
    public static final String ANY_MOMMENT_OFFLINE = "anyMommentOffline";
    public static final String UPLOAD_TIME = "uploadTime";
    public static final String SHOP_NAME = "shopName";
    public static final String USER_EMAIL = "userEmail";
    public static final String CHECKLIST_NAME = "checklistName";
    public static final String IS_SYNCED = "isSynced";
    private static final String QUESTION_COUNT = "questionCount";
    private static final String SHOP_ID = "shopId";
    private static final String CHECKLIST_ID = "checklistId";
    //endregion

    private long checklistDataBaseId;
    private long id;
    private String resultID;
    private String date;
    private String time;
    private int answerCount;
    private int pictureCount;
    private int uploadedPictures;
    private String status;
    private String NET;
    private int anyMommentOffline;
    private String uploadTime;
    private String shopId;
    private String checklistId;
    private String shopName;
    private String userEmail;
    private String checklistName;
    public int isSynced = 0;
    private int questionCount;


    //region constructores

    public LogMonitor(long id, long checklistDataBaseId, String resultID, String date, String time,int questionCount, int answerCount
            , int pictureCount, int uploadedPictures, String status, String net, int anyMommentOffline, String uploadTime
            ,String shopId,String checklistId, String shopName, String userEmail, String checklistName, int isSynced) {
        this.id = id;
        this.checklistDataBaseId = checklistDataBaseId;
        this.resultID = resultID;
        this.date = date;
        this.time = time;
        this.questionCount = questionCount;
        this.answerCount = answerCount;
        this.pictureCount = pictureCount;
        this.uploadedPictures = uploadedPictures;
        this.status = status;
        this.NET = net;
        this.anyMommentOffline = anyMommentOffline;
        this.uploadTime = uploadTime;
        this.shopId = shopId;
        this.checklistId = checklistId;
        this.shopName = shopName;
        this.userEmail = userEmail;
        this.checklistName = checklistName;
        this.isSynced = isSynced;
    }

    public LogMonitor() {

    }

    //endregion

    public LogMonitor fetchById(long id) {
        LoggerTableDBHelper dbHelper = LoggerTableDBHelper.getInstance(G.context);

        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.LogTable.TABLE_NAME
                + " where " + FeedReaderContract.LogTable._ID + "='" + id + "'", null);
        cursor.moveToNext();
        return getItemByCursor(cursor);
    }

    public LogMonitor fetchByCheckListDBID(long id) {
        LoggerTableDBHelper dbHelper = LoggerTableDBHelper.getInstance(G.context);

        // Gets the data repository in write mode
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor cursor = db.rawQuery("select * from " + FeedReaderContract.LogTable.TABLE_NAME
                + " where " + FeedReaderContract.LogTable.checklistDataBaseID + "='" + id + "'", null);
        cursor.moveToNext();
        return getItemByCursor(cursor);
    }

    public void Insert() {
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
////                LoggerTableDBHelper dbHelper = new LoggerTableDBHelper(G.context);
////                if (!dbHelper.isTableExists(FeedReaderContract.LogTable.TABLE_NAME,false)){
////                    getWritableDB().execSQL(FeedReaderContract.LogTable.SQL_CREATE_ENTRIES);
////                }
        Log.i(TAG, "run: " + checklistDataBaseId);

        if (!resultExist(checklistDataBaseId)) {
            SQLiteDatabase db = getWritableDB();
            ContentValues contentValues = getValues(LogMonitor.this);
            long id = db.insert(FeedReaderContract.LogTable.TABLE_NAME, null, contentValues);
            Log.i(TAG, "inserted: " + id);
        } else {

            update(LogMonitor.this);
        }
//            }
//        }).start();

    }

    public void update(LogMonitor logMonitor) {
        getWritableDB().update(FeedReaderContract.LogTable.TABLE_NAME
                , getValues(logMonitor), FeedReaderContract.LogTable.checklistDataBaseID
                        + " = " + checklistDataBaseId + "", null);
    }

    private SQLiteDatabase getWritableDB() {
        return  LoggerTableDBHelper.getInstance(G.context).getWritableDatabase();
    }

    public boolean resultExist(long resId) {
        return getItemsByCursor(getWritableDB().rawQuery("SELECT * FROM " + FeedReaderContract.LogTable.TABLE_NAME
                + " where " + FeedReaderContract.LogTable.checklistDataBaseID + " = " + resId, null)).size() != 0;
    }

    private ContentValues getValues(LogMonitor logMonitor) {
        ContentValues values = new ContentValues();
        values.put(FeedReaderContract.LogTable.checklistDataBaseID, logMonitor.checklistDataBaseId);
        values.put(FeedReaderContract.LogTable.resultID, logMonitor.resultID);
        values.put(FeedReaderContract.LogTable.Date, logMonitor.date);
        values.put(FeedReaderContract.LogTable.Time, logMonitor.time);
        values.put(FeedReaderContract.LogTable.QuesrionCount, logMonitor.questionCount);
        values.put(FeedReaderContract.LogTable.AnswerCount, logMonitor.answerCount);
        values.put(FeedReaderContract.LogTable.PictureCount, logMonitor.pictureCount);
        values.put(FeedReaderContract.LogTable.UploadedPicture, logMonitor.uploadedPictures);
        values.put(FeedReaderContract.LogTable.Status, logMonitor.status);
        values.put(FeedReaderContract.LogTable.NET, logMonitor.NET);
        values.put(FeedReaderContract.LogTable.AnyMommentOffline, logMonitor.anyMommentOffline);
        values.put(FeedReaderContract.LogTable.UploadTime, logMonitor.uploadTime);
        values.put(FeedReaderContract.LogTable.shopId, logMonitor.shopId);
        values.put(FeedReaderContract.LogTable.checklistId, logMonitor.checklistId);
        values.put(FeedReaderContract.LogTable.shopName, logMonitor.shopName);
        values.put(FeedReaderContract.LogTable.checklistName, logMonitor.checklistName);
        values.put(FeedReaderContract.LogTable.userEmail, logMonitor.userEmail);
        values.put(FeedReaderContract.LogTable.isSynced, logMonitor.isSynced);
        return values;
    }

    public void getAllItems(final IDBArrayResultView<LogMonitor> callBack) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                ArrayList<LogMonitor> logMonitors = getItemsByCursor(getWritableDB().rawQuery("SELECT * FROM " + FeedReaderContract.LogTable.TABLE_NAME, null));
                callBack.onSuccess(logMonitors);
            }
        }).start();

    }

    private ArrayList<LogMonitor> getItemsByCursor(Cursor cursor) {
        try {
            ArrayList<LogMonitor> logMonitors = new ArrayList<>();
            if (cursor.moveToFirst()) {
                while (!cursor.isAfterLast()) {

                    logMonitors.add(getItemsForCursor(cursor));

                    cursor.moveToNext();
                }
            }

            cursor.close();
            return logMonitors;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cursor.close();
        }
        return new ArrayList<>();
    }

    private LogMonitor getItemByCursor(Cursor cursor) {
        if (cursor != null) {
            try {
                long _ID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.LogTable._ID));
                long checklistDBID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.LogTable.checklistDataBaseID));
                String ResultId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.resultID));
                String Date = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.Date));
                String Time = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.Time));
                int QuestionCount = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.LogTable.QuesrionCount));
                int AnsweredCount = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.LogTable.AnswerCount));
                int PictureCount = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.LogTable.PictureCount));
                int UploadedPictures = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.LogTable.UploadedPicture));
                String Status = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.Status));
                String Net = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.NET));
                int AnyMommentOffline = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.LogTable.AnyMommentOffline));
                String UploadTime = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.UploadTime));
                String UserEmail = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.userEmail));
                String shopId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.shopId));
                String checklistId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.checklistId));
                String ShopName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.shopName));
                String CheckListName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.checklistName));
                int isSynced = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.LogTable.isSynced));
                LogMonitor logMonitor = new LogMonitor(_ID, checklistDBID, ResultId, Date, Time,QuestionCount, AnsweredCount, PictureCount, UploadedPictures
                        , Status, Net, AnyMommentOffline, UploadTime,shopId,checklistId, ShopName, UserEmail, CheckListName, isSynced);

                return logMonitor;
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                cursor.close();
            }
        }
        return new LogMonitor();
    }

    public JSONArray getJSONArrayFromArrayListLogMonitor(ArrayList<LogMonitor> logMonitors) {
        JSONArray datas = new JSONArray();
        for (int i = 0; i < logMonitors.size(); i++) {

            JSONObject data = new JSONObject();

            LogMonitor logMonitor = logMonitors.get(i);

            try {
                data.put(CHECKLIST_DATABASE_ID, logMonitor.getChecklistDataBaseId());
                data.put(RESULT_ID, logMonitor.getResultID());
                data.put(DATE, logMonitor.getDate());
                data.put(TIME, logMonitor.getTime());
                data.put(QUESTION_COUNT, logMonitor.getQuestionCount());
                data.put(ANSWER_COUNT, logMonitor.getAnswerCount());
                data.put(PICTURES_COUNT, logMonitor.getPictureCount());
                data.put(UPLOADED_PICTURES_COUNT, logMonitor.getUploadedPictures());
                data.put(STATUS, logMonitor.getStatus());
                data.put(N_E_T, logMonitor.getNET());
                data.put(ANY_MOMMENT_OFFLINE, logMonitor.getAnyMommentOffline());
                data.put(UPLOAD_TIME, logMonitor.getUploadTime());
                data.put(SHOP_ID, logMonitor.getShopId());
                data.put(CHECKLIST_ID, logMonitor.getChecklistId());
                data.put(SHOP_NAME, logMonitor.getShopName());
                data.put(CHECKLIST_NAME, logMonitor.getChecklistName());
                data.put(USER_EMAIL, logMonitor.getUserEmail());
                data.put(IS_SYNCED, logMonitor.isSynced());

                datas.put(data);
            } catch (JSONException e) {
                e.printStackTrace();
            }


        }

        return datas;
    }

    public void getAllNotSynced(final IDBArrayResultView<LogMonitor> callBack) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    ArrayList<LogMonitor> logMonitors = getItemsByCursor(getWritableDB().rawQuery("SELECT * FROM " + FeedReaderContract.LogTable.TABLE_NAME
                            + " where " + FeedReaderContract.LogTable.isSynced + " ='" + 0 +"'", null));
                    callBack.onSuccess(logMonitors);
                }
            }).start();
    }

    public void getAllInJSONArray(final LogMonitorDataListener listener) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                getAllNotSynced(new IDBArrayResultView<LogMonitor>() {
                    @Override
                    public void onSuccess(ArrayList<LogMonitor> results) {
                        listener.onDataRecieved(getJSONArrayFromArrayListLogMonitor(results));
                    }

                    @Override
                    public void onFail(String error) {

                    }
                });
            }
        }).start();
    }

    private LogMonitor getItemsForCursor(Cursor cursor) {
        if (cursor != null) {
            long _ID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.LogTable._ID));
            long checklistDBID = cursor.getLong(cursor.getColumnIndex(FeedReaderContract.LogTable.checklistDataBaseID));
            String ResultId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.resultID));
            String Date = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.Date));
            String Time = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.Time));
            int QuestionCount = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.LogTable.QuesrionCount));
            int AnsweredCount = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.LogTable.AnswerCount));
            int PictureCount = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.LogTable.PictureCount));
            int UploadedPictures = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.LogTable.UploadedPicture));
            String Status = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.Status));
            String Net = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.NET));
            int AnyMommentOffline = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.LogTable.AnyMommentOffline));
            String UploadTime = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.UploadTime));
            String UserEmail = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.userEmail));
            String shopId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.shopId));
            String checklistId = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.checklistId));
            String ShopName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.shopName));
            String CheckListName = cursor.getString(cursor.getColumnIndex(FeedReaderContract.LogTable.checklistName));
            int isSynced = cursor.getInt(cursor.getColumnIndex(FeedReaderContract.LogTable.isSynced));
            LogMonitor logMonitor = new LogMonitor(_ID, checklistDBID, ResultId, Date, Time,QuestionCount, AnsweredCount, PictureCount, UploadedPictures, Status
                    , Net, AnyMommentOffline, UploadTime,shopId,checklistId, ShopName, UserEmail, CheckListName, isSynced);

            return logMonitor;
        }
        return new LogMonitor();
    }

    public void setAllSentSynced(JSONArray data) {
        String ides = "";
        for (int i = 0; i < data.length(); i++) {
            try {
                String id = data.getJSONObject(i).getString(CHECKLIST_DATABASE_ID);
                if (data.length() == 1) {
                    ides = id;
                }else {
                    if (i == data.length() - 1){
                        ides += id;
                    }else {
                        ides += id + ",";
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }//here we have all ides in IDES variable like this 1,3,5,6,7,23

        String SQL = " UPDATE "+ FeedReaderContract.LogTable.TABLE_NAME
                +" SET "+ FeedReaderContract.LogTable.isSynced +" = '1'"+
                " WHERE "+ FeedReaderContract.LogTable.checklistDataBaseID +" IN ("
                +ides +" ) ";

        getWritableDB().execSQL(SQL);

    }

    //region setter getter


    public String getUserEmail() {
        return userEmail;
    }

    public String getShopName() {
        return shopName;
    }

    public String getChecklistName() {
        return checklistName;
    }

    public void setChecklistDataBaseId(long checklistDataBaseId) {
        this.checklistDataBaseId = checklistDataBaseId;
    }

    public long getChecklistDataBaseId() {
        return this.checklistDataBaseId;
    }

    public String getResultID() {
        return resultID;
    }

    public void setResultID(String resultID) {
        this.resultID = resultID;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getAnswerCount() {
        return answerCount;
    }

    public void setAnswerCount(int answerCount) {
        this.answerCount = answerCount;
    }

    public int getPictureCount() {
        return pictureCount;
    }

    public void setPictureCount(int pictureCount) {
        this.pictureCount = pictureCount;
    }

    public int getUploadedPictures() {
        return uploadedPictures;
    }

    public void setUploadedPictures(int uploadedPictures) {
        this.uploadedPictures = uploadedPictures;
        Log.i(TAG, "setUploadedPictures: " + checklistDataBaseId + " -> " + uploadedPictures);
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNET() {
        return NET;
    }

    public void setNET(String NET) {
        this.NET = NET;
    }

    public int getAnyMommentOffline() {
        return anyMommentOffline;
    }

    public void setAnyMommentOffline(int anyMommentOffline) {
        this.anyMommentOffline = anyMommentOffline;
    }

    public String getUploadTime() {
        return uploadTime;
    }

    public void setUploadTime(String uploadTime) {
        this.uploadTime = uploadTime;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setIsSynced(int isSynced) {
        this.isSynced = isSynced;
    }

    public int isSynced() {
        return this.isSynced;
    }

    public int getQuestionCount() {
        return questionCount;
    }

    public void setQuestionCount(int questionCount) {
        this.questionCount = questionCount;
    }

    public String getShopId() {
        return shopId;
    }

    public void setShopId(String shopId) {
        this.shopId = shopId;
    }

    public String getChecklistId() {
        return checklistId;
    }

    public void setChecklistId(String checklistId) {
        this.checklistId = checklistId;
    }


    //endregion


}
